import { MODE_FRAMES, paintFrame, resolvePreset } from 'thinking-orbs/engine';

const controllers = new WeakMap();
const STATE_LABELS = {
  working: 'Working…',
  searching: 'Searching…',
  solving: 'Solving…',
  listening: 'Listening…',
  connecting: 'Connecting…',
  weaving: 'Weaving…',
  composing: 'Composing…',
  breathing: 'Thinking…',
  shaping: 'Shaping…'
};

function resolveDark(canvas, theme) {
  if (theme === 'dark') return true;
  if (theme === 'light') return false;

  let node = canvas;
  while (node instanceof Element) {
    const dataTheme = node.getAttribute('data-theme');
    if (dataTheme === 'dark' || node.classList.contains('dark')) return true;
    if (dataTheme === 'light' || node.classList.contains('light')) return false;
    node = node.parentElement;
  }

  return globalThis.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
}

function mount(canvas, rawOptions = {}) {
  if (!(canvas instanceof HTMLCanvasElement)) return () => {};
  controllers.get(canvas)?.destroy();

  const options = {
    state: rawOptions.state || 'working',
    size: Number(rawOptions.size) === 20 ? 20 : 64,
    speed: Number.isFinite(Number(rawOptions.speed)) ? Number(rawOptions.speed) : 1,
    theme: ['light', 'dark'].includes(rawOptions.theme) ? rawOptions.theme : 'auto',
    paused: rawOptions.paused === true,
    ariaLabel: rawOptions.ariaLabel || STATE_LABELS[rawOptions.state] || STATE_LABELS.working
  };
  const dpr = Math.min(2, globalThis.devicePixelRatio || 1);
  const { mode, speed: presetSpeed, opts } = resolvePreset(options.state, options.size);
  const frame = MODE_FRAMES[mode];
  const reducedMotion = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)') ?? null;
  const themeMedia = globalThis.matchMedia?.('(prefers-color-scheme: dark)') ?? null;
  let raf = 0;
  let running = false;
  let visible = true;
  let destroyed = false;

  canvas.width = Math.round(options.size * dpr);
  canvas.height = Math.round(options.size * dpr);
  canvas.style.width = `${options.size}px`;
  canvas.style.height = `${options.size}px`;
  canvas.style.display = 'block';
  if (canvas.getAttribute('aria-hidden') !== 'true') {
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', options.ariaLabel);
  }

  const ctx = canvas.getContext('2d');
  if (!ctx) return () => {};

  const draw = (time = performance.now()) => {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, options.size, options.size);
    const timeSeconds = reducedMotion?.matches ? 0.6 : (time / 1000) * presetSpeed * options.speed;
    paintFrame(ctx, frame(options.size, timeSeconds, opts), resolveDark(canvas, options.theme));
  };
  const loop = (time) => {
    draw(time);
    if (running) raf = requestAnimationFrame(loop);
  };
  const stop = () => {
    running = false;
    cancelAnimationFrame(raf);
  };
  const start = () => {
    if (destroyed || running || options.paused || reducedMotion?.matches || !visible || document.hidden) return;
    running = true;
    raf = requestAnimationFrame(loop);
  };
  const refresh = () => {
    stop();
    draw();
    start();
  };
  const onVisibilityChange = () => document.hidden ? stop() : start();
  const onReducedMotionChange = () => refresh();
  const onThemeChange = () => draw();
  const intersectionObserver = typeof IntersectionObserver === 'undefined'
    ? null
    : new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) start();
      else stop();
    });
  const themeObserver = options.theme === 'auto' && typeof MutationObserver !== 'undefined'
    ? new MutationObserver(onThemeChange)
    : null;

  intersectionObserver?.observe(canvas);
  themeObserver?.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['class', 'data-theme']
  });
  document.addEventListener('visibilitychange', onVisibilityChange);
  reducedMotion?.addEventListener?.('change', onReducedMotionChange);
  themeMedia?.addEventListener?.('change', onThemeChange);
  draw();
  if (!intersectionObserver) start();

  const destroy = () => {
    if (destroyed) return;
    destroyed = true;
    stop();
    intersectionObserver?.disconnect();
    themeObserver?.disconnect();
    document.removeEventListener('visibilitychange', onVisibilityChange);
    reducedMotion?.removeEventListener?.('change', onReducedMotionChange);
    themeMedia?.removeEventListener?.('change', onThemeChange);
    controllers.delete(canvas);
  };
  controllers.set(canvas, { destroy });
  return destroy;
}

function mountDeclarativeOrbs(root = document) {
  root.querySelectorAll?.('canvas[data-thinking-orb]').forEach((canvas) => {
    mount(canvas, {
      state: canvas.dataset.thinkingOrb,
      size: canvas.dataset.orbSize,
      speed: canvas.dataset.orbSpeed,
      theme: canvas.dataset.orbTheme,
      paused: canvas.dataset.orbPaused === 'true',
      ariaLabel: canvas.getAttribute('aria-label') || undefined
    });
  });
}

globalThis.DinSideThinkingOrb = Object.freeze({
  mount,
  unmount(canvas) {
    controllers.get(canvas)?.destroy();
  }
});

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => mountDeclarativeOrbs(), { once: true });
} else {
  mountDeclarativeOrbs();
}
