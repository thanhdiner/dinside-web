(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');
  providers.register({
    id: 'gemini',
    name: 'Gemini',
    shortName: 'Gemini',
    frameId: 'providerFrame',
    homeUrl: 'https://gemini.google.com/app',
    origins: ['https://gemini.google.com'],
    supportsThemeSync: true,
    getAccountUrl(slot = '') {
      const normalized = /^\d$/.test(String(slot)) ? String(slot) : '';
      return normalized
        ? `https://gemini.google.com/u/${normalized}/app?pageId=none`
        : 'https://gemini.google.com/app';
    },
    getAccountSlot(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        if (url.hostname !== 'gemini.google.com') return null;
        return url.pathname.match(/^\/u\/(\d)(?:\/|$)/i)?.[1] ?? null;
      } catch (_) {
        return null;
      }
    },
    isRestorableChatUrl(rawUrl) {
      return /^https:\/\/gemini\.google\.com\/(?:u\/\d\/)?app\/[^/?#]+/.test(String(rawUrl || ''));
    },
    getChatIdentity(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        const match = url.pathname.match(/^\/(?:u\/(\d)\/)?app\/([^/]+)/i);
        const account = url.pathname.match(/^\/u\/(\d)(?:\/|$)/i)?.[1] || 'default';
        return match ? `conversation:${account}:${match[2]}` : `draft:${account}`;
      } catch (_) {
        return rawUrl;
      }
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      const account = String(previousIdentity || '').match(/^draft:(.+)$/)?.[1];
      return Boolean(account && String(nextIdentity || '').startsWith(`conversation:${account}:`));
    }
  });
})();
