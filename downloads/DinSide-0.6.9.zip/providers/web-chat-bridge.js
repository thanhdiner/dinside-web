(() => {
  if (window.__dinSideWebChatBridgeInstalled) return;
  window.__dinSideWebChatBridgeInstalled = true;
  const t = (source, ...values) => {
    if (globalThis.DinSideI18n?.t) return globalThis.DinSideI18n.t(source, ...values);
    const key = Array.isArray(source)
      ? source.reduce((result, part, index) => result + (index ? `{${index - 1}}` : '') + part, '')
      : String(source ?? '');
    return key.replace(/\{(\d+)\}/g, (match, index) => index < values.length ? String(values[index]) : match);
  };
  const BRIDGE_PROFILES = [
    {
      id: 'chatgpt',
      name: 'ChatGPT',
      hosts: ['chatgpt.com'],
      composerSelectors: [
        '#prompt-textarea',
        '[data-testid="prompt-textarea"]',
        'div.ProseMirror[contenteditable="true"]',
        '[contenteditable="true"][role="textbox"]',
        'textarea[placeholder*="Ask"]',
        'textarea'
      ],
      sendButtonSelectors: [
        'button[data-testid="send-button"]',
        'button[data-testid="composer-submit-button"]',
        'button[aria-label="Send prompt"]',
        'button[aria-label="Send message"]',
        'button[aria-label="Send"]',
        'button[type="submit"]'
      ],
      disclaimer: 'ChatGPT can make mistakes. Check important info.'
    },
    {
      id: 'gemini',
      name: 'Gemini',
      hosts: ['gemini.google.com'],
      ignoredPathPrefixes: ['/_/'],
      composerSelectors: [
        '[aria-label="Enter a prompt for Gemini"][contenteditable="true"]',
        '[aria-label="Enter a prompt for Gemini"]',
        'rich-textarea [contenteditable="true"]',
        '[contenteditable="true"][role="textbox"]'
      ],
      sendButtonSelectors: [
        'button[aria-label="Send message"]',
        'button[aria-label^="Send"]',
        'button[type="submit"]'
      ]
    },
    {
      id: 'googleaimode',
      name: 'Google AI Mode',
      hosts: ['google.com'],
      preferLastComposer: true,
      maxPromptChars: 6000,
      matchesLocation() {
        if (location.pathname === '/ai') return true;
        const params = new URLSearchParams(location.search);
        return location.pathname === '/search' && (
          params.get('udm') === '50' || params.get('aep') === '11'
        );
      },
      composerSelectors: [
        '[aria-label*="Ask anything" i][contenteditable="true"]',
        'textarea[aria-label*="Ask anything" i]',
        'textarea[placeholder*="Ask anything" i]',
        '[aria-label*="Hỏi" i][contenteditable="true"]',
        'textarea[aria-label*="Hỏi" i]',
        'textarea[placeholder*="Hỏi" i]',
        '[contenteditable="true"][role="textbox"]',
        'textarea:not([name="q"]):not([role="combobox"])',
        'textarea[name="q"]'
      ],
      sendButtonSelectors: [
        'button[aria-label="Send"]',
        'button[aria-label^="Send "]',
        'button[aria-label="Gửi"]',
        'button[aria-label^="Gửi "]',
        'button[type="submit"]'
      ]
    },
    {
      id: 'googleaistudio',
      name: 'Google AI Studio',
      hosts: ['aistudio.google.com'],
      maxPromptChars: 49000,
      matchesLocation() {
        return /^\/(?:u\/\d\/)?prompts\//.test(location.pathname);
      },
      composerSelectors: [
        'ms-prompt-box textarea',
        'textarea[placeholder*="Start typing a prompt" i]',
        'textarea[aria-label="Enter a prompt"]',
        'textarea[placeholder*="prompt" i]',
        'ms-prompt-input-wrapper textarea',
        '.prompt-box-container textarea',
        'ms-prompt-input-wrapper [contenteditable="true"]',
        '.prompt-box-container [contenteditable="true"]'
      ],
      sendButtonSelectors: [
        'ms-prompt-box ms-run-button button',
        'ms-prompt-box button[aria-label="Run"]',
        'button[aria-label="Run"]',
        'button[aria-label="Run prompt"]',
        'button[aria-label="Send"]',
        'button[aria-label="Send message"]',
        'button.run-button',
        'button[type="submit"]'
      ]
    },
    {
      id: 'notebooklm',
      name: 'NotebookLM',
      hosts: ['notebook.google.com', 'notebooklm.google.com'],
      preferLastComposer: true,
      disclaimer: 'NotebookLM can be inaccurate, please double-check its responses.',
      disclaimerPattern: /^(?:NotebookLM|Gemini(?: in)? (?:NotebookLM|Notebook)) can be inaccurate[;,]\s*please (?:double-check|double check) its responses\.?$/i,
      composerSelectors: [
        'textarea[aria-label*="chat" i]',
        'textarea[aria-label*="ask" i]',
        'textarea[placeholder*="typing" i]',
        'textarea[placeholder*="ask" i]',
        '[contenteditable="true"][role="textbox"]',
        'textarea'
      ],
      sendButtonSelectors: [
        'button[aria-label*="send" i]',
        'button[aria-label*="submit" i]',
        'button[data-testid*="send" i]',
        'button[type="submit"]'
      ]
    },
    {
      id: 'claude',
      name: 'Claude',
      hosts: ['claude.ai'],
      composerSelectors: [
        '[data-testid="chat-input"][contenteditable="true"]',
        '[data-testid="chat-input"]',
        '[aria-label="Write your prompt to Claude"][contenteditable="true"]',
        '[aria-label="Write your prompt to Claude"]',
        '[contenteditable="true"][role="textbox"]',
        'div.ProseMirror[contenteditable="true"]'
      ],
      sendButtonSelectors: [
        'button[data-testid="chat-input-send"]',
        'button[aria-label="Send message"]',
        'button[aria-label="Send"]',
        'button[data-testid*="send"]',
        'button[type="submit"]'
      ]
    },
    {
      id: 'perplexity',
      name: 'Perplexity',
      hosts: ['perplexity.ai'],
      composerSelectors: [
        '#ask-input[contenteditable="true"]',
        '#ask-input',
        '[contenteditable="true"][role="textbox"]'
      ],
      sendButtonSelectors: [
        'button[aria-label="Submit"]',
        'button[type="submit"]'
      ]
    },
    {
      id: 'deepseek',
      name: 'DeepSeek',
      hosts: ['chat.deepseek.com'],
      composerSelectors: [
        'textarea[placeholder*="DeepSeek"]',
        'textarea'
      ],
      sendButtonSelectors: [
        'div[role="button"][aria-disabled]:not(.ds-toggle-button)'
      ]
    },
    {
      id: 'openrouter',
      name: 'OpenRouter',
      hosts: ['openrouter.ai'],
      requiredPathPrefixes: ['/chat'],
      composerSelectors: [
        'textarea[data-testid="composer-input"]',
        'textarea[placeholder^="Start a new message"]',
        'textarea'
      ],
      sendButtonSelectors: [
        'button[data-testid="send-button"]',
        'button[aria-label="Send message"]'
      ]
    },
    {
      id: 'copilot',
      name: 'Microsoft Copilot',
      hosts: ['copilot.microsoft.com'],
      composerSelectors: [
        'textarea[data-testid="composer-input"]',
        'textarea#userInput',
        'textarea[placeholder="Message Copilot"]'
      ],
      sendButtonSelectors: [
        'button[data-testid="submit-button"]'
      ]
    },
    {
      id: 'qwen',
      name: 'Qwen',
      hosts: ['chat.qwen.ai'],
      composerSelectors: [
        'textarea.message-input-textarea',
        'textarea[placeholder="Ask Qwen"]'
      ],
      sendButtonSelectors: [
        'button.send-button',
        'button[aria-label="Send"]'
      ]
    },
    {
      id: 'kimi',
      name: 'Kimi',
      hosts: ['kimi.ai'],
      composerSelectors: [
        '.chat-editor .chat-input-editor[contenteditable="true"]',
        '.chat-input-editor[contenteditable="true"]'
      ],
      sendButtonSelectors: [
        '.chat-editor .send-button-container:not(.disabled):not(.stop)',
        '.send-button-container:not(.disabled):not(.stop)'
      ]
    },
    {
      id: 'metaai',
      name: 'Meta AI',
      hosts: ['meta.ai'],
      composerSelectors: [
        '[data-testid="composer-input"][contenteditable="true"]',
        'textarea[data-testid="composer-input"]',
        '.ql-editor[contenteditable="true"]',
        '[contenteditable="true"][role="textbox"]',
        '[contenteditable="true"][aria-label*="Ask Meta AI" i]',
        'textarea[placeholder*="Ask Meta AI" i]',
        'textarea[aria-label*="Ask Meta AI" i]'
      ],
      sendButtonSelectors: [
        'button[data-testid="composer-send-button"]',
        'button[aria-label="Send"]',
        'button[aria-label="Send message"]',
        'button[aria-label*="Send" i]',
        'button[data-testid*="send" i]',
        'button[type="submit"]'
      ]
    },
    {
      id: 'mimo',
      name: 'Xiaomi MiMo Studio',
      hosts: ['aistudio.xiaomimimo.com'],
      maxPromptChars: 49000,
      composerSelectors: [
        'textarea[placeholder^="Tell me what you want to build"]',
        'textarea[placeholder^="Ask me anything"]',
        'textarea[placeholder^="想做什么"]',
        'textarea[placeholder^="有问题"]',
        '#root textarea[rows="1"][class*="resize-none"]'
      ],
      sendButtonSelectors: [
        'button[data-track-id="home_send_btn"]',
        'button[data-track-name="home_send_message"]'
      ]
    },
    {
      id: 'zai',
      name: 'Z.ai',
      hosts: ['chat.z.ai'],
      composerSelectors: [
        '#chat-input'
      ],
      sendButtonSelectors: [
        '#send-message-button'
      ]
    }
  ];
  const provider = BRIDGE_PROFILES.find((candidate) =>
    candidate.hosts.some((host) => location.hostname === host || location.hostname.endsWith(`.${host}`)) &&
    (!candidate.matchesLocation || candidate.matchesLocation())
  );
  if (!provider) return;
  const isCurrentProviderLocation = () => !provider.matchesLocation || provider.matchesLocation();
  if (!isCurrentProviderLocation()) return;
  if (provider.requiredPathPrefixes && !provider.requiredPathPrefixes.some((prefix) => location.pathname.startsWith(prefix))) return;
  if (provider.ignoredPathPrefixes?.some((prefix) => location.pathname.startsWith(prefix))) return;
  const DINSIDE_BRIDGE_VERSION = chrome.runtime.getManifest().version;
  if (provider.id === 'perplexity' && window.parent !== window && navigator.serviceWorker) {
    navigator.serviceWorker.getRegistrations()
      .then((registrations) => Promise.all(registrations.map((registration) => registration.unregister())))
      .catch(() => {});
  }

  console.info('[DinSide bridge] loaded', {
    version: DINSIDE_BRIDGE_VERSION,
    extensionId: chrome.runtime.id,
    provider: provider.id,
    frameUrl: location.href
  });

  // Only the provider iframe inside DinSide should replace normal sends with
  // context-aware sends. The same content script also runs in standalone
  // provider tabs for lightweight integration, where native sending must stay
  // untouched.
  const isEmbeddedProviderView = window.parent !== window;

  // DeepSeek's hCaptcha and social sign-in can fail in a third-party iframe.
  // Let the provider render its own login controls, but move authentication to
  // a normal tab before the user types credentials or starts the challenge.
  if (provider.id === 'deepseek' && isEmbeddedProviderView) {
    let lastDeepSeekAuthGestureAt = 0;
    const handleDeepSeekAuthGesture = (event) => {
      if (typeof event.button === 'number' && event.button !== 0) return;
      if (!/^\/(?:sign_in|sign_up|forgot_password)(?:\/|$)/.test(location.pathname)) return;

      const target = event.target;
      const field = target?.closest?.(
        'input[placeholder="Phone number / email address"], input[type="email"], input[type="password"]'
      );
      const control = target?.closest?.('.ds-sign-in-form__social-link, [role="button"]');
      const label = String(control?.textContent || '').trim();
      const authControl = control && /^(?:(?:sign|log)\s*in\s+with\s+(?:google|apple)|log\s*in)$/i.test(label);
      if (!field && !authControl) return;

      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      if (Date.now() - lastDeepSeekAuthGestureAt < 500) return;
      lastDeepSeekAuthGestureAt = Date.now();
      window.parent.postMessage({
        type: 'DINSIDE_PROVIDER_AUTH_OPEN',
        providerHost: location.hostname,
        url: location.href
      }, '*');
    };

    window.addEventListener('pointerdown', handleDeepSeekAuthGesture, true);
    window.addEventListener('click', handleDeepSeekAuthGesture, true);
    window.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ' || event.key.length === 1) {
        handleDeepSeekAuthGesture(event);
      }
    }, true);

    // A successful login in another tab of the same Chrome profile updates
    // DeepSeek's localStorage. The iframe does not notice until it navigates.
    window.addEventListener('storage', (event) => {
      if (event.storageArea !== localStorage || event.key !== 'userToken' ||
          !event.newValue || event.newValue === event.oldValue ||
          !/^\/(?:sign_in|sign_up)(?:\/|$)/.test(location.pathname)) return;
      window.parent.postMessage({
        type: 'DINSIDE_PROVIDER_AUTH_COMPLETE',
        providerId: 'deepseek'
      }, '*');
    });
  }

  if (provider.id === 'zai' && isEmbeddedProviderView) {
    window.addEventListener('storage', (event) => {
      if (event.storageArea !== localStorage || event.key !== 'token' ||
          !event.newValue || event.newValue === event.oldValue) return;
      window.parent.postMessage({
        type: 'DINSIDE_PROVIDER_AUTH_COMPLETE',
        providerId: 'zai'
      }, '*');
    });
  }

  let bypassNextSend = false;
  let sending = false;
  let selectedTextContexts = [];
  let committedSelectionCount = 0;
  let skillsContext = [];
  let skillsPopoverCleanup = null;
  const SKILL_LIFETIME_ORDER = ['once', 'chat', 'always'];
  const CONTEXT_DISPLAY_MODES = ['visible', 'compact'];
  const DINSIDE_USER_MESSAGE_MARKER = '[USER_MESSAGE]';
  const DINSIDE_CONTEXT_START_PATTERN = /\n\s*\[(?:DINSIDE_SKILLS|PAGE_CONTEXT(?:_UPDATE|_DIFF)?|PAGE_META|VIEWPORT_CONTEXT(?:_UPDATE)?|PINNED_PAGE_\d+|SELECTED_TEXT_\d+)\]/;
  const DINSIDE_CONTEXT_MARKER_PATTERN = /\[(?:DINSIDE_SKILLS|PAGE_CONTEXT(?:_UPDATE|_DIFF)?|PAGE_META|VIEWPORT_CONTEXT(?:_UPDATE)?|PINNED_PAGE_\d+|SELECTED_TEXT_\d+)\]/;
  const META_CONTEXT_END_MARKER = '[/DINSIDE_CONTEXT]';
  const META_CONTEXT_SECTION_PATTERN = /\[\/?(?:DINSIDE_SKILLS|PAGE_CONTEXT(?:_UPDATE|_DIFF)?|PAGE_META|VIEWPORT_CONTEXT(?:_UPDATE)?|PINNED_PAGE_\d+|SELECTED_TEXT_\d+)\]/g;
  const CHATGPT_USER_MESSAGE_SELECTOR = '[data-user-message-bubble="true"], [data-message-author-role="user"], [data-testid="user-message"], [data-testid="user-message-content"], article .bg-token-message-surface, [data-testid^="conversation-turn-"] .bg-token-message-surface';
  let contextDisplayMode = 'compact';
  let contextDisplayObserver = null;
  let contextDisplayScanFrame = 0;
  const contextDisplayScanRoots = new Set();
  let contextDisplayPendingSeq = 0;
  const pendingContextDisplayUserTexts = [];

  function queueContextDisplayUserText(userText = '', promptText = '') {
    const text = String(userText || '').trim();
    if (!text || contextDisplayMode !== 'compact') return '';
    const id = `dinside-display-${++contextDisplayPendingSeq}`;
    pendingContextDisplayUserTexts.push({ id, text, promptText, at: Date.now() });
    while (pendingContextDisplayUserTexts.length > 8) pendingContextDisplayUserTexts.shift();
    return id;
  }

  function findPendingContextDisplayUserText(renderedText = '') {
    const now = Date.now();
    while (pendingContextDisplayUserTexts.length && now - pendingContextDisplayUserTexts[0].at > 30000) {
      pendingContextDisplayUserTexts.shift();
    }

    const rendered = String(renderedText || '').replace(/\s+/g, ' ').trim();
    if (!rendered) return null;
    const hasUserMarker = rendered.includes(DINSIDE_USER_MESSAGE_MARKER);
    // Kimi can partially reconcile the prefix, and Google AI Mode can omit it
    // from the rendered search bubble altogether. A recent pending Send plus a
    // DinSide-only context marker is still an unambiguous short-lived match.
    const hasProviderContextFallback = (
      provider.id === 'kimi' || provider.id === 'googleaimode' ||
      provider.id === 'chatgpt' || provider.id === 'mimo' ||
      provider.id === 'metaai' || provider.id === 'googleaistudio' || provider.id === 'zai'
    ) && DINSIDE_CONTEXT_MARKER_PATTERN.test(rendered);
    if (!hasUserMarker && !hasProviderContextFallback) return null;

    // Prefer the newest matching turn. Gemini can render a transient version of
    // the user bubble before replacing it with the final DOM, so the same queued
    // text may need to match more than once during a single Send.
    for (let index = pendingContextDisplayUserTexts.length - 1; index >= 0; index -= 1) {
      const entry = pendingContextDisplayUserTexts[index];
      const normalized = entry.text.replace(/\s+/g, ' ').trim();
      const probe = normalized.slice(0, Math.min(80, normalized.length));
      if (probe && rendered.includes(probe)) return entry;
    }
    return null;
  }

  function consumePendingContextDisplayUserText(id = '') {
    const index = pendingContextDisplayUserTexts.findIndex((entry) => entry.id === id);
    if (index >= 0) pendingContextDisplayUserTexts.splice(index, 1);
  }

  function installContextDisplayGuardStyle() {
    // Some providers continuously reconcile rendered message children. Keep their
    // raw provider DOM intact and render Compact mode through a CSS pseudo-element
    // instead of moving/replacing framework-owned nodes.
    const existing = document.getElementById('__dinside_context_display_guard_style__');
    if (existing) return;

    const style = document.createElement('style');
    style.id = '__dinside_context_display_guard_style__';
    style.textContent = `
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="gemini"] > * {
        display: none !important;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="gemini"]::after {
        content: attr(data-dinside-context-compact-text);
        display: block;
        white-space: pre-wrap;
        font-size: var(--dinside-context-compact-font-size, 1rem);
        line-height: var(--dinside-context-compact-line-height, normal);
        font-family: inherit;
        font-weight: inherit;
        color: inherit;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaimode"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaistudio"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="chatgpt"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="notebooklm"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="claude"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="openrouter"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="qwen"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="kimi"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="metaai"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="mimo"] > *,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="zai"] > * {
        display: none !important;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaimode"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaistudio"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="notebooklm"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="claude"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="openrouter"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="kimi"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="mimo"]::after {
        content: attr(data-dinside-context-compact-text);
        display: block;
        white-space: pre-wrap;
        font: inherit;
        color: inherit;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaimode"],
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="chatgpt"],
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="notebooklm"],
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="qwen"],
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="zai"] {
        display: block !important;
        -webkit-box-orient: initial !important;
        -webkit-line-clamp: unset !important;
        line-clamp: unset !important;
        overflow: visible !important;
        font-size: 0 !important;
        line-height: 0 !important;
        color: transparent !important;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaistudio"] {
        font-size: 0 !important;
        line-height: 0 !important;
        color: transparent !important;
      }

      /* Meta clamps long user prompts and puts its ellipsis at the end. Render
       * the compact text before provider children so the clamp cannot hide it. */
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="metaai"] {
        display: block !important;
        -webkit-box-orient: initial !important;
        -webkit-line-clamp: unset !important;
        line-clamp: unset !important;
        height: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        overflow: visible !important;
        font-size: 0 !important;
        line-height: 0 !important;
        color: transparent !important;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="metaai"]::before {
        content: attr(data-dinside-context-compact-text);
        display: block;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        font-size: var(--dinside-context-compact-font-size, 16px);
        line-height: var(--dinside-context-compact-line-height, 1.4);
        font-family: inherit;
        font-weight: inherit;
        color: var(--dinside-context-compact-color, #f5f5f5);
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="metaai"]::after,
      *:has(> [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="metaai"])::after {
        content: none !important;
      }

      /* The native expand button sits beside the text in some Meta turns. */
      *:has(> [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="metaai"]) > [aria-expanded] {
        display: none !important;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="mimo"] {
        display: inline-block !important;
        -webkit-line-clamp: unset !important;
        line-clamp: unset !important;
        overflow: visible !important;
        font-size: 0 !important;
        line-height: 0 !important;
        color: transparent !important;
      }

      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaimode"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="googleaistudio"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="chatgpt"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="notebooklm"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="qwen"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="mimo"]::after,
      [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="zai"]::after {
        content: attr(data-dinside-context-compact-text);
        display: block;
        white-space: pre-wrap;
        font-size: var(--dinside-context-compact-font-size, 1rem);
        line-height: var(--dinside-context-compact-line-height, normal);
        font-family: inherit;
        font-weight: inherit;
        color: var(--dinside-context-compact-color, inherit);
      }

      /* ChatGPT keeps its long-message ellipsis and expand button outside the
       * rendered text. Both become redundant after Compact replaces that text. */
      [data-user-message-bubble="true"]:has([data-dinside-context-display-state="compact"]) span[aria-hidden="true"].block,
      [data-user-message-bubble="true"]:has([data-dinside-context-display-state="compact"]) button[aria-expanded] {
        display: none !important;
      }

      /* Qwen clamps the full injected prompt before DinSide compacts it. The
       * resulting WebKit line box can also clip the replacement ::after text,
       * while its native expand button remains floating over an empty bubble. */
      .chunked-text-renderer-root:has(
        > [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="qwen"]
      ) > .chat-user-message-expand-toggle,
      .chunked-text-renderer-root:has(
        > [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="qwen"]
      ) + .chunked-text-renderer-root-expand-toggle-mask {
        display: none !important;
      }

      /* Claude adds a screen-reader heading containing the raw first line of the
       * submitted prompt. Hide that duplicate marker only on DinSide-compacted
       * user turns so accessibility output matches the visible compact message. */
      [role="article"]:has(
        [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="claude"]
      ) h2[data-find-omitted] {
        display: none !important;
      }

      /* Gemini shows a native expand/collapse control because the hidden raw
       * DinSide prompt is still long. In Compact mode that control is redundant
       * and absolutely positioned over the short visible user text, so hide it
       * only for bubbles that DinSide has already compacted. */
      [data-test-id="luminous-expanded-bubble"]:has(
        [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="gemini"]
      ) > .luminous-toggle-container,
      [data-test-id="luminous-collapsed-bubble"]:has(
        [data-dinside-context-display-state="compact"][data-dinside-context-compact-provider="gemini"]
      ) > .luminous-toggle-container {
        display: none !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function normalizeContextDisplayMode(value) {
    return CONTEXT_DISPLAY_MODES.includes(value) ? value : 'compact';
  }

  function parseInjectedContextMessage(element) {
    if (!element) return null;

    const renderedText = String(element.innerText || element.textContent || '');
    if (
      provider.id === 'gemini' || provider.id === 'googleaimode' ||
      provider.id === 'notebooklm' || provider.id === 'kimi' ||
      provider.id === 'mimo' || provider.id === 'metaai' || provider.id === 'googleaistudio' || provider.id === 'zai' ||
      (provider.id === 'chatgpt' && DINSIDE_CONTEXT_MARKER_PATTERN.test(element.textContent || ''))
    ) {
      // Gemini and Google AI Mode can truncate long rendered prompts, while Kimi
      // can split or partially reconcile the synthetic prefix. For a turn DinSide
      // just sent, use the exact pre-injection user text we queued at Send.
      const pending = findPendingContextDisplayUserText(renderedText);
      if (pending) {
        return { userText: pending.text, pendingContextDisplayId: pending.id };
      }
    }

    let raw = renderedText;
    if (provider.id === 'claude') {
      // Claude prepends an sr-only "You said: ..." heading beside the actual
      // user-message node. Parsing the whole row sees [USER_MESSAGE] twice and
      // leaks the marker into Compact mode. Read the canonical user-message body.
      const userMessage = element.matches?.('[data-testid="user-message"]')
        ? element
        : element.querySelector?.('[data-testid="user-message"]');
      if (userMessage) raw = String(userMessage.innerText || userMessage.textContent || '');
    }
    if (provider.id === 'gemini') {
      // Historical turns do not have a pending exact copy. The accessibility
      // label is still usually less lossy than Gemini's collapsed visual summary,
      // so keep it as a best-effort fallback for chats loaded from history.
      const label = element.querySelector?.('.screen-reader-user-query-label');
      if (label) {
        const clone = label.cloneNode(true);
        clone.querySelector('span')?.remove();
        raw = String(clone.textContent || '');
      }
    }

    // ChatGPT can render the submitted prompt as rich text. Its innerText may
    // omit line breaks between blocks, while textContent still has the markers.
    if (['chatgpt', 'metaai', 'googleaistudio', 'zai'].includes(provider.id) && !DINSIDE_CONTEXT_START_PATTERN.test(raw)) {
      raw = String(element.textContent || raw);
    }

    const markerIndex = raw.indexOf(DINSIDE_USER_MESSAGE_MARKER);
    if (markerIndex < 0) {
      if (provider.id !== 'kimi') return null;

      // Best-effort repair for already-saved Kimi turns produced before the
      // pending-send fallback above was installed. In that DOM variant Kimi can
      // retain only a leading fragment such as "[USE" before the actual user
      // text, while the DinSide context marker remains intact.
      const normalizedRaw = raw.trimStart();
      const contextMarker = normalizedRaw.match(DINSIDE_CONTEXT_MARKER_PATTERN);
      if (!contextMarker || contextMarker.index == null) return null;
      const beforeContext = normalizedRaw.slice(0, contextMarker.index).trim();
      let sharedPrefixLength = 0;
      while (
        sharedPrefixLength < beforeContext.length &&
        sharedPrefixLength < DINSIDE_USER_MESSAGE_MARKER.length &&
        beforeContext[sharedPrefixLength] === DINSIDE_USER_MESSAGE_MARKER[sharedPrefixLength]
      ) {
        sharedPrefixLength += 1;
      }
      if (sharedPrefixLength < 4 || sharedPrefixLength >= DINSIDE_USER_MESSAGE_MARKER.length) return null;
      const repairedUserText = beforeContext.slice(sharedPrefixLength).trim();
      return repairedUserText ? { userText: repairedUserText } : null;
    }

    const afterMarker = raw.slice(markerIndex + DINSIDE_USER_MESSAGE_MARKER.length);
    const contextMatch = afterMarker.match(DINSIDE_CONTEXT_START_PATTERN)
      || (['chatgpt', 'metaai', 'googleaistudio', 'zai'].includes(provider.id)
        ? afterMarker.match(DINSIDE_CONTEXT_MARKER_PATTERN)
        : null);
    if (!contextMatch || contextMatch.index == null) return null;

    const userText = afterMarker.slice(0, contextMatch.index).trim();
    return userText ? { userText } : null;
  }

  function observeContextDisplayMutations() {
    if (!contextDisplayObserver || !document.documentElement) return;
    const options = {
      childList: true,
      subtree: true,
      characterData: true
    };
    if (provider.id === 'chatgpt') {
      options.attributes = true;
      options.attributeFilter = ['class', 'data-message-author-role'];
    }
    contextDisplayObserver.observe(document.documentElement, options);
  }

  function withContextDisplayObserverPaused(callback) {
    contextDisplayObserver?.disconnect();
    try {
      return callback();
    } finally {
      observeContextDisplayMutations();
    }
  }

  function isContextDisplayEditable(element) {
    return Boolean(element?.closest?.('textarea, input, [contenteditable="true"], [role="textbox"]'));
  }

  function restoreContextDisplayContainer(container) {
    if (!container) return;

    // These providers reconcile message children, so compaction is presentation-only.
    if (['gemini', 'googleaimode', 'googleaistudio', 'chatgpt', 'notebooklm', 'claude', 'openrouter', 'qwen', 'kimi', 'metaai', 'mimo', 'zai'].includes(container.dataset.dinsideContextCompactProvider)) {
      delete container.dataset.dinsideContextDisplayState;
      delete container.dataset.dinsideContextDisplayPending;
      delete container.dataset.dinsideContextCompactProvider;
      delete container.dataset.dinsideContextCompactText;
      container.style.removeProperty('--dinside-context-compact-font-size');
      container.style.removeProperty('--dinside-context-compact-line-height');
      container.style.removeProperty('--dinside-context-compact-color');
      return;
    }

    const original = [...container.children]
      .find((child) => child.dataset?.dinsideContextOriginal === 'true');
    if (!original) {
      delete container.dataset.dinsideContextDisplayState;
      delete container.dataset.dinsideContextDisplayPending;
      return;
    }

    withContextDisplayObserverPaused(() => {
      [...container.children]
        .filter((child) => child.dataset?.dinsideContextCompact === 'true')
        .forEach((child) => child.remove());
      while (original.firstChild) container.insertBefore(original.firstChild, original);
      original.remove();
      delete container.dataset.dinsideContextDisplayState;
      delete container.dataset.dinsideContextDisplayPending;
    });
  }

  function restoreAllContextMessages() {
    document.querySelectorAll('[data-dinside-context-display-state="compact"]')
      .forEach(restoreContextDisplayContainer);
    document.querySelectorAll('[data-dinside-context-display-pending="true"]')
      .forEach((container) => delete container.dataset.dinsideContextDisplayPending);
  }

  function compactContextDisplayContainer(container, parsed) {
    if (!container || !parsed?.userText || container.dataset.dinsideContextDisplayState === 'compact') return;
    if (isContextDisplayEditable(container)) return;

    if (provider.id === 'gemini' || provider.id === 'googleaimode' || provider.id === 'googleaistudio' || provider.id === 'chatgpt' || provider.id === 'notebooklm' || provider.id === 'claude' || provider.id === 'openrouter' || provider.id === 'qwen' || provider.id === 'kimi' || provider.id === 'metaai' || provider.id === 'mimo' || provider.id === 'zai') {
      // Do not insert or move framework-owned message children. Unknown data
      // attributes survive provider reconciliation, while an injected compact
      // child can be overwritten or can destroy provider bubble styling.
      let computed = getComputedStyle(container);
      if (provider.id === 'metaai') {
        // Meta's bubble wrapper can have 0px or transparent text while nested
        // spans carry the actual typography. Copy it from the prompt text.
        const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
        const probe = parsed.userText.slice(0, 24);
        for (let count = 0, node; count < 80 && (node = walker.nextNode()); count += 1) {
          const value = node.nodeValue || '';
          if (!value.includes(DINSIDE_USER_MESSAGE_MARKER) && !value.includes(probe)) continue;
          const candidate = getComputedStyle(node.parentElement);
          if (parseFloat(candidate.fontSize) >= 11 && candidate.color !== 'transparent' &&
              !/^rgba\([^)]*,\s*0(?:\.0+)?\)$/.test(candidate.color)) {
            computed = candidate;
            break;
          }
        }
      }
      // getComputedStyle() is live in Chromium. Snapshot these values before
      // adding the compact attributes, because Copilot's compact CSS immediately
      // changes the source node to 0px/transparent.
      const compactFontSize = provider.id === 'metaai' && parseFloat(computed.fontSize) < 11
        ? '16px' : computed.fontSize || '1rem';
      const compactLineHeight = provider.id === 'metaai' && parseFloat(computed.lineHeight) < 12
        ? '1.4' : computed.lineHeight || 'normal';
      const sourceColor = computed.color || '';
      const compactColor = provider.id === 'metaai' &&
        (!sourceColor || sourceColor === 'transparent' || /^rgba\([^)]*,\s*0(?:\.0+)?\)$/.test(sourceColor))
        ? getComputedStyle(document.body).color || '#f5f5f5'
        : sourceColor || 'inherit';
      container.dataset.dinsideContextDisplayState = 'compact';
      container.dataset.dinsideContextCompactProvider = provider.id;
      container.dataset.dinsideContextCompactText = parsed.userText;
      container.style.setProperty('--dinside-context-compact-font-size', compactFontSize);
      container.style.setProperty('--dinside-context-compact-line-height', compactLineHeight);
      container.style.setProperty('--dinside-context-compact-color', compactColor);
      if (provider.id === 'mimo' && parsed.pendingContextDisplayId) {
        consumePendingContextDisplayUserText(parsed.pendingContextDisplayId);
      }
      delete container.dataset.dinsideContextDisplayPending;
      return;
    }

    withContextDisplayObserverPaused(() => {
      container.dataset.dinsideContextDisplayState = 'compact';
      const original = document.createElement('span');
      original.dataset.dinsideContextOriginal = 'true';
      original.style.display = 'none';
      while (container.firstChild) original.appendChild(container.firstChild);

      const compact = document.createElement('span');
      compact.dataset.dinsideContextCompact = 'true';
      compact.style.whiteSpace = 'pre-wrap';
      compact.textContent = parsed.userText;
      container.append(original, compact);
      if (parsed.pendingContextDisplayId) consumePendingContextDisplayUserText(parsed.pendingContextDisplayId);
      delete container.dataset.dinsideContextDisplayPending;
    });
  }

  function findContextDisplayContainer(startNode) {
    if (!startNode?.parentElement) return null;
    // Provider page titles can temporarily mirror the raw submitted query. They
    // are metadata, not rendered chat turns, and must never be compacted/mutated.
    if (startNode.parentElement.closest('head, title, script, style, noscript')) return null;
    if (startNode.parentElement.closest('[data-dinside-context-display-state="compact"]')) return null;
    if (isContextDisplayEditable(startNode.parentElement)) return null;

    if (provider.id === 'gemini') {
      // Always compact Gemini at the stable query-text boundary. Compacting a
      // transient <p>/<h5> child can consume the queued userText and then be
      // replaced by Angular, leaving the final visual bubble unprotected.
      const queryHost = startNode.parentElement.closest('user-query-content');
      const queryText = queryHost?.querySelector('.query-text');
      if (queryText && !isContextDisplayEditable(queryText)) {
        const parsed = parseInjectedContextMessage(queryText);
        if (parsed) return { element: queryText, parsed };
      }
      return null;
    }

    if (provider.id === 'claude') {
      // Claude renders an sr-only heading plus a canonical user-message body in
      // each human transcript row. Compact only the body so the bubble layout,
      // actions, virtualization wrapper, and React-owned row remain untouched.
      const row = startNode.parentElement.closest('[data-testid="transcript-row"][data-perf-row="human"], [role="article"]');
      const userMessage = row?.querySelector?.('[data-testid="user-message"]');
      if (userMessage && !isContextDisplayEditable(userMessage)) {
        const parsed = parseInjectedContextMessage(userMessage);
        if (parsed) return { element: userMessage, parsed };
      }
      return null;
    }

    if (provider.id === 'deepseek') {
      const userMessage = startNode.parentElement.closest('.ds-message');
      if (userMessage && !isContextDisplayEditable(userMessage)) {
        const parsed = parseInjectedContextMessage(userMessage);
        if (parsed) return { element: userMessage, parsed };
      }
      return null;
    }

    if (provider.id === 'openrouter') {
      const userMessage = startNode.parentElement.closest('[data-testid="user-message"]');
      const userBubble = userMessage?.querySelector?.('[data-message-bubble="user"]') || userMessage;
      if (userBubble && !isContextDisplayEditable(userBubble)) {
        const parsed = parseInjectedContextMessage(userBubble);
        if (parsed) return { element: userBubble, parsed };
      }
      return null;
    }

    if (provider.id === 'copilot') {
      const userMessage = startNode.parentElement.closest('[data-content="user-message"]');
      if (userMessage && !isContextDisplayEditable(userMessage)) {
        const parsed = parseInjectedContextMessage(userMessage);
        if (parsed) return { element: userMessage, parsed };
      }
      return null;
    }

    if (provider.id === 'qwen') {
      const userRow = startNode.parentElement.closest('.qwen-chat-message-user');
      const userMessage = userRow?.querySelector?.('.user-message-content');
      if (userMessage && !isContextDisplayEditable(userMessage)) {
        const parsed = parseInjectedContextMessage(userMessage);
        if (parsed) return { element: userMessage, parsed };
      }
      return null;
    }

    if (provider.id === 'kimi') {
      const userRow = startNode.parentElement.closest('.chat-content-item-user, .segment-user');
      const userMessage = userRow?.querySelector?.('.user-content');
      if (userMessage && !isContextDisplayEditable(userMessage)) {
        const parsed = parseInjectedContextMessage(userMessage);
        if (parsed) return { element: userMessage, parsed };
      }
      return null;
    }

    if (provider.id === 'googleaistudio') {
      // AI Studio separates each user turn from its model response. Compact
      // only the text body, preserving the turn controls and chat scroller.
      const userTurn = startNode.parentElement.closest(
        'ms-chat-turn:has(.chat-turn-container.user), ms-chat-turn:has([data-turn-role="User"])'
      );
      const userText = userTurn?.querySelector('.user-prompt-container .turn-content') ||
        startNode.parentElement.closest('.chat-turn-container.user .turn-content');
      if (userText && !isContextDisplayEditable(userText)) {
        const parsed = parseInjectedContextMessage(userText);
        if (parsed) return { element: userText, parsed };
      }
      return null;
    }

    if (provider.id === 'mimo') {
      // MiMo's AutoLinkText splits a user prompt into text/link spans. A marker
      // may fit entirely in the first span while the page context lives in later
      // siblings, so compact the provider-owned bubble that contains all of it.
      const userBubble = startNode.parentElement.closest('.bg-mimo-bg-message.whitespace-pre-wrap');
      if (userBubble && !isContextDisplayEditable(userBubble)) {
        const parsed = parseInjectedContextMessage(userBubble);
        if (parsed) return { element: userBubble, parsed };
      }
      return null;
    }

    if (provider.id === 'zai') {
      const userRow = startNode.parentElement.closest('.user-message');
      const userBubble = userRow?.querySelector('.relative.overflow-hidden.rounded-xl');
      if (userBubble && !isContextDisplayEditable(userBubble)) {
        const parsed = parseInjectedContextMessage(userBubble);
        if (parsed) return { element: userBubble, parsed };
      }
      return null;
    }

    if (provider.id === 'metaai') {
      // Meta linkifies and splits long prompts into sibling text/link nodes.
      // The first parseable child can contain just the question; compacting it
      // leaves the rest of PAGE_CONTEXT visible. Walk to the smallest ancestor
      // containing the complete submitted prompt (or its final marker).
      let element = startNode.parentElement;
      let legacyCandidate = null;
      for (let depth = 0; element && element !== document.body && depth < 20; depth += 1) {
        if (isContextDisplayEditable(element)) return null;
        const raw = element.textContent || '';
        if (raw.includes(DINSIDE_USER_MESSAGE_MARKER) && DINSIDE_CONTEXT_MARKER_PATTERN.test(raw)) {
          const parsed = parseInjectedContextMessage(element);
          if (parsed) {
            const normalized = raw.replace(/\s+/g, ' ').trim();
            const pending = parsed.pendingContextDisplayId
              ? pendingContextDisplayUserTexts.find((entry) => entry.id === parsed.pendingContextDisplayId)
              : null;
            const fullPrompt = pending?.promptText?.replace(/\s+/g, ' ').trim();
            if (
              raw.includes(META_CONTEXT_END_MARKER) ||
              (fullPrompt && normalized.includes(fullPrompt))
            ) return { element, parsed };

            // Previously sent turns lack the final marker. Wait until every
            // context section visible in this candidate has its closing tag;
            // if its parent adds more sections from the same turn, use it.
            const sections = raw.match(META_CONTEXT_SECTION_PATTERN) || [];
            const opens = sections.filter((section) => !section.startsWith('[/'));
            const complete = opens.length > 0 && opens.every((section) =>
              sections.includes(`[/${section.slice(1)}`)
            );
            if (complete) {
              const parentRaw = element.parentElement?.textContent || '';
              const parentSections = parentRaw.match(META_CONTEXT_SECTION_PATTERN) || [];
              const sameTurn = parentRaw.split(DINSIDE_USER_MESSAGE_MARKER).length === 2;
              if (!sameTurn || parentSections.length === sections.length) {
                legacyCandidate = { element, parsed };
                break;
              }
            }
          }
        }
        element = element.parentElement;
      }
      return legacyCandidate;
    }

    const chatGptUserMessage = provider.id === 'chatgpt'
      ? startNode.parentElement.closest(CHATGPT_USER_MESSAGE_SELECTOR)
      : null;
    // ChatGPT's composer contains the exact injected prompt before Send. Only
    // mutate nodes that are already rendered inside a user-message turn; if the
    // provider changes this marker, fail safe by leaving the context visible.
    if (provider.id === 'chatgpt' && !chatGptUserMessage) return null;

    let element = startNode.parentElement;
    for (let depth = 0; element && element !== document.body && depth < 30; depth += 1) {
      if (isContextDisplayEditable(element)) return null;
      if (chatGptUserMessage && element === chatGptUserMessage && element.children.length) break;
      const parsed = parseInjectedContextMessage(element);
      if (parsed) return { element, parsed };
      if (chatGptUserMessage && element === chatGptUserMessage) break;
      element = element.parentElement;
    }
    return null;
  }

  function compactContextMessagesIn(root) {
    if (contextDisplayMode !== 'compact' || !root) return;
    const base = root.nodeType === Node.ELEMENT_NODE ? root : root.parentElement;
    if (!base?.isConnected) return;

    const walker = document.createTreeWalker(base, NodeFilter.SHOW_TEXT);
    const markerNodes = [];
    let node;
    while ((node = walker.nextNode())) {
      const text = node.nodeValue || '';
      // AI Mode can omit the leading marker; Meta can split it across text
      // nodes. Scan context markers too so the complete turn can be found.
      if (
        text.includes(DINSIDE_USER_MESSAGE_MARKER) ||
        (['googleaimode', 'googleaistudio', 'metaai', 'zai'].includes(provider.id) && DINSIDE_CONTEXT_MARKER_PATTERN.test(text))
      ) {
        markerNodes.push(node);
      }
    }

    for (const markerNode of markerNodes) {
      const found = findContextDisplayContainer(markerNode);
      if (found) compactContextDisplayContainer(found.element, found.parsed);
    }

    if (provider.id === 'chatgpt') {
      // The marker can be split among rich-text nodes. Scan complete user
      // turns and choose the narrowest available message body.
      const selector = CHATGPT_USER_MESSAGE_SELECTOR;
      const turns = new Set();
      if (base.matches?.(selector)) turns.add(base);
      const closest = base.closest?.(selector);
      if (closest) turns.add(closest);
      base.querySelectorAll?.(selector).forEach((element) => turns.add(element));

      for (const turn of turns) {
        if (turn.querySelector('[data-dinside-context-display-state="compact"]')) continue;
        const turnText = turn.textContent || '';
        if (!turnText.includes(DINSIDE_USER_MESSAGE_MARKER) || !DINSIDE_CONTEXT_MARKER_PATTERN.test(turnText)) continue;
        let candidate = turn;
        let parsed = parseInjectedContextMessage(candidate);
        if (!parsed) continue;
        for (let depth = 0; depth < 30; depth += 1) {
          const matchingChild = [...candidate.children]
            .map((child) => ({ element: child, parsed: parseInjectedContextMessage(child) }))
            .find((match) => match.parsed && !isContextDisplayEditable(match.element));
          if (!matchingChild) break;
          candidate = matchingChild.element;
          parsed = matchingChild.parsed;
        }
        // A broad turn wrapper also owns selection chips and action buttons.
        if (candidate === turn && turn.children.length) continue;
        compactContextDisplayContainer(candidate, parsed);
      }
    }

    if (provider.id === 'kimi') {
      // Kimi renders a submitted prompt through Vue into one or more child spans.
      // Scan the stable message body as a whole so compaction does not depend on
      // [USER_MESSAGE] surviving inside one individual text node.
      const selector = '.segment-user .user-content, .chat-content-item-user .user-content';
      const candidates = new Set();
      if (base.matches?.(selector)) candidates.add(base);
      const closest = base.closest?.(selector);
      if (closest) candidates.add(closest);
      base.querySelectorAll?.(selector).forEach((element) => candidates.add(element));

      for (const userMessage of candidates) {
        if (userMessage.dataset.dinsideContextDisplayState === 'compact') continue;
        if (isContextDisplayEditable(userMessage)) continue;
        const parsed = parseInjectedContextMessage(userMessage);
        if (parsed) compactContextDisplayContainer(userMessage, parsed);
      }
    }

    if (provider.id === 'googleaistudio') {
      const selector = 'ms-chat-turn .chat-turn-container.user .user-prompt-container .turn-content';
      const candidates = new Set();
      if (base.matches?.(selector)) candidates.add(base);
      const closest = base.closest?.(selector);
      if (closest) candidates.add(closest);
      base.querySelectorAll?.(selector).forEach((element) => candidates.add(element));
      for (const userText of candidates) {
        if (userText.dataset.dinsideContextDisplayState === 'compact') continue;
        if (isContextDisplayEditable(userText)) continue;
        const parsed = parseInjectedContextMessage(userText);
        if (parsed) compactContextDisplayContainer(userText, parsed);
      }
    }
  }

  function scheduleContextDisplayScan(root = document.body || document.documentElement) {
    if (contextDisplayMode !== 'compact' || !root) return;
    let element = root.nodeType === Node.ELEMENT_NODE ? root : root.parentElement;
    if (!element) return;

    // Scan a few ancestors so separately-rendered prompt/context blocks still meet
    // at their message container without ever scanning/replacing the whole page.
    for (let i = 0; i < 4 && element.parentElement && element.parentElement !== document.body; i += 1) {
      element = element.parentElement;
    }

    // Never hide a turn before parsing succeeds. Provider rendering is
    // asynchronous, so an incomplete DOM must remain visible and be retried by
    // later mutations instead of becoming a permanently hidden message.
    contextDisplayScanRoots.add(element);
    if (contextDisplayScanFrame) return;

    contextDisplayScanFrame = 1;
    queueMicrotask(() => {
      contextDisplayScanFrame = 0;
      const roots = [...contextDisplayScanRoots];
      contextDisplayScanRoots.clear();
      roots.forEach(compactContextMessagesIn);
    });
  }

  function applyContextDisplayMode(value) {
    contextDisplayMode = normalizeContextDisplayMode(value);
    if (contextDisplayMode === 'compact') scheduleContextDisplayScan(document.body || document.documentElement);
    else restoreAllContextMessages();
  }

  function installContextDisplayMode() {
    installContextDisplayGuardStyle();
    try {
      chrome.storage.local.get(['dinsideContextDisplayMode'])
        .then((saved) => applyContextDisplayMode(saved.dinsideContextDisplayMode))
        .catch(() => applyContextDisplayMode('visible'));
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== 'local' || !changes.dinsideContextDisplayMode) return;
        applyContextDisplayMode(changes.dinsideContextDisplayMode.newValue);
      });
    } catch (_) {
      applyContextDisplayMode('visible');
    }

    contextDisplayObserver = new MutationObserver((mutations) => {
      if (contextDisplayMode !== 'compact') return;
      for (const mutation of mutations) {
        if (mutation.type === 'attributes') {
          if (mutation.target.matches?.(CHATGPT_USER_MESSAGE_SELECTOR) ||
              mutation.target.closest?.(CHATGPT_USER_MESSAGE_SELECTOR)) {
            scheduleContextDisplayScan(mutation.target);
          }
          continue;
        }
        if (mutation.type === 'characterData') {
          scheduleContextDisplayScan(mutation.target.parentElement);
          continue;
        }
        for (const added of mutation.addedNodes) {
          scheduleContextDisplayScan(added);
        }
      }
    });
    observeContextDisplayMutations();
  }

  if (isEmbeddedProviderView) installContextDisplayMode();

  function normalizeSkillLifetime(value) {
    return SKILL_LIFETIME_ORDER.includes(value) ? value : 'chat';
  }

  function skillLifetimeLabel(value) {
    const lifetime = normalizeSkillLifetime(value);
    if (lifetime === 'once') return t('Once');
    if (lifetime === 'always') return t('Always');
    return t('Chat');
  }

  function skillLifetimeDescription(value) {
    const lifetime = normalizeSkillLifetime(value);
    if (lifetime === 'once') return t('This message');
    if (lifetime === 'always') return t('Always');
    return t('This chat');
  }

  function nextSkillLifetime(value) {
    const current = normalizeSkillLifetime(value);
    const index = SKILL_LIFETIME_ORDER.indexOf(current);
    return SKILL_LIFETIME_ORDER[(index + 1) % SKILL_LIFETIME_ORDER.length];
  }

  function sendRuntimeMessageSafely(message) {
    try {
      if (!chrome?.runtime?.id) return Promise.resolve(false);
      return chrome.runtime.sendMessage(message)
        .then(() => true)
        .catch(() => false);
    } catch (_) {
      // Old content scripts survive an extension reload, but their runtime
      // object is invalid. Treat that as disconnected instead of throwing.
      return Promise.resolve(false);
    }
  }

  function reportBridgeReady() {
    const message = {
      type: 'DINSIDE_BRIDGE_READY',
      version: DINSIDE_BRIDGE_VERSION,
      providerId: provider.id
    };
    window.parent.postMessage(message, '*');
    if (window.parent === window) {
      sendRuntimeMessageSafely({
        type: 'DINSIDE_EXTERNAL_BRIDGE_READY',
        version: DINSIDE_BRIDGE_VERSION,
        providerId: provider.id,
        url: location.href
      });
    }
  }

  reportBridgeReady();

  function findGoogleAiModeNarrowRail() {
    if (!isEmbeddedProviderView || provider.id !== 'googleaimode' || innerWidth > 520) return null;
    const sampleY = Math.max(80, Math.floor(innerHeight * .55));
    const candidates = [...new Set([
      ...document.elementsFromPoint?.(6, sampleY) || [],
      ...document.elementsFromPoint?.(24, sampleY) || []
    ])];
    const match = candidates
      .map((element) => ({ element, rect: element.getBoundingClientRect?.() }))
      .filter(({ rect }) => rect && rect.left <= 8 && rect.right >= 44 && rect.right <= 100 && rect.height >= innerHeight * .68)
      .sort((left, right) => left.rect.width - right.rect.width)[0];
    if (!match) return null;

    // elementsFromPoint may return a nested rail child. Hide the outermost
    // narrow full-height ancestor so its flex/grid parent can reclaim the slot.
    let rail = match.element;
    while (rail.parentElement && rail.parentElement !== document.body) {
      const parentRect = rail.parentElement.getBoundingClientRect?.();
      if (!parentRect || parentRect.left > 8 || parentRect.right > 110 || parentRect.height < innerHeight * .68) break;
      rail = rail.parentElement;
    }
    return rail;
  }

  if (provider.id === 'googleaimode' && isEmbeddedProviderView) {
    let layoutTimer = null;
    const repairGoogleAiModeLayout = () => {
      layoutTimer = null;
      const rail = findGoogleAiModeNarrowRail();
      if (!rail || rail.dataset.dinsideGoogleAiRail === 'fitted') return;
      const railRect = rail.getBoundingClientRect();
      const railWidth = Math.max(48, Math.min(88, Math.round(railRect.width)));
      const parent = rail.parentElement;
      const parentDisplay = parent ? getComputedStyle(parent).display : '';
      const content = parent
        ? Array.from(parent.children)
          .filter((child) => child !== rail)
          .map((element) => ({ element, rect: element.getBoundingClientRect?.() }))
          .filter(({ rect }) => rect && rect.width >= innerWidth * .5)
          .sort((left, right) => right.rect.width - left.rect.width)[0]?.element
        : null;
      rail.dataset.dinsideGoogleAiRail = 'fitted';
      rail.style.removeProperty('display');
      rail.style.setProperty('flex', `0 0 ${railWidth}px`, 'important');
      if (parent) {
        parent.style.setProperty('min-width', '0', 'important');
        parent.style.setProperty('width', '100%', 'important');
        parent.style.setProperty('max-width', '100vw', 'important');
        parent.style.setProperty('overflow-x', 'hidden', 'important');
        if (parentDisplay.includes('grid')) {
          parent.style.setProperty('grid-template-columns', `${railWidth}px minmax(0, 1fr)`, 'important');
        }
      }
      if (content) {
        content.dataset.dinsideGoogleAiContent = 'fitted';
        content.style.setProperty('min-width', '0', 'important');
        content.style.setProperty('width', 'auto', 'important');
        content.style.setProperty('max-width', `calc(100vw - ${railWidth}px)`, 'important');
        content.style.setProperty('flex', '1 1 0%', 'important');
        content.style.setProperty('overflow-x', 'hidden', 'important');
        let responsiveStyle = document.getElementById('__dinside_google_ai_narrow_layout__');
        if (!responsiveStyle) {
          responsiveStyle = document.createElement('style');
          responsiveStyle.id = '__dinside_google_ai_narrow_layout__';
          responsiveStyle.textContent = `
            [data-dinside-google-ai-content="fitted"],
            [data-dinside-google-ai-content="fitted"] * {
              min-width: 0 !important;
              max-width: 100% !important;
              box-sizing: border-box !important;
            }
          `;
          (document.head || document.documentElement).appendChild(responsiveStyle);
        }
      }
      document.documentElement.style.setProperty('overflow-x', 'hidden', 'important');
      document.body?.style.setProperty('max-width', '100vw', 'important');
    };
    const scheduleGoogleAiModeLayout = () => {
      if (!layoutTimer) layoutTimer = setTimeout(repairGoogleAiModeLayout, 80);
    };
    repairGoogleAiModeLayout();
    window.addEventListener('resize', scheduleGoogleAiModeLayout);
    const layoutObserver = new MutationObserver(scheduleGoogleAiModeLayout);
    layoutObserver.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => layoutObserver.disconnect(), 10000);
  }

  let guestAuthDismissUntil = 0;

  function isChatGptGuestMode() {
    if (provider.id !== 'chatgpt') return false;
    return [...document.querySelectorAll('a[href], button')].some((candidate) => {
      const labels = [
        candidate.textContent || '',
        candidate.getAttribute('aria-label') || ''
      ].map((value) => value.replace(/\s+/g, ' ').trim()).filter(Boolean);
      if (!labels.some((label) => /^(?:log in|login|sign in|sign up)$/i.test(label))) return false;
      const rect = candidate.getBoundingClientRect?.();
      const style = getComputedStyle(candidate);
      return Boolean(rect && rect.width >= 2 && rect.height >= 2 && style.display !== 'none' && style.visibility !== 'hidden');
    });
  }

  function armGuestAuthDismiss() {
    if (isChatGptGuestMode()) guestAuthDismissUntil = Date.now() + 5000;
  }

  function dismissOptionalChatGptAuthDialogs(root = document) {
    if (provider.id !== 'chatgpt' || Date.now() > guestAuthDismissUntil || !root?.querySelectorAll) return false;

    const dialogs = [];
    if (root.matches?.('[role="dialog"], [data-state="open"]')) dialogs.push(root);
    dialogs.push(...root.querySelectorAll('[role="dialog"], [data-state="open"]'));

    for (const dialog of dialogs) {
      if (dialog.getAttribute('aria-hidden') === 'true') continue;
      const rect = dialog.getBoundingClientRect?.();
      const style = getComputedStyle(dialog);
      if (!rect || rect.width < 2 || rect.height < 2 || style.display === 'none' || style.visibility === 'hidden') continue;

      const text = (dialog.innerText || dialog.textContent || '').replace(/\s+/g, ' ').trim();
      if (!/\b(?:log in|login|sign in|sign up|create account)\b/i.test(text)) continue;

      const dismiss = [...dialog.querySelectorAll('button, [role="button"]')].find((button) => {
        const labels = [
          button.textContent || '',
          button.getAttribute('aria-label') || '',
          button.getAttribute('title') || ''
        ].map((value) => value.replace(/\s+/g, ' ').trim()).filter(Boolean);
        const isDismissAction = labels.some((label) =>
          /^(?:close|not now|maybe later|skip|continue as guest|continue without (?:logging|signing) in|continue without (?:an )?account)$/i.test(label)
        );
        if (!isDismissAction) return false;
        const buttonRect = button.getBoundingClientRect?.();
        const buttonStyle = getComputedStyle(button);
        return Boolean(
          buttonRect &&
          buttonRect.width >= 2 &&
          buttonRect.height >= 2 &&
          buttonStyle.display !== 'none' &&
          buttonStyle.visibility !== 'hidden' &&
          !button.disabled
        );
      });

      if (!dismiss) continue;
      dismiss.click();
      console.info('[DinSide bridge] dismissed optional ChatGPT sign-in prompt for guest mode');
      return true;
    }

    return false;
  }

  if (provider.id === 'chatgpt' && isEmbeddedProviderView) {
    let optionalAuthDismissQueued = false;
    const scheduleOptionalAuthDismiss = (root) => {
      if (optionalAuthDismissQueued) return;
      optionalAuthDismissQueued = true;
      queueMicrotask(() => {
        optionalAuthDismissQueued = false;
        dismissOptionalChatGptAuthDialogs(root?.isConnected ? root : document);
      });
    };
    const optionalAuthObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'attributes') {
          const target = mutation.target;
          if (target?.matches?.('[role="dialog"], [data-state="open"]')) {
            scheduleOptionalAuthDismiss(target);
            return;
          }
          continue;
        }

        for (const added of mutation.addedNodes) {
          if (added.nodeType !== Node.ELEMENT_NODE) continue;
          if (added.matches?.('[role="dialog"], [data-state="open"]') || added.querySelector?.('[role="dialog"], [data-state="open"]')) {
            scheduleOptionalAuthDismiss(added);
            return;
          }
        }
      }
    });
    optionalAuthObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['role', 'data-state', 'aria-hidden']
    });
  }

  function dismissOpenRouterCreditsDialog(root = document) {
    if (provider.id !== 'openrouter' || !isEmbeddedProviderView || !root?.querySelectorAll) return false;

    const dialogs = [];
    if (root.matches?.('[role="dialog"]')) dialogs.push(root);
    dialogs.push(...root.querySelectorAll('[role="dialog"]'));

    for (const dialog of dialogs) {
      if (dialog.getAttribute('aria-hidden') === 'true') continue;
      const rect = dialog.getBoundingClientRect?.();
      const style = getComputedStyle(dialog);
      if (!rect || rect.width < 2 || rect.height < 2 || style.display === 'none' || style.visibility === 'hidden') continue;

      const text = (dialog.innerText || dialog.textContent || '').replace(/\s+/g, ' ').trim();
      if (!/\binsufficient credits\b/i.test(text) || !/\badd credits to continue using paid models\b/i.test(text)) continue;

      const dismiss = [...dialog.querySelectorAll('button, [role="button"]')].find((button) => {
        const labels = [
          button.textContent || '',
          button.getAttribute('aria-label') || '',
          button.getAttribute('title') || '',
          button.getAttribute('data-testid') || '',
          button.getAttribute('data-slot') || ''
        ].map((value) => value.replace(/\s+/g, ' ').trim()).filter(Boolean);
        if (!labels.some((label) => /^(?:close|dismiss|dialog-close|modal-close)$/i.test(label))) return false;

        const buttonRect = button.getBoundingClientRect?.();
        const buttonStyle = getComputedStyle(button);
        return Boolean(
          buttonRect &&
          buttonRect.width >= 2 &&
          buttonRect.height >= 2 &&
          buttonStyle.display !== 'none' &&
          buttonStyle.visibility !== 'hidden' &&
          !button.disabled
        );
      });

      if (!dismiss) continue;
      dismiss.click();
      console.info('[DinSide bridge] dismissed OpenRouter insufficient-credits notice');
      return true;
    }

    return false;
  }

  if (provider.id === 'openrouter' && isEmbeddedProviderView) {
    let creditsDismissQueued = false;
    const scheduleCreditsDismiss = (root = document) => {
      if (creditsDismissQueued) return;
      creditsDismissQueued = true;
      queueMicrotask(() => {
        creditsDismissQueued = false;
        dismissOpenRouterCreditsDialog(root?.isConnected ? root : document);
      });
    };

    scheduleCreditsDismiss();
    const creditsDialogObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'attributes') {
          const target = mutation.target;
          if (target?.matches?.('[role="dialog"]')) {
            scheduleCreditsDismiss(target);
            return;
          }
          continue;
        }

        for (const added of mutation.addedNodes) {
          const element = added.nodeType === Node.ELEMENT_NODE ? added : added.parentElement;
          if (!element) continue;
          const dialog = element.matches?.('[role="dialog"]')
            ? element
            : element.querySelector?.('[role="dialog"]') || element.closest?.('[role="dialog"]');
          if (!dialog) continue;
          scheduleCreditsDismiss(dialog);
          return;
        }
      }
    });
    creditsDialogObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['role', 'aria-hidden']
    });
  }

  function installDinSideTheme() {
    if (document.getElementById('__dinside_theme__')) return;

    const style = document.createElement('style');
    style.id = '__dinside_theme__';
    style.textContent = `
      /* Keep the embedded provider scrollbar visually consistent with DinSide. */
      * {
        scrollbar-color: rgba(255, 255, 255, 0.14) transparent;
      }

      *::-webkit-scrollbar {
        width: 8px;
        height: 8px;
      }

      *::-webkit-scrollbar-track {
        background: transparent;
      }

      *::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.14);
        border: 2px solid transparent;
        background-clip: padding-box;
        border-radius: 999px;
      }

      *::-webkit-scrollbar-thumb:hover {
        background: rgba(255, 255, 255, 0.24);
        background-clip: padding-box;
      }

      *::-webkit-scrollbar-thumb:active {
        background: rgba(255, 255, 255, 0.32);
        background-clip: padding-box;
      }

      *::-webkit-scrollbar-corner {
        background: transparent;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  if (isEmbeddedProviderView) installDinSideTheme();

  function installQwenEmbeddedLayout() {
    if (provider.id !== 'qwen' || !isEmbeddedProviderView) return;
    if (document.getElementById('__dinside_qwen_embedded_layout__')) return;

    const style = document.createElement('style');
    style.id = '__dinside_qwen_embedded_layout__';
    style.textContent = `
      @media (max-width: 720px) {
        html,
        body,
        #root {
          width: 100% !important;
          max-width: 100% !important;
          min-width: 0 !important;
          overflow-x: hidden !important;
        }

        /* Keep Qwen's native sidebar toggle, but take the sidebar out of the
         * document flow so its collapsed rail does not consume scarce width.
         * Opening it uses Qwen's normal control and overlays the conversation. */
        .sidebar-wrapper {
          position: fixed !important;
          inset: 0 auto 0 0 !important;
          width: 0 !important;
          z-index: 1000 !important;
        }

        .sidebar-wrapper .sidebar {
          position: fixed !important;
          inset: 0 auto 0 0 !important;
          width: min(260px, calc(100vw - 24px)) !important;
          max-width: calc(100vw - 24px) !important;
          box-shadow: 10px 0 28px rgba(0, 0, 0, .28);
        }

        .sidebar-wrapper .sidebar-collapse,
        .sidebar-wrapper .sidebar-floating-collapse {
          width: 0 !important;
          max-width: 0 !important;
          overflow: hidden !important;
          box-shadow: none;
        }

        .sidebar-wrapper .sidebar-float-placeholder {
          display: none !important;
        }

        #__dinside_qwen_sidebar_toggle__ {
          position: fixed;
          top: 10px;
          left: 10px;
          z-index: 1001;
          width: 32px;
          height: 32px;
          display: none;
          place-items: center;
          padding: 0;
          border: 1px solid var(--line-heavier, rgba(255, 255, 255, .1));
          border-radius: 9px;
          background: var(--background-capsule, rgba(32, 32, 32, .92));
          color: var(--text-primary, currentColor);
          box-shadow: 0 4px 14px rgba(0, 0, 0, .18);
          cursor: pointer;
        }

        html:has(.sidebar-wrapper .sidebar-collapse, .sidebar-wrapper .sidebar-floating-collapse)
          #__dinside_qwen_sidebar_toggle__ {
          display: grid;
        }

        html:has(.sidebar-wrapper .sidebar-collapse, .sidebar-wrapper .sidebar-floating-collapse)
          #qwen-chat-header-left {
          min-width: 0;
          margin-left: 40px;
        }

        /* Qwen's desktop model menu is fixed at 380px and opens from the model
         * trigger rather than the viewport edge. Constrain it to the remaining
         * side-panel width and truncate long model metadata cleanly. */
        .wms-popup {
          width: min(300px, calc(100vw - 76px)) !important;
          max-width: calc(100vw - 24px) !important;
          box-sizing: border-box !important;
        }

        .wms-popup__inner,
        .wms-intro__content,
        .wms-list__item,
        .wms-list__name,
        .wms-list__name-row,
        .wms-list__name-info {
          min-width: 0 !important;
          max-width: 100% !important;
        }

        /* The secondary list is positioned 384px to the right by Qwen's desktop
         * menu. Overlay it on the primary popup instead, so hover remains usable
         * inside a narrow iframe. */
        .wms-popup .ant-dropdown:has(.wms-popup--secondary),
        .wms-popup .qwen-chat-v2-dropdown-menu-popup:has(> .wms-popup--secondary) {
          inset: 0 auto auto 0 !important;
          top: 0 !important;
          right: auto !important;
          bottom: auto !important;
          left: 0 !important;
          transform: none !important;
        }

        .wms-popup--secondary {
          width: min(300px, calc(100vw - 76px)) !important;
          min-width: min(300px, calc(100vw - 76px)) !important;
          max-width: calc(100vw - 24px) !important;
          box-sizing: border-box !important;
        }

        .wms-intro__battle {
          flex: 0 0 auto;
        }

        .wms-list__name-text,
        .wms-list__desc {
          display: block;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        #__dinside_qwen_sidebar_toggle__:hover {
          background: var(--background-option, rgba(255, 255, 255, .1));
        }

        #__dinside_qwen_sidebar_toggle__:focus-visible {
          outline: 2px solid var(--text-theme, #315cff);
          outline-offset: 2px;
        }

        .desktop-layout,
        .desktop-layout .desktop-layout-content,
        .desktop-layout .desktop-layout-content-inner,
        .desktop-layout .desktop-layout-content-chat-panel,
        .desktop-layout .layout-main,
        .splitter-container,
        .splitter-container-left-panel,
        .home-page-layout-main,
        .main-content {
          width: 100% !important;
          max-width: 100% !important;
          min-width: 0 !important;
          box-sizing: border-box !important;
        }

        .desktop-layout .desktop-layout-content {
          overflow-x: hidden !important;
        }

        /* Qwen's desktop shell puts 6px of sidebar-colored padding around the
         * chat. It appears as dark gaps on three sides of this narrow frame. */
        .desktop-layout .desktop-layout-content-inner {
          padding: 0 !important;
        }

        .desktop-layout .layout-main,
        .desktop-layout .splitter-container,
        .desktop-layout .splitter-container-left-panel {
          border-radius: 0 !important;
        }

        .message-input-wrapper,
        .qwen-chat-message,
        .placeholder-logo-pc-container,
        .placeholder-logo-pc-container-multi-model {
          max-width: 100% !important;
          min-width: 0 !important;
          box-sizing: border-box !important;
        }
      }
    `;
    (document.head || document.documentElement).appendChild(style);

    const sidebarToggle = document.createElement('button');
    sidebarToggle.id = '__dinside_qwen_sidebar_toggle__';
    sidebarToggle.type = 'button';
    sidebarToggle.title = 'Open Qwen sidebar';
    sidebarToggle.setAttribute('aria-label', 'Open Qwen sidebar');
    sidebarToggle.innerHTML = `
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" aria-hidden="true">
        <rect x="3" y="4" width="18" height="16" rx="2.5" stroke="currentColor" stroke-width="1.7" />
        <path d="M8 4v16M12 9l3 3-3 3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" />
      </svg>
    `;
    sidebarToggle.addEventListener('click', () => {
      document.querySelector('.sidebar-side-fold-container-open')?.click();
    });
    (document.body || document.documentElement).appendChild(sidebarToggle);
  }

  installQwenEmbeddedLayout();

  function installKimiEmbeddedLayout() {
    if (provider.id !== 'kimi' || !isEmbeddedProviderView) return;
    if (document.getElementById('__dinside_kimi_embedded_layout__')) return;

    const style = document.createElement('style');
    style.id = '__dinside_kimi_embedded_layout__';
    style.textContent = `
      @media (max-width: 720px) {
        html,
        body,
        #app,
        .app {
          width: 100% !important;
          max-width: 100% !important;
          min-width: 0 !important;
          overflow-x: clip !important;
        }

        /* Kimi's desktop shell currently enforces a 375px minimum width. The
         * DinSide iframe can be narrower, which otherwise creates a page-level
         * horizontal scrollbar even though the chat itself is responsive. */
        .app .main,
        .layout-container,
        .layout-content,
        .layout-content-body,
        .landing-area,
        .chat-page,
        .chat-detail-content,
        .chat-detail-main,
        .chat-content-container,
        .chat-editor {
          box-sizing: border-box !important;
          width: 100% !important;
          max-width: 100% !important;
          min-width: 0 !important;
        }
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  installKimiEmbeddedLayout();

  function installGeminiEmbeddedLayout() {
    if (provider.id !== 'gemini' || !isEmbeddedProviderView) return;
    const style = document.createElement('style');
    style.id = '__dinside_gemini_embedded_layout__';
    style.textContent = `
      @media (max-width: 720px) {
        html, body { max-width: 100% !important; overflow-x: hidden !important; }
        .input-area-container, .input-area, .input-area-inner-container,
        .text-input-field, rich-textarea {
          box-sizing: border-box !important;
          min-width: 0 !important;
          max-width: 100% !important;
        }
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  installGeminiEmbeddedLayout();

  if (provider.id === 'googleaistudio' && isEmbeddedProviderView) {
    const style = document.createElement('style');
    style.id = '__dinside_google_ai_studio_embedded_layout__';
    style.textContent = `
      @media (max-width: 720px) {
        html, body { max-width: 100% !important; overflow-x: hidden !important; }
        ms-prompt-box, ms-prompt-input-wrapper, .prompt-box-container {
          box-sizing: border-box !important;
          min-width: 0 !important;
          max-width: 100% !important;
        }
        ms-playground-toolbar button.runsettings-toggle-button {
          flex: 0 0 32px !important;
          width: 32px !important;
          min-width: 32px !important;
        }
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function detectProviderTheme() {
    const candidates = [document.body, document.documentElement].filter(Boolean);

    // Z.ai sets its resolved theme on html before the app renders. Its body
    // background can disagree with the visible theme in an embedded frame.
    if (provider.id === 'zai') {
      const root = document.documentElement.classList;
      if (root.contains('light')) return 'light';
      if (root.contains('dark')) return 'dark';
    }

    // Copilot (and some provider variants) declares the resolved theme on the
    // root element while leaving body/html backgrounds transparent.
    for (const node of candidates) {
      const declared = String(
        node.getAttribute('data-theme') || node.getAttribute('data-color-scheme') || ''
      ).toLowerCase();
      if (declared === 'light' || declared === 'dark') return declared;
    }

    for (const node of candidates) {
      const bg = getComputedStyle(node).backgroundColor;
      const match = bg?.match(/rgba?\(\s*(\d+)[, ]+\s*(\d+)[, ]+\s*(\d+)/i);
      if (!match || bg === 'rgba(0, 0, 0, 0)') continue;
      const [r, g, b] = match.slice(1, 4).map(Number);
      const luminance = (0.2126 * r) + (0.7152 * g) + (0.0722 * b);
      return luminance >= 128 ? 'light' : 'dark';
    }

    const rootClass = document.documentElement.className || '';
    if (/\bdark\b/i.test(rootClass)) return 'dark';
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  let lastReportedTheme = '';
  function reportProviderTheme(force = false) {
    const theme = detectProviderTheme();
    if (!force && theme === lastReportedTheme) return;
    const changed = theme !== lastReportedTheme;
    lastReportedTheme = theme;
    window.parent.postMessage({ type: 'DINSIDE_PROVIDER_THEME', theme }, '*');

    // DinSide cards live inside the provider DOM, so repaint them when the
    // provider switches light/dark without waiting for the next selection.
    if (changed) {
      requestAnimationFrame(() => {
        if (selectedTextContexts.length) renderSelectedTextCard();
        if (skillsContext.length) renderSkillsCard();
      });
    }
  }

  reportProviderTheme(true);
  const themeObserver = new MutationObserver(() => requestAnimationFrame(() => reportProviderTheme()));
  themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'style', 'data-theme'] });
  if (document.body) themeObserver.observe(document.body, { attributes: true, attributeFilter: ['class', 'style', 'data-theme'] });
  window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', () => reportProviderTheme(true));
  let lastReportedChatUrl = '';
  function reportChatUrl(force = false) {
    const url = location.href;
    if (!force && url === lastReportedChatUrl) return;
    lastReportedChatUrl = url;
    window.parent.postMessage({ type: 'DINSIDE_CHAT_URL', providerId: provider.id, url }, '*');
    // Persist through the service worker as well. This also covers providers
    // that run in a normal browser tab instead of the embedded side-panel frame.
    sendRuntimeMessageSafely({
      type: 'DINSIDE_CHAT_URL_CHANGED',
      providerId: provider.id,
      url
    });
  }

  reportChatUrl(true);
  window.addEventListener('popstate', () => setTimeout(() => reportChatUrl(true), 0));
  window.addEventListener('message', (event) => {
    if (event.data?.type === 'DINSIDE_REQUEST_THEME') reportProviderTheme(true);
    if (event.data?.type === 'DINSIDE_REQUEST_CHAT_URL') reportChatUrl(true);
    if (event.data?.type === 'DINSIDE_REQUEST_BRIDGE_STATUS') reportBridgeReady();
  });
  setInterval(() => reportChatUrl(), 1000);

  function hideProviderDisclaimer() {
    const needle = String(provider.disclaimer || '').replace(/\s+/g, ' ').trim();
    const pattern = provider.disclaimerPattern instanceof RegExp ? provider.disclaimerPattern : null;
    if (!needle && !pattern) return;
    for (const el of document.querySelectorAll('div, p, span, small')) {
      const text = String(el.textContent || '').replace(/\s+/g, ' ').trim();
      if (text !== needle && !pattern?.test(text)) continue;
      const row = el.closest('div');
      (row || el).style.setProperty('display', 'none', 'important');
    }
  }
  // ChatGPT can mount a long conversation in many batches. Re-scanning every
  // element for a cosmetic disclaimer after each batch can starve hydration.
  if (isEmbeddedProviderView && provider.id !== 'chatgpt') hideProviderDisclaimer();
  if (isEmbeddedProviderView && provider.id !== 'chatgpt' && provider.disclaimer) {
    const disclaimerObserver = new MutationObserver(hideProviderDisclaimer);
    disclaimerObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  function declinePerplexityOptionalCookies() {
    if (provider.id !== 'perplexity') return false;
    const declineButton = [...document.querySelectorAll('button')].find((button) => {
      const text = (button.textContent || '').trim();
      const aria = (button.getAttribute('aria-label') || '').trim();
      if (!/^decline optional$/i.test(text) && !/^decline optional$/i.test(aria)) return false;
      const rect = button.getBoundingClientRect?.();
      if (!rect || rect.width < 2 || rect.height < 2) return false;
      const style = getComputedStyle(button);
      return style.display !== 'none' && style.visibility !== 'hidden';
    });
    if (!declineButton) return false;
    declineButton.click();
    return true;
  }

  if (provider.id === 'perplexity' && !declinePerplexityOptionalCookies()) {
    const cookiePolicyObserver = new MutationObserver(() => {
      if (declinePerplexityOptionalCookies()) cookiePolicyObserver.disconnect();
    });
    cookiePolicyObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  function rejectCopilotOptionalCookies() {
    if (provider.id !== 'copilot' || !isEmbeddedProviderView) return false;

    const exact = document.querySelector('button[data-testid="cookie-banner-reject-button"]');
    const rejectButton = exact || [...document.querySelectorAll('button')].find((button) => {
      const label = `${button.textContent || ''} ${button.getAttribute('aria-label') || ''}`
        .replace(/\s+/g, ' ')
        .trim();
      if (!/^(?:reject)(?: reject)?$/i.test(label)) return false;

      let container = button.parentElement;
      for (let depth = 0; container && depth < 6; depth += 1, container = container.parentElement) {
        const text = (container.innerText || container.textContent || '').replace(/\s+/g, ' ').trim();
        if (/we value your privacy/i.test(text) && /more options/i.test(text)) return true;
      }
      return false;
    });

    if (!rejectButton || rejectButton.disabled) return false;
    const rect = rejectButton.getBoundingClientRect?.();
    const style = getComputedStyle(rejectButton);
    if (!rect || rect.width < 2 || rect.height < 2 || style.display === 'none' || style.visibility === 'hidden') return false;

    rejectButton.click();
    console.info('[DinSide bridge] rejected optional Microsoft Copilot cookies');
    return true;
  }

  if (provider.id === 'copilot' && isEmbeddedProviderView && !rejectCopilotOptionalCookies()) {
    const copilotCookieObserver = new MutationObserver(() => {
      if (rejectCopilotOptionalCookies()) copilotCookieObserver.disconnect();
    });
    copilotCookieObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  const COMPOSER_SELECTOR = provider.composerSelectors.join(', ');

  function isVisibleComposer(node) {
    if (!node?.matches?.(COMPOSER_SELECTOR)) return false;
    const rect = node.getBoundingClientRect?.();
    if (!rect || rect.width < 2 || rect.height < 2) return false;
    const style = getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    if (provider.id === 'metaai') {
      // Meta keeps a textarea mirror beside its visible editor. The mirror is
      // useful for injecting text but must not anchor Selected Text cards.
      return Number(style.opacity || 1) > 0.05 && rect.bottom > 0 &&
        rect.top < window.innerHeight && rect.right > 0 && rect.left < window.innerWidth;
    }
    if (provider.id === 'googleaistudio') {
      return Number(style.opacity || 1) > 0.05 && rect.bottom > 0 &&
        rect.top < window.innerHeight && rect.right > 0 && rect.left < window.innerWidth;
    }
    return true;
  }

  function getComposer(preferredTarget = null) {
    // Google Search and AI Mode share an origin and can switch tabs without a
    // document navigation. Never intercept the regular Search composer after
    // the embedded view leaves an AI Mode route.
    if (!isCurrentProviderLocation()) return null;
    if (provider.id === 'googleaistudio') {
      const promptFields = [...document.querySelectorAll(
        'ms-prompt-box textarea, ms-prompt-box [contenteditable="true"], ' +
        '.prompt-box-container textarea, .prompt-box-container [contenteditable="true"], ' +
        'ms-prompt-input-wrapper textarea'
      )].filter(isVisibleComposer);
      if (promptFields.length) return promptFields.at(-1);
    }
    const preferred = preferredTarget?.matches?.(COMPOSER_SELECTOR)
      ? preferredTarget
      : preferredTarget?.closest?.(COMPOSER_SELECTOR);
    if (preferred && isVisibleComposer(preferred)) return preferred;

    const active = document.activeElement?.matches?.(COMPOSER_SELECTOR)
      ? document.activeElement
      : document.activeElement?.closest?.(COMPOSER_SELECTOR);
    if (active && isVisibleComposer(active)) return active;

    const visible = [...document.querySelectorAll(COMPOSER_SELECTOR)].filter(isVisibleComposer);
    if (visible.length) return provider.preferLastComposer ? visible.at(-1) : visible[0];
    const candidates = [...document.querySelectorAll(COMPOSER_SELECTOR)];
    return provider.preferLastComposer ? candidates.at(-1) || null : candidates[0] || null;
  }

  if (provider.id === 'deepseek' && isEmbeddedProviderView) {
    let stableSince = 0;
    let lastBounds = '';
    let reported = false;
    const startedAt = performance.now();
    const checkDeepSeekReady = () => {
      if (reported) return;
      if (performance.now() - startedAt > 30000) {
        clearInterval(timer);
        return;
      }

      const candidate = [...document.querySelectorAll(
        '.ds-sign-in-form__social-link, textarea[placeholder*="DeepSeek"], textarea, [contenteditable="true"][role="textbox"]'
      )].find((element) => {
        const rect = element?.getBoundingClientRect?.();
        if (!rect || rect.width < 20 || rect.height < 10) return false;
        const style = getComputedStyle(element);
        return style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) > 0;
      });
      if (!candidate) {
        stableSince = 0;
        lastBounds = '';
        return;
      }

      const bounds = candidate.getBoundingClientRect();
      const signature = `${Math.round(bounds.left)}:${Math.round(bounds.top)}:${Math.round(bounds.width)}:${Math.round(bounds.height)}`;
      if (signature !== lastBounds) {
        lastBounds = signature;
        stableSince = performance.now();
        return;
      }
      if (performance.now() - stableSince < 250) return;

      reported = true;
      clearInterval(timer);
      window.parent.postMessage({ type: 'DINSIDE_PROVIDER_UI_READY', providerId: 'deepseek' }, '*');
    };
    const timer = setInterval(checkDeepSeekReady, 120);
    checkDeepSeekReady();
  }

  if (provider.id === 'gemini' && isEmbeddedProviderView) {
    let stableSince = 0;
    let lastBounds = '';
    let reported = false;
    const startedAt = performance.now();
    const checkGeminiReady = () => {
      if (reported) return;
      if (performance.now() - startedAt > 30000) {
        clearInterval(timer);
        return;
      }
      const composer = [...document.querySelectorAll(
        'rich-textarea [contenteditable="true"], [aria-label="Enter a prompt for Gemini"][contenteditable="true"], [contenteditable="true"][role="textbox"]'
      )].find(isVisibleComposer);
      if (!isVisibleComposer(composer)) {
        stableSince = 0;
        lastBounds = '';
        return;
      }

      const viewportWidth = document.documentElement.clientWidth || innerWidth;
      const field = composer.closest('.text-input-field') || composer;
      let bounds = field.getBoundingClientRect();
      if (bounds.right > viewportWidth + 2 && viewportWidth <= 720) {
        stableSince = 0;
        lastBounds = '';
        // Gemini can keep a desktop minimum width while its narrow layout mounts.
        for (let node = field, depth = 0; node && node !== document.body && depth < 7; node = node.parentElement, depth += 1) {
          const rect = node.getBoundingClientRect();
          if (rect.right <= viewportWidth + 2 || rect.left >= viewportWidth - 160) continue;
          node.style.setProperty('min-width', '0', 'important');
          node.style.setProperty('max-width', `${Math.max(160, Math.floor(viewportWidth - rect.left - 8))}px`, 'important');
          node.style.setProperty('box-sizing', 'border-box', 'important');
        }
        bounds = field.getBoundingClientRect();
      }

      if (bounds.left < -2 || bounds.right > viewportWidth + 2 || bounds.width < 160) {
        stableSince = 0;
        lastBounds = '';
        return;
      }
      const signature = `${Math.round(bounds.left)}:${Math.round(bounds.right)}:${Math.round(bounds.bottom)}`;
      if (signature !== lastBounds) {
        lastBounds = signature;
        stableSince = performance.now();
        return;
      }
      if (performance.now() - stableSince < 600) return;
      reported = true;
      clearInterval(timer);
      window.parent.postMessage({ type: 'DINSIDE_PROVIDER_UI_READY', providerId: 'gemini' }, '*');
    };
    const timer = setInterval(checkGeminiReady, 120);
    checkGeminiReady();
  }

  if (provider.id === 'mimo' && isEmbeddedProviderView) {
    let stableSince = 0;
    let lastBounds = '';
    let reported = false;
    const startedAt = performance.now();
    const checkMimoReady = () => {
      if (reported) return;
      const root = document.getElementById('root');
      const elapsed = performance.now() - startedAt;
      // MiMo can leave its React root empty during a failed auth/network load.
      // Never let DinSide's own overlay hide that state indefinitely.
      if (!root?.children.length && elapsed < 20000) return;

      const composer = getComposer();
      const bounds = composer?.getBoundingClientRect();
      const usable = bounds && bounds.width >= 140 && bounds.height >= 20 &&
        bounds.left >= -2 && bounds.right <= innerWidth + 2;
      if (usable) {
        const signature = `${Math.round(bounds.left)}:${Math.round(bounds.right)}:${Math.round(bounds.bottom)}`;
        if (signature !== lastBounds) {
          lastBounds = signature;
          stableSince = performance.now();
        }
        if (performance.now() - stableSince < 350) return;
      } else if (elapsed < 20000 && (elapsed < 8000 || (root?.innerText || '').trim().length < 30)) {
        return;
      }

      reported = true;
      clearInterval(timer);
      window.parent.postMessage({ type: 'DINSIDE_PROVIDER_UI_READY', providerId: 'mimo' }, '*');
    };
    const timer = setInterval(checkMimoReady, 120);
    checkMimoReady();
  }

  if (provider.id === 'googleaistudio' && isEmbeddedProviderView) {
    const startedAt = performance.now();
    let stableSince = 0;
    let lastBounds = '';
    let initialSettingsHandled = false;
    const checkStudioReady = () => {
      const elapsed = performance.now() - startedAt;
      if (!initialSettingsHandled && innerWidth <= 720) {
        const closeSettings = document.querySelector(
          'ms-run-settings.expanded button[aria-label="Close run settings panel"]'
        );
        if (closeSettings) {
          closeSettings.click();
          initialSettingsHandled = true;
        }
      }
      const composer = getComposer();
      const bounds = composer?.getBoundingClientRect();
      const usable = isVisibleComposer(composer) && bounds.width >= 140 &&
        bounds.right <= innerWidth + 2;
      if (usable) {
        const signature = `${Math.round(bounds.left)}:${Math.round(bounds.right)}:${Math.round(bounds.bottom)}`;
        if (signature !== lastBounds) {
          lastBounds = signature;
          stableSince = performance.now();
        }
      } else {
        stableSince = 0;
        lastBounds = '';
      }
      if ((!usable || performance.now() - stableSince < 400) &&
          elapsed < 20000 && (elapsed < 8000 || (document.body?.innerText || '').trim().length < 100)) return;
      clearInterval(timer);
      window.parent.postMessage({ type: 'DINSIDE_PROVIDER_UI_READY', providerId: 'googleaistudio' }, '*');
    };
    const timer = setInterval(checkStudioReady, 120);
    checkStudioReady();
  }

  const SEND_BUTTON_SELECTOR = provider.sendButtonSelectors.join(', ');

  function isVisibleSendButton(button) {
    if (!button?.isConnected) return false;
    const rect = button.getBoundingClientRect?.();
    if (!rect || rect.width < 2 || rect.height < 2) return false;
    const style = getComputedStyle(button);
    return style.display !== 'none' && style.visibility !== 'hidden';
  }

  function getSendButton(composer = getComposer()) {
    if (provider.id === 'googleaistudio') {
      // AI Studio's Run settings also contain buttons. Search only the prompt
      // box, and never let the global fallback submit an unrelated control.
      const box = composer?.closest('ms-prompt-box') ||
        composer?.closest('.prompt-box-container') ||
        composer?.closest('ms-prompt-input-wrapper');
      if (!box) return null;
      const candidates = [...box.querySelectorAll('button')]
        .filter((button) => isVisibleSendButton(button) &&
          (Boolean(button.closest('ms-run-button')) ||
          /^(?:run|send)$/i.test((button.querySelector('.run-button-label')?.textContent || '').trim()) ||
          /^(?:run(?: prompt)?|send(?: message)?)$/i.test(
            `${button.getAttribute('aria-label') || button.getAttribute('title') || ''}`.trim()
          ) || /^(?:run|send)(?:\s*[↵⏎])?$/i.test((button.textContent || '').trim())));
      return candidates.find(isSendButtonReady) || candidates.at(-1) || null;
    }
    if (provider.id === 'metaai') {
      const nativeSend = document.querySelector('button[data-testid="composer-send-button"]');
      if (isVisibleSendButton(nativeSend)) return nativeSend;
    }
    if ((provider.id === 'deepseek' || provider.id === 'mimo') && composer) {
      let container = composer.parentElement;
      while (container && container !== document.body) {
        const candidates = [...container.querySelectorAll(SEND_BUTTON_SELECTOR)]
          .filter(isVisibleSendButton);
        if (candidates.length) {
          return candidates.filter(isSendButtonReady).at(-1) || candidates.at(-1);
        }
        container = container.parentElement;
      }
    }

    const form = composer?.closest('form');
    const scoped = [...(form?.querySelectorAll(SEND_BUTTON_SELECTOR) || [])];
    const visibleScoped = scoped.filter(isVisibleSendButton);
    const readyScoped = visibleScoped.find(isSendButtonReady);
    if (readyScoped) return readyScoped;
    if (visibleScoped.length) return visibleScoped.at(-1);

    // Last-resort fallback for provider variants that remove stable attributes:
    // the enabled final button in the composer form is the submit control once
    // the composer contains text.
    const candidates = [...(form?.querySelectorAll('button') || [])]
      .filter((button) => isVisibleSendButton(button) && isSendButtonReady(button) && !/attach|upload|voice|dictat|stop/i.test(
        `${button.getAttribute('aria-label') || ''} ${button.getAttribute('data-testid') || ''}`
      ));
    if (candidates.length) return candidates.at(-1);

    const globalCandidates = [...document.querySelectorAll(SEND_BUTTON_SELECTOR)]
      .filter(isVisibleSendButton);
    return globalCandidates.find(isSendButtonReady) || globalCandidates.at(-1) || null;
  }

  function isSendButtonReady(button) {
    return Boolean(
      button?.isConnected &&
      !button.disabled &&
      button.getAttribute('aria-disabled') !== 'true'
    );
  }

  async function waitForSendButton(composer, timeoutMs = 0) {
    const timeout = Math.max(0, Number(timeoutMs) || 0);
    const deadline = performance.now() + timeout;

    while (true) {
      const currentComposer = composer?.isConnected ? composer : getComposer();
      const button = getSendButton(currentComposer);
      if (isSendButtonReady(button)) return button;
      if (performance.now() >= deadline) return null;
      await new Promise((resolve) => setTimeout(resolve, 40));
    }
  }

  async function waitForComposerToClear(composer, timeoutMs = 800) {
    const deadline = performance.now() + Math.max(0, Number(timeoutMs) || 0);
    while (true) {
      const currentComposer = composer?.isConnected ? composer : getComposer();
      if (!currentComposer || !composerText(currentComposer)) return true;
      if (performance.now() >= deadline) return false;
      await new Promise((resolve) => setTimeout(resolve, 40));
    }
  }

  async function retrySendThroughForm(composer, timeoutMs = 1200) {
    const currentComposer = composer?.isConnected ? composer : getComposer();
    const sendButton = await waitForSendButton(currentComposer, 400);
    const form = sendButton?.form || sendButton?.closest?.('form') || currentComposer?.closest?.('form');
    if (!form) return false;

    try {
      bypassNextSend = true;
      if (typeof form.requestSubmit === 'function') form.requestSubmit(sendButton || undefined);
      else form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    } catch (error) {
      console.warn('[DinSide bridge] direct form submit failed', error);
      return false;
    }
    return waitForComposerToClear(currentComposer, timeoutMs);
  }

  function composerForSendButton(target) {
    const clicked = target?.closest?.(provider.id === 'googleaistudio' ? 'button' : SEND_BUTTON_SELECTOR);
    if (!clicked) return null;
    const form = clicked.closest('form');
    if (!form && (provider.id === 'deepseek' || provider.id === 'mimo' || provider.id === 'googleaistudio')) {
      let container = clicked.parentElement;
      while (container && container !== document.body) {
        const composer = [...container.querySelectorAll(COMPOSER_SELECTOR)].find(isVisibleComposer);
        if (composer) return composer;
        container = container.parentElement;
      }
    }
    return getComposer(form?.querySelector(COMPOSER_SELECTOR) || document.activeElement);
  }

  function isSendButtonTarget(target) {
    const clicked = target?.closest?.(provider.id === 'googleaistudio' ? 'button' : SEND_BUTTON_SELECTOR);
    if (!clicked) return false;
    const composer = composerForSendButton(clicked);
    const sendButton = getSendButton(composer);
    return Boolean(sendButton && clicked === sendButton);
  }

  function composerText(composer) {
    if (provider.id === 'metaai') {
      const mirror = document.querySelector('textarea[data-testid="composer-input"]');
      if (mirror?.value?.trim()) return mirror.value.trim();
    }
    if (typeof composer?.value === 'string') return composer.value.trim();
    return (composer?.innerText || composer?.textContent || '').trim();
  }

  function cleanComposerUserText(value = '') {
    const raw = String(value || '').trim();
    if (!raw.startsWith(DINSIDE_USER_MESSAGE_MARKER)) return raw;
    const afterMarker = raw.slice(DINSIDE_USER_MESSAGE_MARKER.length).trimStart();
    const contextMatch = afterMarker.match(DINSIDE_CONTEXT_START_PATTERN);
    return (contextMatch?.index == null ? afterMarker : afterMarker.slice(0, contextMatch.index)).trim();
  }

  // Reading innerText after a large ProseMirror/Lexical mutation can force a
  // full layout/paint pass. Post-injection checks only need marker presence, so
  // use value/textContent instead and keep the hot send path layout-free.
  function composerSnapshotText(composer) {
    if (typeof composer?.value === 'string') return composer.value;
    return composer?.textContent || '';
  }

  function showContextPreparingIndicator(composer) {
    document.getElementById('__dinside_context_spinner__')?.remove();
    const sendButton = getSendButton(composer);
    const indicator = document.createElement('div');
    indicator.id = '__dinside_context_spinner__';
    indicator.setAttribute('role', 'status');
    indicator.setAttribute('aria-live', 'polite');
    indicator.innerHTML = '<canvas aria-hidden="true"></canvas><b></b>';
    indicator.querySelector('b').textContent = t('Reading page…');
    Object.assign(indicator.style, {
      position: 'fixed',
      zIndex: '2147483647',
      display: 'flex',
      alignItems: 'center',
      gap: '7px',
      padding: '7px 10px',
      borderRadius: '999px',
      background: 'rgba(20,20,20,.92)',
      color: '#fff',
      boxShadow: '0 4px 18px rgba(0,0,0,.22)',
      font: '500 12px/1 system-ui, sans-serif',
      pointerEvents: 'none'
    });
    const orb = indicator.querySelector('canvas');
    const destroyOrb = globalThis.DinSideThinkingOrb?.mount?.(orb, {
      state: 'searching',
      size: 20,
      speed: 1,
      theme: 'dark',
      ariaLabel: t('Reading page…')
    });
    if (!destroyOrb) {
      Object.assign(orb.style, {
        width: '16px',
        height: '16px',
        boxSizing: 'border-box',
        border: '2px solid rgba(255,255,255,.35)',
        borderTopColor: '#fff',
        borderRadius: '50%',
        animation: 'dinside-context-spin .7s linear infinite'
      });
      let style = document.getElementById('__dinside_context_spinner_style__');
      if (!style) {
        style = document.createElement('style');
        style.id = '__dinside_context_spinner_style__';
        style.textContent = '@keyframes dinside-context-spin{to{transform:rotate(360deg)}}';
        document.documentElement.appendChild(style);
      }
    }
    document.body.appendChild(indicator);

    const place = () => {
      const button = sendButton?.isConnected ? sendButton : getSendButton(composer);
      const rect = button?.getBoundingClientRect();
      if (rect) {
        indicator.style.right = `${Math.max(12, innerWidth - rect.right)}px`;
        indicator.style.bottom = `${Math.max(12, innerHeight - rect.top + 8)}px`;
      } else {
        indicator.style.right = '20px';
        indicator.style.bottom = '88px';
      }
    };
    place();
    const onResize = () => place();
    window.addEventListener('resize', onResize, { passive: true });

    return () => {
      window.removeEventListener('resize', onResize);
      destroyOrb?.();
      indicator.remove();
    };
  }

  function placeComposerCaretAtStart(composer) {
    if (typeof composer?.select === 'function') {
      composer.setSelectionRange?.(0, 0);
      return;
    }
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(composer);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function composerHasInjectedText(composer, prefix) {
    const current = composerSnapshotText(composer).replace(/\u00a0/g, ' ').trim();
    const firstEnvelopeMarker = String(prefix).match(/^\[[^\]\n]+\]/m)?.[0] || '';
    return Boolean(
      current &&
      (!firstEnvelopeMarker || current.startsWith(firstEnvelopeMarker)) &&
      current.includes('[USER_MESSAGE]')
    );
  }

  function plainTextToInsertionHtml(text = '') {
    const escaped = String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    return `<p>${escaped.replace(/\r?\n/g, '<br>')}</p>`;
  }

  function prependComposerContext(composer, prefix) {
    if (!composer) return false;

    const originalValue = typeof composer.value === 'string' ? composer.value : null;
    const active = document.activeElement;
    if (active !== composer && !composer.contains?.(active)) {
      try { composer.focus({ preventScroll: true }); } catch (_) { composer.focus(); }
    }
    placeComposerCaretAtStart(composer);

    // Perplexity's Lexical editor discards/mangles literal newlines passed through
    // execCommand('insertText'). U+2028 is preserved as a semantic line separator
    // while remaining a normal text character from Lexical's point of view.
    const nativePrefix = provider.id === 'perplexity'
      ? prefix.replace(/\r?\n/g, '\u2028')
      : prefix;

    let inserted = false;
    // ChatGPT uses ProseMirror. insertText makes Chromium process a huge context
    // almost character-by-character internally (tens of KB can take seconds),
    // while one insertHTML transaction is orders of magnitude faster and still
    // updates ProseMirror's state. Escape all page text before building the HTML.
    const useFastProseMirrorInsert = provider.id === 'chatgpt' &&
      composer.isContentEditable && composer.classList?.contains('ProseMirror');

    if (useFastProseMirrorInsert) {
      try {
        inserted = document.execCommand(
          'insertHTML',
          false,
          plainTextToInsertionHtml(nativePrefix)
        );
      } catch (_) {
        inserted = false;
      }
    }

    // Compatibility path for other providers and any ChatGPT DOM variant where
    // the ProseMirror HTML transaction is unavailable.
    if (!inserted) {
      try {
        inserted = document.execCommand('insertText', false, nativePrefix);
      } catch (_) {
        inserted = false;
      }
    }

    if (!inserted && nativePrefix.length > 48000) {
      try {
        inserted = true;
        for (let offset = 0; offset < nativePrefix.length; offset += 24000) {
          const chunk = nativePrefix.slice(offset, offset + 24000);
          if (!document.execCommand('insertText', false, chunk)) {
            inserted = false;
            break;
          }
        }
      } catch (_) {
        inserted = false;
      }
    }

    // Textarea fallback for a future provider composer variant. Use the native
    // value setter so React sees the same state transition as normal typing.
    if (!inserted && originalValue !== null && composer.value === originalValue) {
      try {
        const descriptor = Object.getOwnPropertyDescriptor(
          Object.getPrototypeOf(composer),
          'value'
        );
        descriptor?.set?.call(composer, `${nativePrefix}${composer.value}`);
        composer.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          composed: true,
          inputType: 'insertText',
          data: prefix
        }));
        inserted = true;
      } catch (_) {}
    }

    if (!inserted || !composerHasInjectedText(composer, prefix)) return false;
    // execCommand already emits the native input transaction for rich editors.
    // A synthetic change event only helps textarea-style fallbacks and can make
    // React/contenteditable providers reconcile the large prompt a second time.
    if (originalValue !== null) {
      composer.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return true;
  }

  function replaceComposerText(composer, text = '') {
    if (!composer) return false;
    const nativeText = provider.id === 'perplexity'
      ? String(text).replace(/\r?\n/g, '\u2028')
      : String(text);

    if (provider.id === 'metaai') {
      const mirror = document.querySelector('textarea[data-testid="composer-input"]');
      if (mirror) {
        try {
          const descriptor = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
          descriptor?.set?.call(mirror, nativeText);
          if (!descriptor?.set) mirror.value = nativeText;
          mirror.dispatchEvent(new Event('input', { bubbles: true }));
          return mirror.value === nativeText;
        } catch (_) {
          return false;
        }
      }
    }

    const originalValue = typeof composer.value === 'string' ? composer.value : null;
    try { composer.focus({ preventScroll: true }); } catch (_) { composer.focus(); }

    // DeepSeek's React-controlled textarea accepts a real editing transaction
    // more reliably than assigning value and dispatching a synthetic event.
    if (provider.id === 'deepseek' && originalValue !== null) {
      try {
        composer.setSelectionRange(0, composer.value.length);
        const inserted = document.execCommand('insertText', false, nativeText);
        if (inserted && composerHasInjectedText(composer, nativeText)) return true;
      } catch (_) {}
    }

    if (originalValue !== null) {
      try {
        const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(composer), 'value');
        descriptor?.set?.call(composer, nativeText);
        composer.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          composed: true,
          inputType: 'insertText',
          data: text
        }));
        composer.dispatchEvent(new Event('change', { bubbles: true }));
        return provider.id === 'mimo' || provider.id === 'googleaistudio'
          ? composer.value === nativeText
          : Boolean(composerText(composer));
      } catch (_) {
        return false;
      }
    }

    try {
      const range = document.createRange();
      range.selectNodeContents(composer);
      const selection = getSelection();
      selection.removeAllRanges();
      selection.addRange(range);

      const useFastProseMirrorInsert = provider.id === 'chatgpt' &&
        composer.isContentEditable && composer.classList?.contains('ProseMirror');
      const inserted = useFastProseMirrorInsert
        ? document.execCommand('insertHTML', false, plainTextToInsertionHtml(nativeText))
        : document.execCommand('insertText', false, nativeText);

      if (inserted) return Boolean(composerText(composer));
    } catch (_) {}

    return false;
  }

  async function injectPerplexityContext(composer, userText = '', contextBody = '') {
    const message = String(userText || '').trim();
    const context = String(contextBody || '').trim();
    if (!composer || !message || !context) return false;

    try { composer.focus({ preventScroll: true }); } catch (_) { composer.focus(); }

    try {
      // Perplexity uses Lexical. Replacing the whole editor with execCommand and
      // embedded newlines looks successful in the DOM for a moment, but Lexical's
      // internal state keeps only the original query. Preserve that query, add the
      // DinSide marker at the start, then paste the multiline context at the end.
      let selection = getSelection();
      let range = document.createRange();
      range.selectNodeContents(composer);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
      if (!document.execCommand('insertText', false, `${DINSIDE_USER_MESSAGE_MARKER} `)) return false;

      // Let Lexical commit the prefix before moving its internal caret.
      await new Promise((resolve) => requestAnimationFrame(resolve));

      selection = getSelection();
      range = document.createRange();
      range.selectNodeContents(composer);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);

      // A harmless trailing space synchronizes Lexical's internal selection with
      // the DOM range. Without this transaction, a synthetic paste can land at
      // Lexical's previous caret even though the DOM caret is visually at the end.
      if (!document.execCommand('insertText', false, ' ')) return false;
      await new Promise((resolve) => requestAnimationFrame(resolve));

      const transfer = new DataTransfer();
      transfer.setData('text/plain', `\n\n${context}`);
      const pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: transfer
      });
      composer.dispatchEvent(pasteEvent);

      // Lexical applies paste through its editor update queue rather than in the
      // dispatch call itself. Wait for the committed editor state before Send.
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));

      const current = String(composer.innerText || composer.textContent || '');
      const contextMarker = context.match(/^\s*(\[[^\]\n]+\])/m)?.[1] || '';
      const messageProbe = message.slice(0, Math.min(80, message.length));
      return current.includes(DINSIDE_USER_MESSAGE_MARKER) &&
        (!messageProbe || current.includes(messageProbe)) &&
        (!contextMarker || current.includes(contextMarker));
    } catch (_) {
      return false;
    }
  }

  function quickAskInstruction(action, locale = '', customInstruction = '') {
    if (action === 'custom') {
      return String(customInstruction || '').trim().slice(0, 2000);
    }
    if (action === 'translate') {
      const target = String(locale || '').trim() || 'the user\'s language';
      return `Translate this selected text into the user's language (${target}). If it is already in that language, translate it into English instead. Preserve its meaning, tone, and formatting.`;
    }
    if (action === 'summarize') {
      return 'Summarize this selected text concisely. Keep the key ideas and important details.';
    }
    return 'Explain this selected text clearly and concisely. Focus on what it means and why it matters.';
  }

  function normalizeSelectedTextContext(selection) {
    const text = String(selection?.text ?? '').slice(0, 12000);
    if (!text.trim()) return null;
    const domContext = selection?.domContext || {};
    return {
      text,
      title: String(selection?.title || '').slice(0, 500),
      url: String(selection?.url || '').slice(0, 4000),
      locale: String(selection?.locale || '').slice(0, 80),
      domContext: {
        section: String(domContext.section || '').trim().slice(0, 240),
        element: String(domContext.element || '').trim().slice(0, 80),
        tag: String(domContext.tag || '').trim().slice(0, 40),
        block: String(domContext.block || '').trim().slice(0, 40),
        blockId: String(domContext.blockId || '').trim().slice(0, 500)
      },
      sourceChunk: String(selection?.sourceChunk || '').trim().slice(0, 1800)
    };
  }

  function selectedTextIdentity(selection = {}) {
    return [
      selection.url || '',
      selection.text || '',
      selection.domContext?.section || '',
      selection.domContext?.element || '',
      selection.domContext?.block || '',
      selection.domContext?.blockId || '',
      selection.sourceChunk || ''
    ].join('\n');
  }

  const SELECTION_SUPPORT_TOTAL_BUDGET = 3000;

  function selectionSupportBudget(selectionTexts = [], sourceCount = 1) {
    const lengths = (Array.isArray(selectionTexts) ? selectionTexts : [selectionTexts])
      .map((value) => String(value || '').trim().length)
      .filter((value) => value > 0);
    const length = lengths.length ? Math.min(...lengths) : 0;
    let base = 250;
    if (length < 80) base = 1200;
    else if (length < 300) base = 800;
    else if (length < 800) base = 500;
    return Math.max(0, Math.min(base, Math.floor(SELECTION_SUPPORT_TOTAL_BUDGET / Math.max(1, sourceCount))));
  }

  function selectionSourceGroupKey(selection = {}) {
    const url = selection.url || '';
    const blockId = selection.domContext?.blockId || '';
    if (blockId) return `${url}\nblock:${blockId}`;
    const source = String(selection.sourceChunk || '').replace(/\s+/g, ' ').trim();
    if (source) return `${url}\nsource:${source}`;
    return '';
  }

  function trimSharedSelectionSourceChunk(groupSelections, sourceCount = 1) {
    const candidates = [...new Set(groupSelections
      .map((selection) => String(selection?.sourceChunk || '').replace(/\s+/g, ' ').trim())
      .filter(Boolean))];
    if (!candidates.length) return '';

    const selectedTexts = groupSelections
      .map((selection) => String(selection?.text || '').replace(/\s+/g, ' ').trim())
      .filter(Boolean);
    const probes = selectedTexts.map((text) => text.slice(0, Math.min(240, text.length))).filter(Boolean);
    const budget = selectionSupportBudget(selectedTexts, sourceCount);
    if (!budget) return '';

    // Prefer the source candidate that covers the most selections. This matters
    // when several selections share a long block but their capture windows differ.
    let source = candidates[0];
    let bestCoverage = -1;
    for (const candidate of candidates) {
      const coverage = probes.reduce((count, probe) => count + (candidate.includes(probe) ? 1 : 0), 0);
      if (coverage > bestCoverage || (coverage === bestCoverage && candidate.length > source.length)) {
        source = candidate;
        bestCoverage = coverage;
      }
    }
    if (source.length <= budget) return source;

    const positions = probes
      .map((probe) => source.indexOf(probe))
      .filter((index) => index >= 0)
      .sort((a, b) => a - b);
    let start;
    if (positions.length) {
      const first = positions[0];
      const lastProbe = probes.find((probe) => source.indexOf(probe) === positions.at(-1)) || '';
      const last = positions.at(-1) + lastProbe.length;
      const span = last - first;
      if (span <= budget) {
        const spare = budget - span;
        start = Math.max(0, first - Math.floor(spare * 0.4));
      } else {
        start = Math.max(0, first - Math.floor(budget * 0.25));
      }
    } else {
      start = Math.max(0, Math.floor((source.length - budget) / 2));
    }

    let end = Math.min(source.length, start + budget);
    if (end === source.length) start = Math.max(0, end - budget);
    return `${start > 0 ? '…' : ''}${source.slice(start, end)}${end < source.length ? '…' : ''}`;
  }

  function buildSharedSelectionModel(selections = []) {
    const normalizedSelections = selections.map(normalizeSelectedTextContext).filter(Boolean);
    const groups = new Map();
    normalizedSelections.forEach((selection, index) => {
      const key = selectionSourceGroupKey(selection);
      if (!key) return;
      if (!groups.has(key)) groups.set(key, { key, selections: [], firstIndex: index });
      groups.get(key).selections.push(selection);
    });

    const sourceGroups = [...groups.values()].sort((a, b) => a.firstIndex - b.firstIndex);
    const sourceRefByKey = new Map();
    const sources = sourceGroups.map((group, index) => {
      const ref = `chunk-${index + 1}`;
      sourceRefByKey.set(group.key, ref);
      return {
        ref,
        text: trimSharedSelectionSourceChunk(group.selections, sourceGroups.length)
      };
    }).filter((source) => source.text);
    const validRefs = new Set(sources.map((source) => source.ref));

    return {
      selections: normalizedSelections.map((selection) => {
        const ref = sourceRefByKey.get(selectionSourceGroupKey(selection)) || '';
        return { selection, sourceRef: validRefs.has(ref) ? ref : '' };
      }),
      sources
    };
  }

  function serializeSelectedTextContexts(selections = []) {
    const model = buildSharedSelectionModel(selections);
    const selectionBlocks = model.selections.map(({ selection, sourceRef }, index) => {
      const number = index + 1;
      const primary = [
        `[SELECTED_TEXT_${number}]`,
        selection.title ? `Title: ${selection.title}` : '',
        selection.url ? `URL: ${selection.url}` : '',
        selection.text,
        `[/SELECTED_TEXT_${number}]`
      ].filter(Boolean).join('\n');
      const contextLines = [
        selection.domContext?.section ? `Section: ${selection.domContext.section}` : '',
        selection.domContext?.element ? `Element: ${selection.domContext.element}` : '',
        selection.domContext?.block ? `Block: ${selection.domContext.block}` : '',
        sourceRef ? `Source: ${sourceRef}` : ''
      ].filter(Boolean);
      const context = contextLines.length
        ? [`[SELECTION_CONTEXT_${number}]`, ...contextLines, `[/SELECTION_CONTEXT_${number}]`].join('\n')
        : '';
      return [primary, context].filter(Boolean).join('\n\n');
    });
    const sourceBlocks = model.sources.map((source) => [
      `[SELECTION_SOURCE_${source.ref.toUpperCase().replace(/-/g, '_')}]`,
      source.text,
      `[/SELECTION_SOURCE_${source.ref.toUpperCase().replace(/-/g, '_')}]`
    ].join('\n'));
    return [...selectionBlocks, ...sourceBlocks].filter(Boolean).join('\n\n');
  }

  function applyBridgeControlMessage(data) {
    if (!data) return false;

    if (data.type === 'DINSIDE_CLEAR_ALL_SELECTED_TEXT') {
      selectedTextContexts = [];
      committedSelectionCount = 0;
      removeSelectedTextCard();
      return true;
    }

    if (data.type === 'DINSIDE_CLEAR_SELECTED_TEXT') {
      if (selectedTextContexts.length > committedSelectionCount) {
        selectedTextContexts = selectedTextContexts.slice(0, committedSelectionCount);
      }
      if (!selectedTextContexts.length) removeSelectedTextCard();
      else renderSelectedTextCard();
      return true;
    }

    if (data.type === 'DINSIDE_GET_PENDING_CONTEXT_STATE' && data.requestId) {
      const previewModel = buildSharedSelectionModel(selectedTextContexts);
      window.parent.postMessage({
        type: 'DINSIDE_PENDING_CONTEXT_STATE',
        requestId: data.requestId,
        selections: previewModel.selections.map(({ selection, sourceRef }) => ({ ...selection, sourceRef })),
        selectionSources: previewModel.sources,
        committedSelectionCount
      }, '*');
      return true;
    }

    if (data.type === 'DINSIDE_REMOVE_SELECTED_CONTEXT') {
      const index = Number(data.index);
      if (!Number.isInteger(index) || index < 0 || index >= selectedTextContexts.length) return true;
      const wasCommitted = index < committedSelectionCount;
      selectedTextContexts.splice(index, 1);
      if (wasCommitted) committedSelectionCount = Math.max(0, committedSelectionCount - 1);
      committedSelectionCount = Math.min(committedSelectionCount, selectedTextContexts.length);
      if (!selectedTextContexts.length) {
        removeSelectedTextCard();
        window.parent.postMessage({ type: 'DINSIDE_SELECTIONS_CLEARED' }, '*');
      } else {
        renderSelectedTextCard();
      }
      return true;
    }

    if (data.type === 'DINSIDE_SELECTED_TEXT' && data.selection?.text) {
      const nextSelection = normalizeSelectedTextContext(data.selection);
      if (!nextSelection) return true;
      const committed = selectedTextContexts.slice(0, committedSelectionCount);
      const nextIdentity = selectedTextIdentity(nextSelection);
      const duplicateCommitted = committed.some(
        (item) => selectedTextIdentity(item) === nextIdentity
      );
      selectedTextContexts = duplicateCommitted || committed.length >= 5
        ? committed
        : [...committed, nextSelection];
      renderSelectedTextCard();
      // Do not steal focus from the source page. PDF/Drive viewers can collapse
      // their native selection as soon as the side-panel composer receives focus.
      return true;
    }

    if (data.type === 'DINSIDE_SKILLS_UPDATED') {
      const preservePopover = Boolean(document.getElementById('__dinside_skills_popover__'));
      skillsContext = Array.isArray(data.skills)
        ? data.skills
          .filter((skill) => skill?.enabled)
          .map((skill) => ({ ...skill, lifetime: normalizeSkillLifetime(skill.lifetime) }))
        : [];
      renderSkillsCard({ preservePopover });
      return true;
    }

    return false;
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.providerId && message.providerId !== provider.id) return;

    if (message?.type === 'DINSIDE_REQUEST_BRIDGE_STATUS') {
      reportBridgeReady();
      sendResponse({ ok: true, providerId: provider.id, version: DINSIDE_BRIDGE_VERSION, url: location.href });
      return;
    }

    if (applyBridgeControlMessage(message)) {
      sendResponse({ ok: true });
      return;
    }

    if (message?.type !== 'DINSIDE_ATTACH_SCREENSHOT_NOW') return;

    attachScreenshot(message.screenshot)
      .then((ok) => sendResponse({
        ok,
        error: ok ? '' : t`${provider.name} file input was not found.`
      }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  });

  // DinSide's side panel embeds the active provider in an iframe. Messages from the extension
  // parent reach this frame via postMessage, which works even though the iframe is
  // cross-origin. This is the path used for "capture -> attach immediately".
  function removeSelectedTextCard() {
    const tooltip = document.getElementById('__dinside_bridge_tooltip__');
    if (tooltip) {
      tooltip.style.opacity = '0';
      tooltip.style.visibility = 'hidden';
      tooltip.style.transition = 'opacity 100ms ease,visibility 0s linear 100ms';
    }
    document.getElementById('__dinside_selected_text_card__')?.remove();
  }

  function closeAttachedSkillsPopover() {
    if (skillsPopoverCleanup) {
      skillsPopoverCleanup();
      skillsPopoverCleanup = null;
    }
    document.getElementById('__dinside_skills_popover__')?.remove();
  }

  function removeSkillsCard() {
    closeAttachedSkillsPopover();
    document.getElementById('__dinside_skills_card__')?.remove();
  }

  function getComposerCardMount(composer = getComposer()) {
    if (!composer) return null;

    if (provider.id === 'googleaimode' || provider.id === 'googleaistudio' || provider.id === 'mimo' || provider.id === 'metaai' || provider.id === 'zai') {
      const hostId = provider.id === 'mimo'
        ? '__dinside_mimo_composer_cards__'
        : provider.id === 'metaai'
          ? '__dinside_meta_ai_composer_cards__'
          : provider.id === 'googleaistudio'
            ? '__dinside_google_ai_studio_composer_cards__'
          : provider.id === 'zai'
            ? '__dinside_zai_composer_cards__'
            : '__dinside_google_ai_mode_composer_cards__';
      let cardsHost = document.getElementById(hostId);
      if (!cardsHost) {
        cardsHost = document.createElement('div');
        cardsHost.id = hostId;
        cardsHost.style.cssText = [
          'position:fixed',
          'left:8px',
          'right:8px',
          'z-index:2147483646',
          'display:flex',
          'flex-direction:column',
          'gap:6px',
          'max-height:min(42vh,300px)',
          'overflow-x:hidden',
          'overflow-y:auto',
          'pointer-events:auto'
        ].join(';');
        (document.body || document.documentElement).appendChild(cardsHost);
      }

      // Keep provider-owned composer controls untouched. Float DinSide cards
      // above the visible shell instead of inserting into framework-owned DOM.
      const composerRect = composer.getBoundingClientRect();
      let shellRect = composerRect;
      let node = composer.parentElement;
      for (let depth = 0; node && node !== document.body && depth < 8; depth += 1) {
        const rect = node.getBoundingClientRect?.();
        if (
          rect &&
          rect.width >= composerRect.width &&
          rect.height >= composerRect.height &&
          rect.height <= 220 &&
          rect.top <= shellRect.top &&
          rect.bottom >= composerRect.bottom - 2 &&
          rect.bottom <= window.innerHeight + 4
        ) {
          shellRect = rect;
        }
        node = node.parentElement;
      }
      cardsHost.style.bottom = `${Math.max(8, window.innerHeight - shellRect.top + 8)}px`;
      return { container: cardsHost, anchor: cardsHost.firstChild, fullWidth: true, gridColumn: false };
    }

    const form = composer.closest?.('form');
    if (form) {
      return { container: form, anchor: form.firstChild, fullWidth: false, gridColumn: false };
    }

    if (provider.id === 'gemini') {
      const field = composer.closest?.('.text-input-field');
      if (field) {
        return { container: field, anchor: field.firstChild, fullWidth: true, gridColumn: true };
      }
    }

    if (provider.id === 'claude') {
      let node = composer.parentElement;
      while (node && node !== document.body) {
        const style = getComputedStyle(node);
        const hasSend = node.querySelector?.('button[data-testid="chat-input-send"]');
        const hasAttach = node.querySelector?.('button[data-testid="chat-input-attach"]');
        if (hasSend && hasAttach && style.display === 'flex' && style.flexDirection === 'column') {
          return { container: node, anchor: node.firstChild, fullWidth: true, gridColumn: false };
        }
        node = node.parentElement;
      }
    }

    if (provider.id === 'perplexity') {
      let node = composer.parentElement;
      while (node && node !== document.body) {
        const style = getComputedStyle(node);
        const hasAttach = node.querySelector?.('button[aria-label="Add files or tools"]');
        const gridColumns = String(style.gridTemplateColumns || '').trim().split(/\s+/).filter(Boolean);
        if (hasAttach && style.display === 'grid' && gridColumns.length === 1) {
          return { container: node, anchor: node.firstChild, fullWidth: true, gridColumn: false };
        }
        node = node.parentElement;
      }
    }

    if (provider.id === 'deepseek') {
      let composerShell = null;
      let node = composer.parentElement;
      while (node && node !== document.body) {
        const style = getComputedStyle(node);
        // DeepSeek omits aria-disabled from its send control while the composer
        // is empty, which is exactly when a newly selected passage is mounted.
        // Locate the composer shell with the broader role selector, then keep
        // the stricter selector for actual send interception.
        const hasControls = node.querySelector?.('div[role="button"]:not(.ds-toggle-button)');
        if (hasControls && !composerShell) composerShell = node;
        const isColumn = style.display === 'flex' && style.flexDirection === 'column';
        const isBlock = style.display === 'block';
        const gridColumns = String(style.gridTemplateColumns || '').trim().split(/\s+/).filter(Boolean);
        if (hasControls && (isColumn || isBlock || (style.display === 'grid' && gridColumns.length === 1))) {
          return { container: node, anchor: node.firstChild, fullWidth: true, gridColumn: false };
        }
        node = node.parentElement;
      }

      // CSS-module changes can leave every composer ancestor as a horizontal
      // flex row. Mount as a sibling immediately above the smallest shell so
      // the preview remains visible without changing DeepSeek's internal row.
      if (composerShell?.parentElement && composerShell.parentElement !== document.body) {
        return {
          container: composerShell.parentElement,
          anchor: composerShell,
          fullWidth: true,
          gridColumn: false
        };
      }
    }

    if (provider.id === 'openrouter') {
      const composerArea = composer.closest?.('[data-testid="playground-composer"]');
      if (composerArea) {
        return {
          container: composerArea,
          anchor: composerArea.firstChild,
          fullWidth: true,
          gridColumn: false
        };
      }
    }

    if (provider.id === 'copilot') {
      const composerContent = composer.closest?.('[data-testid="composer-content"]');
      if (composerContent) {
        return {
          container: composerContent,
          anchor: composerContent.firstChild,
          fullWidth: true,
          gridColumn: false
        };
      }
    }

    if (provider.id === 'qwen') {
      const composerShell = composer.closest?.('.message-input-container');
      if (composerShell) {
        // Qwen clips the desktop composer to the capsule's measured height.
        // Static cards inserted into that capsule replace the visible input row.
        // Keep provider-owned children untouched and float DinSide cards above it.
        let cardsHost = composerShell.querySelector(':scope > #__dinside_qwen_composer_cards__');
        if (!cardsHost) {
          cardsHost = document.createElement('div');
          cardsHost.id = '__dinside_qwen_composer_cards__';
          cardsHost.style.cssText = [
            'position:absolute',
            'left:0',
            'right:0',
            'bottom:calc(100% + 8px)',
            'z-index:20',
            'display:flex',
            'flex-direction:column',
            'gap:6px',
            'max-height:min(45vh,360px)',
            'overflow:auto',
            'pointer-events:auto'
          ].join(';');
          composerShell.style.position = 'relative';
          composerShell.style.overflow = 'visible';
          composerShell.insertBefore(cardsHost, composerShell.firstChild);
        }
        return {
          container: cardsHost,
          anchor: cardsHost.firstChild,
          fullWidth: false,
          gridColumn: false
        };
      }
    }

    if (provider.id === 'kimi') {
      const composerContent = composer.closest?.('.chat-editor-content');
      if (composerContent) {
        return {
          container: composerContent,
          anchor: composerContent.firstChild,
          fullWidth: true,
          gridColumn: false
        };
      }
    }

    return null;
  }

  function mountComposerCard(card, composer = getComposer()) {
    const mount = getComposerCardMount(composer);
    if (!mount) return false;
    if (mount.gridColumn) card.style.gridColumn = '1 / -1';
    if (mount.fullWidth) {
      card.style.width = 'calc(100% - 16px)';
      card.style.maxWidth = 'none';
      card.style.boxSizing = 'border-box';
    }
    mount.container.insertBefore(card, mount.anchor || mount.container.firstChild);
    return true;
  }

  function getComposerCardPalette() {
    const light = detectProviderTheme() === 'light';
    return light ? {
      cardBg: 'rgba(255,255,255,.94)',
      cardColor: 'rgba(31,31,31,.90)',
      cardBorder: 'rgba(60,64,67,.14)',
      cardShadow: '0 1px 2px rgba(60,64,67,.08),0 5px 16px rgba(60,64,67,.08)',
      buttonText: 'rgba(31,31,31,.66)',
      buttonStrong: 'rgba(31,31,31,.90)',
      buttonDisabled: 'rgba(31,31,31,.30)',
      buttonBg: 'rgba(31,31,31,.055)',
      buttonHover: 'rgba(31,31,31,.09)',
      rowBg: 'rgba(31,31,31,.045)',
      badgeBg: 'rgba(31,31,31,.07)',
      removeHover: 'rgba(31,31,31,.08)'
    } : {
      cardBg: 'rgba(24,24,24,.72)',
      cardColor: 'rgba(255,255,255,.92)',
      cardBorder: 'rgba(255,255,255,.07)',
      cardShadow: '0 1px 0 rgba(255,255,255,.025),0 6px 18px rgba(0,0,0,.16)',
      buttonText: 'rgba(255,255,255,.72)',
      buttonStrong: 'rgba(255,255,255,.92)',
      buttonDisabled: 'rgba(255,255,255,.30)',
      buttonBg: 'rgba(255,255,255,.075)',
      buttonHover: 'rgba(255,255,255,.11)',
      rowBg: 'rgba(255,255,255,.035)',
      badgeBg: 'rgba(255,255,255,.07)',
      removeHover: 'rgba(255,255,255,.08)'
    };
  }

  function attachDinSideTooltip(target, text) {
    if (!target || !text) return;
    target.removeAttribute('title');
    target.dataset.dinsideTooltip = String(text);

    const getTooltip = () => {
      let tooltip = document.getElementById('__dinside_bridge_tooltip__');
      if (tooltip) return tooltip;

      tooltip = document.createElement('div');
      tooltip.id = '__dinside_bridge_tooltip__';
      tooltip.setAttribute('role', 'tooltip');
      tooltip.style.cssText = [
        'position:fixed',
        'z-index:2147483647',
        'max-width:260px',
        'padding:7px 10px',
        'border:1px solid rgba(255,255,255,.06)',
        'border-radius:10px',
        'background:rgba(18,18,18,.96)',
        'color:rgba(255,255,255,.82)',
        'box-shadow:0 10px 28px rgba(0,0,0,.34)',
        'backdrop-filter:blur(12px)',
        '-webkit-backdrop-filter:blur(12px)',
        'font:500 12px/1.4 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
        'text-align:left',
        'white-space:pre-line',
        'overflow-wrap:anywhere',
        'opacity:0',
        'visibility:hidden',
        'pointer-events:none',
        'transition:opacity 100ms ease,visibility 0s linear 100ms'
      ].join(';');

      const arrow = document.createElement('span');
      arrow.style.cssText = 'position:absolute;width:8px;height:8px;background:rgba(18,18,18,.96);border-left:1px solid rgba(255,255,255,.06);border-top:1px solid rgba(255,255,255,.06);transform:rotate(45deg);';
      tooltip.appendChild(arrow);
      document.body.appendChild(tooltip);
      return tooltip;
    };

    let timer = 0;
    const hide = () => {
      clearTimeout(timer);
      const tooltip = document.getElementById('__dinside_bridge_tooltip__');
      if (!tooltip) return;
      tooltip.style.opacity = '0';
      tooltip.style.visibility = 'hidden';
      tooltip.style.transition = 'opacity 100ms ease,visibility 0s linear 100ms';
    };
    const show = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (!target.isConnected) return;
        const tooltip = getTooltip();
        const arrow = tooltip.firstElementChild;
        const label = target.dataset.dinsideTooltip || '';
        tooltip.childNodes[1]?.remove?.();
        const textNode = document.createTextNode(label);
        tooltip.appendChild(textNode);
        tooltip.style.left = '0px';
        tooltip.style.top = '0px';
        tooltip.style.visibility = 'hidden';
        tooltip.style.opacity = '0';

        const targetRect = target.getBoundingClientRect();
        const tipRect = tooltip.getBoundingClientRect();
        const gap = 9;
        const pad = 6;
        const targetCenter = targetRect.left + targetRect.width / 2;
        const above = targetRect.top >= tipRect.height + gap + pad;
        let left = Math.round(targetCenter - tipRect.width / 2);
        left = Math.max(pad, Math.min(left, innerWidth - tipRect.width - pad));
        const top = above
          ? Math.round(targetRect.top - tipRect.height - gap)
          : Math.round(targetRect.bottom + gap);
        const arrowLeft = Math.max(10, Math.min(targetCenter - left - 4, tipRect.width - 18));

        tooltip.style.left = `${left}px`;
        tooltip.style.top = `${Math.max(4, top)}px`;
        tooltip.style.transition = 'opacity 100ms ease';
        if (arrow) {
          arrow.style.left = `${Math.round(arrowLeft)}px`;
          arrow.style.top = above ? 'auto' : '-4px';
          arrow.style.bottom = above ? '-4px' : 'auto';
        }
        tooltip.style.visibility = 'visible';
        tooltip.style.opacity = '1';
      }, 180);
    };

    target.addEventListener('mouseenter', show);
    target.addEventListener('mouseleave', hide);
    target.addEventListener('focus', show);
    target.addEventListener('blur', hide);
  }

  function openAttachedSkillsPopover(trigger) {
    const existing = document.getElementById('__dinside_skills_popover__');
    if (existing) {
      closeAttachedSkillsPopover();
      return;
    }
    if (!trigger?.isConnected || !skillsContext.length) return;

    const palette = getComposerCardPalette();
    const popover = document.createElement('div');
    popover.id = '__dinside_skills_popover__';
    popover.style.cssText = [
      'position:fixed',
      'z-index:2147483646',
      'width:min(280px,calc(100vw - 20px))',
      'max-height:min(320px,calc(100vh - 24px))',
      'overflow:hidden',
      'padding:6px',
      `border:1px solid ${palette.cardBorder}`,
      'border-radius:12px',
      `background:${palette.cardBg}`,
      `color:${palette.cardColor}`,
      'backdrop-filter:blur(16px) saturate(1.08)',
      '-webkit-backdrop-filter:blur(16px) saturate(1.08)',
      `box-shadow:${palette.cardShadow},0 12px 34px rgba(0,0,0,.24)`,
      'font:11.5px/1.3 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif'
    ].join(';');

    const header = document.createElement('div');
    header.style.cssText = 'display:flex;align-items:center;gap:8px;height:28px;padding:0 6px 3px;';
    const heading = document.createElement('strong');
    heading.textContent = t('Attached skills');
    heading.style.cssText = 'min-width:0;flex:1;font-size:11.5px;font-weight:700;';
    const total = document.createElement('span');
    total.textContent = String(skillsContext.length);
    total.style.cssText = `flex:0 0 auto;color:${palette.buttonText};font-size:10.5px;font-weight:600;`;
    header.append(heading, total);

    const list = document.createElement('div');
    list.style.cssText = 'max-height:230px;overflow-y:auto;overscroll-behavior:contain;padding:1px;scrollbar-width:thin;';

    for (const skill of skillsContext) {
      const row = document.createElement('div');
      row.style.cssText = `display:flex;align-items:center;gap:6px;min-height:34px;padding:3px 4px 3px 7px;border-radius:8px;background:${palette.rowBg};margin:3px 0;`;

      const marker = document.createElement('span');
      marker.textContent = '✓';
      marker.style.cssText = `flex:0 0 auto;width:14px;color:${palette.buttonText};font-size:10px;text-align:center;`;

      const name = document.createElement('button');
      name.type = 'button';
      name.textContent = skill.name || t('Untitled skill');
      name.style.cssText = `min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0;border:0;background:transparent;color:${palette.cardColor};font:600 11.5px/1.25 system-ui,sans-serif;text-align:left;cursor:pointer;`;
      attachDinSideTooltip(name, skill.name || t('Untitled skill'));
      name.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        closeAttachedSkillsPopover();
        window.parent.postMessage({ type: 'DINSIDE_SKILL_EDIT_REQUEST', skillId: skill.id || '' }, '*');
      });

      const lifetime = document.createElement('button');
      lifetime.type = 'button';
      lifetime.textContent = skillLifetimeLabel(skill.lifetime);
      lifetime.setAttribute('aria-label', t`Use for ${skillLifetimeDescription(skill.lifetime)}`);
      attachDinSideTooltip(lifetime, t`Use for: ${skillLifetimeDescription(skill.lifetime)} · Click to change`);
      lifetime.style.cssText = [
        'flex:0 0 auto',
        'height:22px',
        'padding:0 6px',
        'border:0',
        'border-radius:999px',
        `background:${palette.badgeBg}`,
        `color:${palette.buttonText}`,
        'font:600 9.5px/1 system-ui,sans-serif',
        'cursor:pointer'
      ].join(';');
      lifetime.addEventListener('mouseenter', () => { lifetime.style.color = palette.buttonStrong; lifetime.style.background = palette.buttonHover; });
      lifetime.addEventListener('mouseleave', () => { lifetime.style.color = palette.buttonText; lifetime.style.background = palette.badgeBg; });
      lifetime.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const nextLifetime = nextSkillLifetime(skill.lifetime);
        skill.lifetime = nextLifetime;
        lifetime.textContent = skillLifetimeLabel(nextLifetime);
        lifetime.setAttribute('aria-label', t`Use for ${skillLifetimeDescription(nextLifetime)}`);
        lifetime.dataset.dinsideTooltip = t`Use for: ${skillLifetimeDescription(nextLifetime)} · Click to change`;
        window.parent.postMessage({
          type: 'DINSIDE_SKILL_LIFETIME_CHANGED',
          skillId: skill.id || '',
          lifetime: nextLifetime
        }, '*');
      });

      const remove = document.createElement('button');
      remove.type = 'button';
      remove.textContent = '×';
      remove.setAttribute('aria-label', t`Detach ${skill.name || t('skill')}`);
      remove.style.cssText = `flex:0 0 auto;width:24px;height:24px;display:grid;place-items:center;padding:0;border:0;border-radius:6px;background:transparent;color:${palette.buttonText};font:15px/1 system-ui,sans-serif;cursor:pointer;`;
      remove.addEventListener('mouseenter', () => { remove.style.background = palette.removeHover; remove.style.color = palette.buttonStrong; });
      remove.addEventListener('mouseleave', () => { remove.style.background = 'transparent'; remove.style.color = palette.buttonText; });
      remove.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const skillId = skill.id || '';
        skillsContext = skillsContext.filter((item) => item !== skill && (!skillId || item.id !== skillId));
        renderSkillsCard({ preservePopover: true });
        window.parent.postMessage({ type: 'DINSIDE_SKILL_DETACHED', skillId }, '*');
      });

      row.append(marker, name, lifetime, remove);
      list.appendChild(row);
    }

    const manage = document.createElement('button');
    manage.type = 'button';
    manage.textContent = t('Manage skills');
    manage.style.cssText = `width:100%;height:30px;margin-top:4px;padding:0 7px;border:0;border-top:1px solid ${palette.cardBorder};background:transparent;color:${palette.buttonText};font:600 11px/1 system-ui,sans-serif;text-align:left;cursor:pointer;`;
    manage.addEventListener('mouseenter', () => { manage.style.color = palette.buttonStrong; });
    manage.addEventListener('mouseleave', () => { manage.style.color = palette.buttonText; });
    manage.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      closeAttachedSkillsPopover();
      window.parent.postMessage({ type: 'DINSIDE_OPEN_SKILLS' }, '*');
    });

    popover.append(header, list, manage);
    document.body.appendChild(popover);

    const triggerRect = trigger.getBoundingClientRect();
    const popRect = popover.getBoundingClientRect();
    const pad = 8;
    const gap = 8;
    let left = Math.round(triggerRect.right - popRect.width);
    left = Math.max(pad, Math.min(left, innerWidth - popRect.width - pad));
    let top = Math.round(triggerRect.top - popRect.height - gap);
    if (top < pad) top = Math.round(triggerRect.bottom + gap);
    top = Math.max(pad, Math.min(top, innerHeight - popRect.height - pad));
    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;

    const onOutside = (event) => {
      if (popover.contains(event.target) || trigger.contains(event.target)) return;
      closeAttachedSkillsPopover();
    };
    const onKey = (event) => {
      if (event.key === 'Escape') closeAttachedSkillsPopover();
    };
    const onViewportChange = () => closeAttachedSkillsPopover();
    const outsideTimer = setTimeout(() => document.addEventListener('pointerdown', onOutside, true), 0);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('resize', onViewportChange, { passive: true });
    window.addEventListener('scroll', onViewportChange, { passive: true, capture: true });
    skillsPopoverCleanup = () => {
      clearTimeout(outsideTimer);
      document.removeEventListener('pointerdown', onOutside, true);
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('resize', onViewportChange);
      window.removeEventListener('scroll', onViewportChange, true);
    };
  }

  function renderSkillsCard({ preservePopover = false } = {}) {
    const shouldRestorePopover = preservePopover && Boolean(document.getElementById('__dinside_skills_popover__'));
    removeSkillsCard();
    if (!skillsContext.length) return;

    const composer = getComposer();
    if (!composer || !getComposerCardMount(composer)) return;

    const palette = getComposerCardPalette();
    const card = document.createElement('div');
    card.id = '__dinside_skills_card__';
    card.style.cssText = [
      'display:flex',
      'align-items:center',
      'gap:6px',
      'width:fit-content',
      'max-width:min(78%,260px)',
      'min-width:0',
      'margin:0 8px 6px',
      'padding:5px 7px',
      'min-height:28px',
      `border:1px solid ${palette.cardBorder}`,
      'border-radius:10px',
      `background:${palette.cardBg}`,
      `color:${palette.cardColor}`,
      'backdrop-filter:blur(14px) saturate(1.08)',
      '-webkit-backdrop-filter:blur(14px) saturate(1.08)',
      `box-shadow:${palette.cardShadow}`,
      'font:11.5px/1.25 system-ui,sans-serif'
    ].join(';');

    const kind = document.createElement('span');
    kind.textContent = '✦';
    attachDinSideTooltip(kind, t('Skill'));
    kind.setAttribute('aria-label', t('Skill'));
    kind.style.cssText = 'flex:0 0 auto;opacity:.62;font-size:11px;line-height:1;';

    const preview = document.createElement('div');
    const names = skillsContext.map((skill) => skill.name || t('Untitled skill'));
    preview.textContent = names[0];
    attachDinSideTooltip(preview, names.join('\n'));
    preview.style.cssText = 'min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;line-height:1.15;';

    let countBadge = null;
    let lifetimeBadge = null;
    if (names.length > 1) {
      countBadge = document.createElement('button');
      countBadge.type = 'button';
      countBadge.textContent = `+${names.length - 1}`;
      countBadge.setAttribute('aria-label', t`Show ${names.length} attached skills`);
      attachDinSideTooltip(countBadge, t`Show ${names.length} attached skills`);
      countBadge.style.cssText = [
        'flex:0 0 auto',
        'padding:2px 5px',
        'border:0',
        'border-radius:999px',
        `background:${palette.badgeBg}`,
        `color:${palette.buttonStrong}`,
        'font:600 10.5px/1.15 system-ui,sans-serif',
        'cursor:pointer'
      ].join(';');
      countBadge.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        openAttachedSkillsPopover(countBadge);
      });
    } else {
      const skill = skillsContext[0];
      lifetimeBadge = document.createElement('button');
      lifetimeBadge.type = 'button';
      lifetimeBadge.textContent = skillLifetimeLabel(skill?.lifetime);
      lifetimeBadge.setAttribute('aria-label', t`Use for ${skillLifetimeDescription(skill?.lifetime)}`);
      attachDinSideTooltip(lifetimeBadge, t`Use for: ${skillLifetimeDescription(skill?.lifetime)} · Click to change`);
      lifetimeBadge.style.cssText = [
        'flex:0 0 auto',
        'padding:2px 5px',
        'border:0',
        'border-radius:999px',
        `background:${palette.badgeBg}`,
        `color:${palette.buttonText}`,
        'font:600 9.5px/1.15 system-ui,sans-serif',
        'cursor:pointer'
      ].join(';');
      lifetimeBadge.addEventListener('mouseenter', () => { lifetimeBadge.style.color = palette.buttonStrong; lifetimeBadge.style.background = palette.buttonHover; });
      lifetimeBadge.addEventListener('mouseleave', () => { lifetimeBadge.style.color = palette.buttonText; lifetimeBadge.style.background = palette.badgeBg; });
      lifetimeBadge.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const nextLifetime = nextSkillLifetime(skill?.lifetime);
        if (skill) skill.lifetime = nextLifetime;
        lifetimeBadge.textContent = skillLifetimeLabel(nextLifetime);
        lifetimeBadge.setAttribute('aria-label', t`Use for ${skillLifetimeDescription(nextLifetime)}`);
        lifetimeBadge.dataset.dinsideTooltip = t`Use for: ${skillLifetimeDescription(nextLifetime)} · Click to change`;
        window.parent.postMessage({
          type: 'DINSIDE_SKILL_LIFETIME_CHANGED',
          skillId: skill?.id || '',
          lifetime: nextLifetime
        }, '*');
      });
    }

    const close = document.createElement('button');
    close.type = 'button';
    close.setAttribute('aria-label', names.length > 1 ? t('Remove all attached skills') : t('Remove attached skill'));
    attachDinSideTooltip(close, names.length > 1 ? t('Remove all attached skills') : t('Remove skill'));
    close.textContent = '×';
    close.style.cssText = [
      'flex:0 0 auto',
      'width:20px',
      'height:20px',
      'display:grid',
      'place-items:center',
      'padding:0',
      'border:0',
      'border-radius:50%',
      'background:transparent',
      `color:${palette.buttonText}`,
      'font:16px/1 system-ui,sans-serif',
      'cursor:pointer'
    ].join(';');
    close.addEventListener('mouseenter', () => { close.style.background = palette.removeHover; close.style.color = palette.buttonStrong; });
    close.addEventListener('mouseleave', () => { close.style.background = 'transparent'; close.style.color = palette.buttonText; });
    close.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      skillsContext = [];
      removeSkillsCard();
      window.parent.postMessage({ type: 'DINSIDE_SKILLS_DETACH_ALL' }, '*');
      getComposer()?.focus();
    });

    card.append(kind, preview);
    if (countBadge) card.appendChild(countBadge);
    if (lifetimeBadge) card.appendChild(lifetimeBadge);
    card.appendChild(close);
    mountComposerCard(card, composer);

    if (shouldRestorePopover) {
      requestAnimationFrame(() => {
        const nextTrigger = document.getElementById('__dinside_skills_card__');
        if (nextTrigger?.isConnected && skillsContext.length) openAttachedSkillsPopover(nextTrigger);
      });
    }
  }

  function renderSelectedTextCard() {
    removeSelectedTextCard();
    if (!selectedTextContexts.length) return;

    const composer = getComposer();
    if (!composer || !getComposerCardMount(composer)) return;

    const palette = getComposerCardPalette();
    const compactGoogleCard = provider.id === 'googleaimode';
    const card = document.createElement('div');
    card.id = '__dinside_selected_text_card__';
    card.style.cssText = [
      'display:flex',
      'flex-direction:column',
      `gap:${compactGoogleCard ? '2px' : '4px'}`,
      'width:calc(100% - 16px)',
      'max-width:100%',
      'min-width:0',
      `margin:0 8px ${compactGoogleCard ? '3px' : '6px'}`,
      `padding:${compactGoogleCard ? '4px' : '6px'}`,
      `border:1px solid ${palette.cardBorder}`,
      `border-radius:${compactGoogleCard ? '10px' : '12px'}`,
      `background:${palette.cardBg}`,
      `color:${palette.cardColor}`,
      'backdrop-filter:blur(14px) saturate(1.08)',
      '-webkit-backdrop-filter:blur(14px) saturate(1.08)',
      `box-shadow:${palette.cardShadow}`,
      `font:${compactGoogleCard ? '11px/1.15' : '11.5px/1.25'} system-ui,sans-serif`
    ].join(';');

    const header = document.createElement('div');
    header.style.cssText = 'display:flex;align-items:center;gap:6px;min-width:0;padding:0 2px;';

    const label = document.createElement('div');
    label.textContent = t`Selected context · ${selectedTextContexts.length}`;
    label.style.cssText = 'min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;opacity:.78;';

    const keep = document.createElement('button');
    keep.type = 'button';
    keep.textContent = t('Keep');
    keep.title = t('Keep current selection');
    keep.setAttribute('aria-label', t('Keep current selection'));
    const hasLiveSelection = selectedTextContexts.length > committedSelectionCount;
    keep.disabled = !hasLiveSelection;
    keep.style.cssText = `height:${compactGoogleCard ? '24px' : '30px'};display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:${compactGoogleCard ? '7px' : '9px'};background:${hasLiveSelection ? palette.buttonBg : 'transparent'};color:${hasLiveSelection ? palette.buttonStrong : palette.buttonDisabled};font:600 ${compactGoogleCard ? '10.5px' : '11.5px'}/1 system-ui,sans-serif;letter-spacing:-.01em;cursor:${hasLiveSelection ? 'pointer' : 'default'};padding:0 ${compactGoogleCard ? '8px' : '11px'};flex:0 0 auto;transition:background 120ms ease,color 120ms ease;`;
    keep.addEventListener('mouseenter', () => {
      if (keep.disabled) return;
      keep.style.background = palette.buttonHover;
      keep.style.color = palette.buttonStrong;
    });
    keep.addEventListener('mouseleave', () => {
      if (keep.disabled) return;
      keep.style.background = palette.buttonBg;
      keep.style.color = palette.buttonStrong;
    });
    keep.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (!hasLiveSelection) return;

      // Keep commits only the passage that is highlighted right now. Any later
      // highlight is transient again until the user presses Keep for that passage.
      committedSelectionCount = selectedTextContexts.length;
      window.parent.postMessage({ type: 'DINSIDE_COMMIT_SELECTION' }, '*');
      renderSelectedTextCard();
      getComposer()?.focus();
    });

    const clear = document.createElement('button');
    clear.type = 'button';
    clear.textContent = t('Clear all');
    clear.title = t('Remove all selected context');
    clear.style.cssText = `height:${compactGoogleCard ? '24px' : '30px'};border:0;border-radius:7px;background:transparent;color:${palette.buttonText};font:500 ${compactGoogleCard ? '10.5px' : '11.5px'}/1 system-ui,sans-serif;letter-spacing:-.01em;cursor:pointer;padding:0 ${compactGoogleCard ? '6px' : '8px'};flex:0 0 auto;transition:background 120ms ease,color 120ms ease;`;
    clear.addEventListener('mouseenter', () => { clear.style.background = palette.buttonHover; clear.style.color = palette.buttonStrong; });
    clear.addEventListener('mouseleave', () => { clear.style.background = 'transparent'; clear.style.color = palette.buttonText; });
    clear.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      selectedTextContexts = [];
      committedSelectionCount = 0;
      removeSelectedTextCard();
      window.parent.postMessage({ type: 'DINSIDE_SELECTIONS_CLEARED' }, '*');
      getComposer()?.focus();
    });

    header.append(label, keep, clear);
    card.appendChild(header);

    selectedTextContexts.forEach((selection, index) => {
      const row = document.createElement('div');
      row.style.cssText = `display:flex;align-items:center;gap:${compactGoogleCard ? '5px' : '6px'};min-width:0;min-height:${compactGoogleCard ? '22px' : '28px'};padding:${compactGoogleCard ? '2px 4px 2px 6px' : '4px 5px 4px 7px'};border-radius:${compactGoogleCard ? '7px' : '8px'};background:${palette.rowBg};`;
      attachDinSideTooltip(row, selection.text);

      const number = document.createElement('span');
      number.textContent = String(index + 1);
      number.style.cssText = `flex:0 0 auto;width:16px;height:16px;display:grid;place-items:center;border-radius:50%;background:${palette.badgeBg};opacity:.7;font-size:9px;font-weight:700;`; 

      const preview = document.createElement('div');
      preview.textContent = selection.text.replace(/\s+/g, ' ').trim();
      preview.style.cssText = 'min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.9;';

      const remove = document.createElement('button');
      remove.type = 'button';
      remove.textContent = '×';
      remove.title = t`Remove selection ${index + 1}`;
      remove.setAttribute('aria-label', t`Remove selection ${index + 1}`);
      remove.style.cssText = 'flex:0 0 auto;width:20px;height:20px;display:grid;place-items:center;padding:0;border:0;border-radius:6px;background:transparent;color:inherit;opacity:.52;font:15px/1 system-ui,sans-serif;cursor:pointer;';
      remove.addEventListener('mouseenter', () => { remove.style.background = palette.removeHover; remove.style.opacity = '1'; });
      remove.addEventListener('mouseleave', () => { remove.style.background = 'transparent'; remove.style.opacity = '.52'; });
      remove.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const wasCommitted = index < committedSelectionCount;
        selectedTextContexts.splice(index, 1);
        if (wasCommitted) committedSelectionCount = Math.max(0, committedSelectionCount - 1);
        committedSelectionCount = Math.min(committedSelectionCount, selectedTextContexts.length);
        if (!selectedTextContexts.length) {
          removeSelectedTextCard();
          window.parent.postMessage({ type: 'DINSIDE_SELECTIONS_CLEARED' }, '*');
        } else {
          renderSelectedTextCard();
        }
        getComposer()?.focus();
      });

      row.append(number, preview, remove);
      card.appendChild(row);
    });

    mountComposerCard(card, composer);
  }

  // These providers can replace their composer subtree while the
  // user switches modes/tools. Re-mount DinSide cards only when they disappeared.
  if (['gemini', 'googleaimode', 'googleaistudio', 'notebooklm', 'claude', 'perplexity', 'deepseek', 'openrouter', 'copilot', 'qwen', 'kimi', 'metaai', 'mimo', 'zai'].includes(provider.id)) {
    let repairQueued = false;
    const repairCards = () => {
      if (repairQueued) return;
      const needsSelection = selectedTextContexts.length && !document.getElementById('__dinside_selected_text_card__');
      const needsSkills = skillsContext.length && !document.getElementById('__dinside_skills_card__');
      if (!needsSelection && !needsSkills) return;
      repairQueued = true;
      requestAnimationFrame(() => {
        repairQueued = false;
        if (needsSelection) renderSelectedTextCard();
        if (needsSkills) renderSkillsCard();
      });
    };
    const repairObserver = new MutationObserver(repairCards);
    repairObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  async function runQuickAsk(data) {
    const action = ['explain', 'translate', 'summarize', 'custom'].includes(data?.action)
      ? data.action
      : 'explain';
    const selection = normalizeSelectedTextContext(data?.selection);
    const customInstruction = action === 'custom'
      ? String(data?.instruction || '').trim().slice(0, 2000)
      : '';
    const respond = (payload) => window.parent.postMessage({
      type: 'DINSIDE_QUICK_ASK_RESULT',
      quickAskId: data?.quickAskId || '',
      ...payload
    }, '*');

    if (!selection?.text || (action === 'custom' && !customInstruction)) {
      respond({ ok: false, error: t('Quick Ask selection or custom instruction is empty.') });
      return false;
    }

    const composer = getComposer();
    if (!composer) {
      respond({ ok: false, error: t`${provider.name} composer was not found.` });
      return false;
    }

    // Never destroy a draft the user was already writing. Attach the selection
    // and leave the composer untouched so the user can decide what to do next.
    if (composerText(composer)) {
      applyBridgeControlMessage({ type: 'DINSIDE_SELECTED_TEXT', selection });
      respond({
        ok: false,
        error: t('Quick Ask paused because the composer already has a draft.')
      });
      return false;
    }

    const prompt = quickAskInstruction(
      action,
      selection.locale || '',
      customInstruction
    );
    if (!replaceComposerText(composer, prompt)) {
      respond({ ok: false, error: t('Quick Ask could not prepare the composer.') });
      return false;
    }

    const sent = await injectContextAndSend('quick-ask', composer, {
      skipPageContext: true,
      preserveSkills: true,
      selectionOverride: [selection],
      afterSendSelectionMode: 'preserveCommitted',
      sendReadyTimeoutMs: 2000,
      requireSendButton: true,
      confirmSend: true
    });
    respond({
      ok: Boolean(sent),
      mode: action,
      label: action === 'custom' ? String(data?.label || '').slice(0, 32) : '',
      error: sent ? '' : t('Quick Ask could not send the prompt.')
    });
    return Boolean(sent);
  }

  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data) return;
    if (provider.id === 'claude' && isEmbeddedProviderView &&
        data.type === 'DINSIDE_SKILLS_UPDATED' &&
        event.source === window.parent &&
        event.origin === `chrome-extension://${chrome.runtime.id}`) {
      document.dispatchEvent(new Event('dinside:claude-embedded'));
    }
    if (data.type === 'DINSIDE_QUICK_ASK') {
      runQuickAsk(data);
      return;
    }
    if (applyBridgeControlMessage(data)) return;

    if (data.type !== 'DINSIDE_ATTACH_SCREENSHOT_NOW' || !data.requestId) return;

    attachScreenshot(data.screenshot)
      .then((ok) => {
        window.parent.postMessage({
          type: 'DINSIDE_ATTACH_SCREENSHOT_RESULT',
          requestId: data.requestId,
          ok,
          error: ok ? '' : t`${provider.name} could not attach the screenshot.`
        }, '*');
      })
      .catch((error) => {
        window.parent.postMessage({
          type: 'DINSIDE_ATTACH_SCREENSHOT_RESULT',
          requestId: data.requestId,
          ok: false,
          error: error.message
        }, '*');
      });
  });

  function notifyContextDelivery(type, details = {}) {
    const message = { type, ...details };
    sendRuntimeMessageSafely(message).then((sent) => {
      if (!sent) window.parent.postMessage(message, '*');
    });
  }

  function inferContextMode() {
    // AI Mode transports the prompt through Google Search and rejects the large
    // full-page envelopes accepted by dedicated chat providers. Keep its normal
    // requests to page metadata + the current viewport; selected text is added
    // separately by the bridge below.
    if (provider.id === 'googleaimode') return 'compact';
    // Prefer completeness over speed. DinSide now waits for full page context
    // before sending, while showing a visible preparation indicator.
    return 'full';
  }

  function truncateProviderContextPart(value = '', budget = 0) {
    const text = String(value || '');
    if (!budget || !text) return '';
    if (text.length <= budget) return text;

    const marker = `\n\n[… context shortened for ${provider.name} …]\n\n`;
    if (budget <= marker.length + 160) return text.slice(0, budget);
    const usable = budget - marker.length;
    const headSize = Math.floor(usable * 0.72);
    return `${text.slice(0, headSize)}${marker}${text.slice(-(usable - headSize))}`;
  }

  function buildProviderContextBody(envelope = '', selectedEnvelope = '', userText = '', composer = null) {
    if (provider.id === 'mimo' || provider.id === 'googleaistudio') {
      const fieldLimit = Number.isInteger(composer?.maxLength) && composer.maxLength > 0
        ? composer.maxLength
        : provider.maxPromptChars;
      const available = Math.max(0,
        Math.min(provider.maxPromptChars, fieldLimit) - `[USER_MESSAGE]\n${userText}\n\n`.length
      );
      if (!available) return '';
      const page = String(envelope || '');
      const selected = String(selectedEnvelope || '');
      const combined = [page, selected].filter(Boolean).join('\n\n');
      if (combined.length <= available) return combined;
      if (!selected) return truncateProviderContextPart(page, available);
      if (!page) return truncateProviderContextPart(selected, available);

      // Preserve the selected passage when the full page exceeds the prompt
      // budget. The remainder goes to page context.
      const selectedBudget = Math.min(
        selected.length,
        Math.max(Math.floor(available * 0.6), available - Math.min(page.length, 1400) - 2)
      );
      const pageBudget = Math.max(0, available - selectedBudget - 2);
      return [
        truncateProviderContextPart(selected, selectedBudget),
        truncateProviderContextPart(page, pageBudget)
      ].filter(Boolean).join('\n\n');
    }
    if (provider.id !== 'googleaimode') {
      return [envelope, selectedEnvelope].filter(Boolean).join('\n\n');
    }

    const promptPrefixLength = `[USER_MESSAGE]\n${userText}\n\n`.length;
    const available = Math.max(0, provider.maxPromptChars - promptPrefixLength);
    if (!available) return '';

    const page = String(envelope || '');
    const selected = String(selectedEnvelope || '');
    if (!selected) return truncateProviderContextPart(page, available);

    const selectedPriorityInstruction = [
      'Primary context: answer about the selected passage below.',
      'References such as "this", "this part", "này", or "đoạn này" refer to SELECTED_TEXT, not to the page as a whole.'
    ].join(' ');
    const prioritizedSelected = `${selectedPriorityInstruction}\n\n${selected}`;
    if (!page) return truncateProviderContextPart(prioritizedSelected, available);

    const separatorSize = 2;
    const contentBudget = Math.max(0, available - separatorSize);
    // When a passage is selected, the surrounding page is supporting context
    // only. Keeping it small stops Google Search from answering about the page
    // title/URL while overlooking a short selection.
    const pageBudget = Math.min(page.length, 1400, Math.floor(contentBudget * 0.28));
    const selectedBudget = Math.min(prioritizedSelected.length, contentBudget - pageBudget);

    // Put the explicitly selected passage first: it is normally more relevant
    // than the automatic viewport snapshot when AI Mode's query budget is tight.
    return [
      truncateProviderContextPart(prioritizedSelected, selectedBudget),
      truncateProviderContextPart(page, pageBudget)
    ].filter(Boolean).join('\n\n');
  }

  async function getPromptPayload(contextMode = 'compact', promptText = '') {
    const requestId = `dinside-context-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const initialTimeoutMs = 7000;
    const maxPreparationTimeoutMs = 120000;

    return new Promise((resolve) => {
      let settled = false;
      let parentFallbackStarted = false;
      let runtimeFallbackStarted = false;
      let timer = null;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        window.removeEventListener('message', onMessage);
        clearTimeout(timer);
        resolve(value);
      };

      const armTimeout = (timeoutMs = initialTimeoutMs) => {
        clearTimeout(timer);
        const delay = Math.min(
          maxPreparationTimeoutMs,
          Math.max(initialTimeoutMs, Number(timeoutMs) || initialTimeoutMs)
        );
        timer = setTimeout(() => {
          const error = 'Timed out waiting for page context; prompt was not sent.';
          finish({
            envelope: '', screenshot: '', deliveryToken: '', requestId,
            failed: true, error
          });
        }, delay);
      };

      const onMessage = (event) => {
        const data = event.data;
        if (!data || data.requestId !== requestId) return;
        if (data.type === 'DINSIDE_CONTEXT_FOR_PROMPT_PENDING') {
          // The parent has accepted the request. Some context reads can
          // legitimately take longer than the short bridge-health timeout.
          armTimeout(data.timeoutMs);
          return;
        }
        if (data.type !== 'DINSIDE_CONTEXT_FOR_PROMPT_RESULT') return;
        console.log('[DinSide bridge] context response', data);
        finish({
          envelope: data.ok ? (data.envelope || '') : '',
          screenshot: '',
          deliveryToken: data.ok ? (data.deliveryToken || '') : '',
          requestId,
          failed: !data.ok,
          error: data.error || ''
        });
      };

      const requestFromParent = () => {
        if (parentFallbackStarted || settled || window.parent === window) return false;
        parentFallbackStarted = true;
        window.parent.postMessage({
          type: 'DINSIDE_GET_CONTEXT_FOR_PROMPT',
          requestId,
          contextMode,
          promptText
        }, '*');
        return true;
      };

      const requestFromRuntime = () => {
        if (runtimeFallbackStarted || settled) return;
        runtimeFallbackStarted = true;
        try {
          chrome.runtime.sendMessage({
            type: 'DINSIDE_GET_CONTEXT_FOR_PROMPT',
            requestId,
            contextMode,
            promptText
          }).then((data) => {
            console.log('[DinSide bridge] context response', data);
            if (!data || settled) return;
            finish({
              envelope: data.ok ? (data.envelope || '') : '',
              screenshot: '',
              deliveryToken: data.ok ? (data.deliveryToken || '') : '',
              requestId,
              failed: !data.ok,
              error: data.error || ''
            });
          }).catch(() => {});
        } catch (_) {}
      };

      window.addEventListener('message', onMessage);
      armTimeout();

      // In DinSide the ChatGPT page is embedded, so the sidepanel parent is the
      // authoritative context provider. Never race it with chrome.runtime: an
      // extension can have multiple sidepanel/tab views alive, and any one of
      // them could answer the runtime message first with unrelated/stale state.
      const requestedParent = requestFromParent();
      if (!requestedParent) requestFromRuntime();
    });
  }

  function dataUrlToFile(dataUrl, filename = `dinside-capture-${Date.now()}.png`) {
    const match = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(dataUrl || '');
    if (!match) throw new Error(t('Invalid screenshot data URL.'));

    const mime = match[1] || 'image/png';
    const isBase64 = Boolean(match[2]);
    const raw = isBase64 ? atob(match[3]) : decodeURIComponent(match[3]);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i += 1) bytes[i] = raw.charCodeAt(i);
    return new File([bytes], filename, { type: mime });
  }

  function fileInputAcceptsImage(input) {
    if (!input || input.disabled) return false;
    const accept = String(input.accept || '').trim().toLowerCase();
    if (!accept) return true;
    return accept.split(',').some((rawToken) => {
      const token = rawToken.trim();
      return token === '*/*' ||
        token.startsWith('image/') ||
        /^\.(?:png|jpe?g|jp2|gif|bmp|tiff?|svg|webp|ico|avif|heic|heif)$/.test(token);
    });
  }

  function attachmentStem(file) {
    return String(file?.name || '').replace(/\.[^.]+$/, '');
  }

  function googleAiModeControlText(control) {
    if (!control) return '';
    return [
      control.getAttribute?.('aria-label'),
      control.getAttribute?.('title'),
      control.getAttribute?.('data-tooltip'),
      control.getAttribute?.('data-testid'),
      control.getAttribute?.('name'),
      control.innerText,
      control.textContent
    ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  }

  function findGoogleAiModeImageInput(composer = getComposer()) {
    const findAcceptedInput = (root) => [...(root?.querySelectorAll?.('input[type="file"]') || [])]
      .filter(fileInputAcceptsImage)
      .at(-1) || null;

    // Prefer an input owned by the composer. Google may also have unrelated
    // image inputs elsewhere on a Search page (for example account controls).
    let scope = composer;
    while (scope && scope !== document.body) {
      const input = findAcceptedInput(scope);
      if (input) return input;
      scope = scope.parentElement;
    }
    return findAcceptedInput(document);
  }

  function findGoogleAiModeAddButton(composer = getComposer()) {
    if (!composer) return null;
    const composerRect = composer.getBoundingClientRect?.();
    if (!composerRect) return null;

    const nearby = [...document.querySelectorAll('button, [role="button"]')].filter((control) => {
      if (!isVisibleSendButton(control)) return false;
      const rect = control.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      return centerX >= composerRect.left - 100 &&
        centerX <= composerRect.right + 100 &&
        centerY >= composerRect.top - 50 &&
        centerY <= composerRect.bottom + 150;
    });

    const addPattern = /(?:^|\b)(?:add|attach|upload|insert|image|photo|file|plus)(?:\b|$)|thêm|đính\s*kèm|tải\s*(?:lên|tệp|ảnh|hình)|(?:chọn|thêm)\s*(?:tệp|ảnh|hình)/i;
    const excludedPattern = /(?:^|\b)(?:send|submit|microphone|mic|voice|dictat|search|close|remove|delete)(?:\b|$)|gửi|micrô|giọng\s*nói|tìm\s*kiếm|đóng|xóa/i;
    const semantic = nearby.find((control) => {
      const text = googleAiModeControlText(control);
      return addPattern.test(text) && !excludedPattern.test(text);
    });
    if (semantic) return semantic;

    // Some AI Mode variants expose the control visually as just "+" without an
    // accessible label. Keep this fallback spatially constrained to the composer.
    return nearby.find((control) => googleAiModeControlText(control).trim() === '+') || null;
  }

  function snapshotGoogleAiModeAttachmentSignals(composer, file) {
    const composerRect = composer?.getBoundingClientRect?.();
    const stem = attachmentStem(file).toLowerCase();
    const signals = new Map();
    if (!composerRect) return signals;

    const selector = [
      'img',
      'canvas',
      '[style*="background-image"]',
      'button[aria-label]',
      '[role="button"][aria-label]',
      '[class*="attachment"]',
      '[class*="preview"]',
      '[class*="upload"]'
    ].join(', ');
    const attachmentPattern = /attach|upload|preview|image|photo|file|remove|delete|đính\s*kèm|tải|ảnh|hình|tệp|xóa/i;

    for (const node of document.querySelectorAll(selector)) {
      const rect = node.getBoundingClientRect?.();
      if (!rect || rect.width < 2 || rect.height < 2) continue;
      const style = getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden') continue;
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      if (centerX < composerRect.left - 120 || centerX > composerRect.right + 120) continue;
      if (centerY < composerRect.top - 320 || centerY > composerRect.bottom + 140) continue;

      const text = googleAiModeControlText(node);
      const src = node.getAttribute?.('src') || '';
      const background = node.style?.backgroundImage || '';
      const className = typeof node.className === 'string' ? node.className : '';
      const isPreviewVisual = (node.matches?.('img, canvas') && rect.width >= 24 && rect.height >= 24) ||
        /blob:|data:image/i.test(`${src} ${background}`);
      if (!isPreviewVisual && !attachmentPattern.test(`${text} ${className}`) && !text.toLowerCase().includes(stem)) {
        continue;
      }
      signals.set(node, `${src}|${background}|${text}|${className}`);
    }
    return signals;
  }

  async function waitForGoogleAiModeAttachment(composer, file, beforeSignals, timeoutMs = 8000) {
    const deadline = performance.now() + timeoutMs;
    while (performance.now() < deadline) {
      const currentComposer = composer?.isConnected ? composer : getComposer();
      if (!currentComposer) return false;
      const currentSignals = snapshotGoogleAiModeAttachmentSignals(currentComposer, file);
      for (const [node, fingerprint] of currentSignals) {
        if (!beforeSignals.has(node) || beforeSignals.get(node) !== fingerprint) return true;
      }
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  async function attachGoogleAiModeScreenshot(file) {
    const composer = getComposer();
    if (!composer) return false;

    let input = findGoogleAiModeImageInput(composer);
    if (!input) {
      const addButton = findGoogleAiModeAddButton(composer);
      if (addButton) {
        addButton.click();
        const inputDeadline = performance.now() + 2500;
        while (performance.now() < inputDeadline) {
          input = findGoogleAiModeImageInput(composer);
          if (input) break;
          await new Promise((resolve) => setTimeout(resolve, 50));
        }
      }
    }

    if (input) {
      const beforeSignals = snapshotGoogleAiModeAttachmentSignals(composer, file);
      const transfer = new DataTransfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      return waitForGoogleAiModeAttachment(composer, file, beforeSignals);
    }

    // Some experiments accept pasted images without ever mounting a file input.
    // This stays as a safe fallback and does not open the native file chooser.
    const beforeSignals = snapshotGoogleAiModeAttachmentSignals(composer, file);
    const transfer = new DataTransfer();
    transfer.items.add(file);
    let pasteEvent;
    try {
      pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: transfer
      });
    } catch (_) {
      return false;
    }
    try { composer.focus({ preventScroll: true }); } catch (_) { composer.focus(); }
    composer.dispatchEvent(pasteEvent);
    return waitForGoogleAiModeAttachment(composer, file, beforeSignals, 6000);
  }

  async function attachGeminiScreenshot(file) {
    const composer = getComposer();
    if (!composer) return false;

    const beforeCloseCount = document.querySelectorAll('button[aria-label="close attachment"]').length;
    const transfer = new DataTransfer();
    transfer.items.add(file);

    let pasteEvent;
    try {
      pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: transfer
      });
    } catch (_) {
      return false;
    }

    try { composer.focus({ preventScroll: true }); } catch (_) { composer.focus(); }
    composer.dispatchEvent(pasteEvent);

    const deadline = performance.now() + 6000;
    while (performance.now() < deadline) {
      const closeCount = document.querySelectorAll('button[aria-label="close attachment"]').length;
      const hasPreviewImage = Boolean(document.querySelector('.attachment-preview-wrapper img'));
      const liveStatus = [...document.querySelectorAll('.cdk-live-announcer-element')]
        .map((node) => (node.textContent || '').trim())
        .filter(Boolean)
        .at(-1) || '';
      if (closeCount > beforeCloseCount && hasPreviewImage && !/uploading/i.test(liveStatus)) return true;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  async function waitForClaudeAttachment(file) {
    const stem = attachmentStem(file);
    const deadline = performance.now() + 7000;
    while (performance.now() < deadline) {
      const remove = [...document.querySelectorAll('button[aria-label^="Remove "]')]
        .find((button) => (button.getAttribute('aria-label') || '').includes(stem));
      const tile = remove?.closest?.('[data-testid="file-thumbnail"]');
      const tileText = (tile?.innerText || tile?.textContent || '').trim();
      if (remove && tile?.querySelector?.('img') && !/loading|uploading/i.test(tileText)) return true;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  function getPerplexityUploadQuotaError() {
    if (provider.id !== 'perplexity') return '';
    const dialogs = [...document.querySelectorAll('[role="dialog"]')];
    const quotaDialog = dialogs.find((dialog) => {
      const text = (dialog.innerText || dialog.textContent || '').replace(/\s+/g, ' ').trim();
      return /upgrade for additional document analysis/i.test(text) ||
        (/upgrade/i.test(text) && /document analysis/i.test(text));
    });
    return quotaDialog ? 'Perplexity file-analysis quota is exhausted or requires an upgrade.' : '';
  }

  async function waitForPerplexityAttachment(file) {
    const stem = attachmentStem(file);
    const deadline = performance.now() + 7000;
    while (performance.now() < deadline) {
      const quotaError = getPerplexityUploadQuotaError();
      if (quotaError) throw new Error(quotaError);

      const preview = [...document.querySelectorAll('button[aria-label^="Preview "]')]
        .find((button) => (button.getAttribute('aria-label') || '').includes(stem));
      const remove = [...document.querySelectorAll('button[aria-label^="Remove "]')]
        .find((button) => (button.getAttribute('aria-label') || '').includes(stem));
      const previewClass = String(preview?.className || '');
      if (preview && remove && !preview.disabled && !/pointer-events-none/.test(previewClass)) return true;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  async function waitForDeepSeekAttachment(file) {
    const stem = attachmentStem(file);
    const deadline = performance.now() + 7000;
    while (performance.now() < deadline) {
      const composer = getComposer();
      let container = composer?.parentElement;
      while (container && container !== document.body && !container.querySelector(SEND_BUTTON_SELECTOR)) {
        container = container.parentElement;
      }
      const hasNamedFile = [...document.querySelectorAll('div')]
        .some((node) => !node.children.length && (node.textContent || '').includes(stem));
      const hasPreview = Boolean(container?.querySelector(
        'img[src], canvas, [style*="background-image"], [class*="preview"], [class*="upload"]'
      ));
      if ((hasNamedFile || hasPreview) && isSendButtonReady(getSendButton(composer))) return true;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  async function waitForOpenRouterAttachment(file) {
    const stem = attachmentStem(file);
    const deadline = performance.now() + 7000;
    while (performance.now() < deadline) {
      const composer = getComposer();
      const composerArea = composer?.closest?.('[data-testid="playground-composer"]');
      const hasNamedFile = [...document.querySelectorAll('div, span')]
        .some((node) => !node.children.length && (node.textContent || '').includes(stem));
      const hasPreview = Boolean(composerArea?.querySelector(
        'img[src], canvas, [style*="background-image"], [class*="preview"], [class*="upload"]'
      ));
      if ((hasNamedFile || hasPreview) && isSendButtonReady(getSendButton(composer))) return true;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  function isVisibleKimiLoginButton() {
    return [...document.querySelectorAll('.login-button')].some((button) => {
      const rect = button.getBoundingClientRect?.();
      if (!rect || rect.width < 2 || rect.height < 2) return false;
      const style = getComputedStyle(button);
      return style.display !== 'none' && style.visibility !== 'hidden';
    });
  }

  async function attachKimiScreenshot(file) {
    // Kimi's own upload handler requires an authenticated account. Do not invoke
    // it in guest mode because that would open Kimi's login UI as a side effect.
    if (isVisibleKimiLoginButton()) {
      throw new Error(t('Kimi requires login to attach screenshots.'));
    }

    const composer = getComposer();
    const chatEditor = composer?.closest?.('.chat-editor');
    if (!composer || !chatEditor) return false;

    const attachmentSelector = '[data-testid="input-attachment-list"] .image-thumbnail';
    const beforeCount = chatEditor.querySelectorAll(attachmentSelector).length;
    const trigger = chatEditor.querySelector('.toolkit-trigger-btn');
    if (!trigger) return false;

    // Kimi only mounts its hidden file input while the + toolkit popover is open.
    // Open that popover programmatically, then wait for Vue to render the input.
    let input = document.querySelector('.toolkit-container input.hidden-input[type="file"]');
    if (!input) {
      trigger.click();
      const inputDeadline = performance.now() + 2500;
      while (performance.now() < inputDeadline) {
        input = document.querySelector('.toolkit-container input.hidden-input[type="file"]');
        if (input) break;
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
    }
    if (!input) return false;

    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));

    // Native file selection closes the toolkit before uploading. Mirror that
    // behavior after Vue has synchronously copied the selected FileList.
    await Promise.resolve();
    await new Promise((resolve) => requestAnimationFrame(resolve));
    if (trigger.classList.contains('active')) trigger.click();

    const uploadDeadline = performance.now() + 12000;
    while (performance.now() < uploadDeadline) {
      const attachments = [...chatEditor.querySelectorAll(attachmentSelector)];
      if (attachments.length > beforeCount) {
        const added = attachments.slice(beforeCount);
        if (added.some((item) => item.classList.contains('error'))) {
          throw new Error(t('Kimi could not upload the screenshot.'));
        }
        if (added.some((item) => item.classList.contains('success') && item.querySelector('img[src]'))) {
          return true;
        }
      }
      if (isVisibleKimiLoginButton()) {
        throw new Error(t('Kimi requires login to attach screenshots.'));
      }
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  async function attachScreenshot(dataUrl) {
    if (!dataUrl) return true;
    if (!isCurrentProviderLocation()) return false;

    const file = dataUrlToFile(dataUrl);
    if (provider.id === 'googleaistudio') {
      const studioComposer = getComposer();
      const box = studioComposer?.closest('ms-prompt-box') ||
        studioComposer?.closest('.prompt-box-container');
      if (!box) return false;
      const before = box.querySelectorAll('img[src], [class*="attachment"], [class*="preview"]').length;
      let input = box.querySelector('input[type="file"]');
      if (!input) {
        const trigger = box.querySelector(
          'button[data-test-id="add-media-button"], button[aria-label^="Insert assets"], button[aria-label^="Insert images"]'
        );
        if (!trigger) return false;
        trigger.click();
        for (let attempt = 0; attempt < 20 && !input; attempt += 1) {
          input = document.querySelector('input[type="file"]');
          if (!input) await new Promise((resolve) => setTimeout(resolve, 50));
        }
      }
      if (!input || !fileInputAcceptsImage(input)) return false;
      const transfer = new DataTransfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      const deadline = performance.now() + 5000;
      while (performance.now() < deadline) {
        const after = box.querySelectorAll('img[src], [class*="attachment"], [class*="preview"]').length;
        if (after > before) {
          sendRuntimeMessageSafely({ type: 'DINSIDE_SCREENSHOT_ATTACHED' });
          return true;
        }
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      return false;
    }
    if (provider.id === 'googleaimode') {
      const ok = await attachGoogleAiModeScreenshot(file);
      if (ok) sendRuntimeMessageSafely({ type: 'DINSIDE_SCREENSHOT_ATTACHED' });
      return ok;
    }
    if (provider.id === 'gemini') {
      const ok = await attachGeminiScreenshot(file);
      if (ok) sendRuntimeMessageSafely({ type: 'DINSIDE_SCREENSHOT_ATTACHED' });
      return ok;
    }
    if (provider.id === 'kimi') {
      const ok = await attachKimiScreenshot(file);
      if (ok) sendRuntimeMessageSafely({ type: 'DINSIDE_SCREENSHOT_ATTACHED' });
      return ok;
    }
    if (provider.id === 'mimo') {
      const composer = getComposer();
      if (!composer) return false;
      // MiMo's editor owns file paste and rejects unsupported image types.
      // Its upload input may only exist while the attachment menu is open.
      const transfer = new DataTransfer();
      transfer.items.add(file);
      const paste = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: transfer
      });
      composer.dispatchEvent(paste);
      if (!paste.defaultPrevented) return false;
      await new Promise((resolve) => setTimeout(resolve, 350));
      sendRuntimeMessageSafely({ type: 'DINSIDE_SCREENSHOT_ATTACHED' });
      return true;
    }

    if (provider.id === 'perplexity') {
      const quotaError = getPerplexityUploadQuotaError();
      if (quotaError) throw new Error(quotaError);
    }

    const input = [...document.querySelectorAll('input[type="file"]')].find(fileInputAcceptsImage);
    if (!input) return false;

    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));

    let ok = true;
    if (provider.id === 'claude') ok = await waitForClaudeAttachment(file);
    else if (provider.id === 'perplexity') ok = await waitForPerplexityAttachment(file);
    else if (provider.id === 'deepseek') ok = await waitForDeepSeekAttachment(file);
    else if (provider.id === 'openrouter') ok = await waitForOpenRouterAttachment(file);
    else await new Promise((resolve) => setTimeout(resolve, 350));

    if (ok) sendRuntimeMessageSafely({ type: 'DINSIDE_SCREENSHOT_ATTACHED' });
    return ok;
  }

  async function injectContextAndSend(trigger = 'unknown', composerOverride = null, options = {}) {
    if (!isEmbeddedProviderView) return false;
    if (sending) return false;
    sending = true;
    let hidePreparing = null;

    try {
      const composer = composerOverride || getComposer();
      const rawUserText = composerText(composer);
      const userText = cleanComposerUserText(rawUserText);
      if (!composer || !userText) return false;

      console.log('[DinSide bridge] intercepted send', {
        trigger,
        userText,
        selectedCount: selectedTextContexts.length,
        skillCount: skillsContext.length
      });

      // Selected text is an extra prompt attachment, not a replacement for the
      // normal page-context lifecycle. Normal sends ask the sidepanel for the
      // context delta; Quick Ask can explicitly skip page context for a tiny,
      // selection-only fast path.
      let promptPayload;
      if (options.skipPageContext) {
        promptPayload = {
          envelope: '',
          deliveryToken: '',
          requestId: `quick-${Date.now()}`,
          failed: false,
          error: ''
        };
      } else {
        // Paint the busy indicator BEFORE requesting page context. A delayed
        // spinner can be starved by context work and makes Send look frozen.
        hidePreparing = showContextPreparingIndicator(composer);
        await new Promise((resolve) => requestAnimationFrame(resolve));
        promptPayload = await getPromptPayload(inferContextMode(userText), userText);
      }

      const {
        envelope,
        deliveryToken,
        requestId,
        failed,
        error
      } = promptPayload;

      if (failed) {
        console.error('[DinSide bridge] context request failed', error);
        notifyContextDelivery('DINSIDE_CONTEXT_INJECT_FAILED', {
          deliveryToken,
          requestId,
          error: error || t('Context request failed; prompt was not sent.')
        });
        return false;
      }

      const selectedSource = Array.isArray(options.selectionOverride)
        ? options.selectionOverride
        : selectedTextContexts;
      const selectedEnvelope = selectedSource.length
        ? serializeSelectedTextContexts(selectedSource)
        : '';

      const contextBody = buildProviderContextBody(envelope, selectedEnvelope, userText, composer);
      const finalPrompt = contextBody
        ? `[USER_MESSAGE]\n${userText}\n\n${contextBody}${provider.id === 'metaai' ? `\n${META_CONTEXT_END_MARKER}` : ''}`
        : userText;

      // Recover cleanly if a previous provider attempt left DinSide's internal
      // envelope in the composer instead of submitting it.
      if (!contextBody && rawUserText !== userText && !replaceComposerText(composer, userText)) return false;

      if (contextBody) {
        console.log('[DinSide bridge] injecting context', {
          userText,
          envelopeLength: envelope?.length || 0,
          selectedEnvelopeLength: selectedEnvelope?.length || 0,
          finalPromptLength: finalPrompt.length
        });
        const ok = provider.id === 'perplexity'
          ? await injectPerplexityContext(composer, userText, contextBody)
          : replaceComposerText(composer, finalPrompt);
        if (!ok) {
          notifyContextDelivery('DINSIDE_CONTEXT_INJECT_FAILED', {
            deliveryToken,
            requestId
          });
          return false;
        }
      }

      // Provider frameworks can update the composer DOM immediately while their
      // Send button state trails behind. Wait for the real enabled control so
      // Quick Ask does not leave a prepared prompt sitting in the composer.
      await Promise.resolve();

      const defaultWaitMs = contextBody ? 1200 : 0;
      const sendButton = await waitForSendButton(
        composer,
        options.sendReadyTimeoutMs ?? defaultWaitMs
      );

      if (sendButton) {
        // Keep the exact pre-injection text around until the provider renders the
        // user turn. This is especially important for Gemini, which may collapse
        // and truncate the long injected prompt before the display compactor runs.
        if (contextBody) queueContextDisplayUserText(
          userText,
          provider.id === 'metaai' ? finalPrompt : ''
        );
        armGuestAuthDismiss();
        bypassNextSend = true;
        sendButton.click();
        if (options.confirmSend) {
          let accepted = await waitForComposerToClear(composer, 800);
          if (!accepted) accepted = await retrySendThroughForm(composer, 1200);
          if (!accepted) {
            console.error('[DinSide bridge] provider did not accept the prepared prompt');
            return false;
          }
        }
        if (deliveryToken) {
          notifyContextDelivery('DINSIDE_CONTEXT_DELIVERED', {
            deliveryToken,
            requestId
          });
        }
        notifyContextDelivery('DINSIDE_PROMPT_SENT', { requestId });
        if (options.afterSendSelectionMode === 'preserveCommitted') {
          selectedTextContexts = selectedTextContexts.slice(0, committedSelectionCount);
          if (selectedTextContexts.length) renderSelectedTextCard();
          else removeSelectedTextCard();
        } else {
          selectedTextContexts = [];
          committedSelectionCount = 0;
          removeSelectedTextCard();
        }
        if (!options.preserveSkills && skillsContext.length) {
          const hasOnceSkills = skillsContext.some((skill) => normalizeSkillLifetime(skill.lifetime) === 'once');
          if (hasOnceSkills) {
            skillsContext = skillsContext.filter((skill) => normalizeSkillLifetime(skill.lifetime) !== 'once');
            renderSkillsCard();
            window.parent.postMessage({ type: 'DINSIDE_SKILLS_CONSUMED' }, '*');
          }
        }
        return true;
      }

      // Quick Ask must only claim success after clicking the provider's real
      // Send button. Keep the prepared prompt available when that button never
      // becomes ready so the user can still send it manually.
      if (options.requireSendButton) return false;

      // Fallback for temporary provider DOM changes.
      // Keep delivery uncommitted because a synthetic Enter cannot prove that
      // the provider accepted the editor transaction.
      armGuestAuthDismiss();
      bypassNextSend = true;
      composer.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        bubbles: true,
        cancelable: true
      }));
      if (deliveryToken) {
        notifyContextDelivery('DINSIDE_CONTEXT_INJECT_FAILED', {
          deliveryToken,
          requestId
        });
      }
      return false;
    } finally {
      hidePreparing?.();
      setTimeout(() => {
        sending = false;
        bypassNextSend = false;
      }, 250);
    }
  }

  document.addEventListener('click', (event) => {
    if (!isEmbeddedProviderView) return;
    if (!isSendButtonTarget(event.target)) return;

    if (bypassNextSend) {
      return;
    }

    const composer = composerForSendButton(event.target) || getComposer(event.target);
    if (!composer || !composerText(composer)) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    injectContextAndSend('click', composer);
  }, true);

  document.addEventListener('submit', (event) => {
    if (!isEmbeddedProviderView) return;
    const composer = getComposer(event.target?.querySelector?.(COMPOSER_SELECTOR) || document.activeElement);
    if (!composer || !event.target?.contains?.(composer) || !composerText(composer)) return;
    if (bypassNextSend) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    injectContextAndSend('submit', composer);
  }, true);

  globalThis.DinSideI18n?.onChange?.(() => {
    renderSkillsCard({ preservePopover: true });
    renderSelectedTextCard();
    const spinnerText = document.querySelector('#__dinside_context_spinner__ b');
    if (spinnerText) spinnerText.textContent = t('Reading page…');
    document.getElementById('__dinside_bridge_tooltip__')?.remove();
  });

  document.addEventListener('keydown', (event) => {
    if (!isEmbeddedProviderView) return;
    if (event.key !== 'Enter' || event.shiftKey || event.isComposing) return;

    const composer = getComposer(event.target);
    if (!composer || !(event.target === composer || composer.contains(event.target))) return;

    if (bypassNextSend) {
      return;
    }

    if (!composerText(composer)) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    injectContextAndSend('enter', composer);
  }, true);
})();
