(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');
  providers.register({
    id: 'openrouter',
    name: 'OpenRouter',
    shortName: 'OpenRouter',
    frameId: 'providerFrame',
    homeUrl: 'https://openrouter.ai/chat',
    origins: ['https://openrouter.ai'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      try {
        const url = new URL(String(rawUrl || ''));
        return url.origin === 'https://openrouter.ai'
          && url.pathname === '/chat'
          && Boolean(url.searchParams.get('room'));
      } catch (_) {
        return false;
      }
    },
    getChatIdentity(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        const roomId = url.pathname === '/chat' ? url.searchParams.get('room') : '';
        return roomId ? `conversation:${roomId}` : 'draft:default';
      } catch (_) {
        return rawUrl;
      }
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
