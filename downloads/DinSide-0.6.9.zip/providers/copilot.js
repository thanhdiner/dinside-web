(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const conversationIdFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (url.origin !== 'https://copilot.microsoft.com') return '';
      const match = url.pathname.match(/^\/chats\/([^/]+)\/?$/);
      const conversationId = match?.[1] || '';
      return ['new', 'temporary'].includes(conversationId) ? '' : conversationId;
    } catch (_) {
      return '';
    }
  };

  providers.register({
    id: 'copilot',
    name: 'Microsoft Copilot',
    shortName: 'Copilot',
    frameId: 'providerFrame',
    homeUrl: 'https://copilot.microsoft.com/',
    origins: ['https://copilot.microsoft.com'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return Boolean(conversationIdFromUrl(rawUrl));
    },
    getChatIdentity(rawUrl = '') {
      const conversationId = conversationIdFromUrl(rawUrl);
      return conversationId ? `conversation:${conversationId}` : 'draft:default';
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
