(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const NOTEBOOK_HOSTS = new Set(['notebook.google.com', 'notebooklm.google.com']);

  providers.register({
    id: 'notebooklm',
    name: 'NotebookLM',
    shortName: 'NotebookLM',
    frameId: 'providerFrame',
    homeUrl: 'https://notebook.google.com/?pageId=none',
    origins: ['https://notebook.google.com', 'https://notebooklm.google.com'],
    supportsThemeSync: true,
    getAccountUrl(slot = '') {
      const normalized = /^\d$/.test(String(slot)) ? String(slot) : '';
      const params = new URLSearchParams();
      if (normalized) params.set('authuser', normalized);
      params.set('pageId', 'none');
      return `https://notebook.google.com/?${params}`;
    },
    getAccountSlot(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        if (!NOTEBOOK_HOSTS.has(url.hostname)) return null;
        const slot = url.searchParams.get('authuser');
        return /^\d$/.test(String(slot)) ? String(slot) : null;
      } catch (_) {
        return null;
      }
    },
    isRestorableChatUrl(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        return NOTEBOOK_HOSTS.has(url.hostname) && /^\/notebook\/[^/]+/.test(url.pathname);
      } catch (_) {
        return false;
      }
    },
    getChatIdentity(rawUrl = '') {
      try {
        const url = new URL(rawUrl || location.href);
        return /^\/notebook\/[^/]+/.test(url.pathname) ? `${url.hostname}${url.pathname}` : 'home';
      } catch (_) {
        return 'home';
      }
    }
  });
})();
