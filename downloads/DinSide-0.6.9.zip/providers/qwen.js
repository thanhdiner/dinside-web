(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const conversationIdFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (url.origin !== 'https://chat.qwen.ai') return '';
      const match = url.pathname.match(/^\/c\/([^/]+)\/?$/);
      const conversationId = match?.[1] || '';
      return ['new-chat', 'new-branch'].includes(conversationId) ? '' : conversationId;
    } catch (_) {
      return '';
    }
  };

  providers.register({
    id: 'qwen',
    name: 'Qwen',
    shortName: 'Qwen',
    frameId: 'providerFrame',
    homeUrl: 'https://chat.qwen.ai/',
    origins: ['https://chat.qwen.ai'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return Boolean(conversationIdFromUrl(rawUrl));
    },
    getChatIdentity(rawUrl = '') {
      const conversationId = conversationIdFromUrl(rawUrl);
      return conversationId ? `conversation:${conversationId}` : 'draft:default';
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
