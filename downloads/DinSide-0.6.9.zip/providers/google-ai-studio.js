(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const promptIdFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (url.origin !== 'https://aistudio.google.com') return '';
      return url.pathname.match(/^\/(?:u\/\d\/)?prompts\/([^/?#]+)\/?$/)?.[1] || '';
    } catch (_) {
      return '';
    }
  };
  const accountSlotFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (url.origin !== 'https://aistudio.google.com') return null;
      const match = url.pathname.match(/^\/(?:u\/(\d)\/)?prompts\//);
      return match ? (match[1] || '') : null;
    } catch (_) {
      return null;
    }
  };

  providers.register({
    id: 'googleaistudio',
    name: 'Google AI Studio',
    shortName: 'AI Studio',
    frameId: 'providerFrame',
    homeUrl: 'https://aistudio.google.com/prompts/new_chat',
    origins: ['https://aistudio.google.com'],
    supportsThemeSync: true,
    getAccountUrl(slot = '') {
      const normalized = /^\d$/.test(String(slot)) ? String(slot) : '';
      return normalized
        ? `https://aistudio.google.com/u/${normalized}/prompts/new_chat`
        : 'https://aistudio.google.com/prompts/new_chat';
    },
    getAccountSlot(rawUrl = '') {
      return accountSlotFromUrl(rawUrl);
    },
    isRestorableChatUrl(rawUrl) {
      const id = promptIdFromUrl(rawUrl);
      return Boolean(id && id !== 'new_chat');
    },
    getChatIdentity(rawUrl = '') {
      const id = promptIdFromUrl(rawUrl);
      const slot = accountSlotFromUrl(rawUrl) || 'default';
      return id && id !== 'new_chat' ? `conversation:${slot}:${id}` : `draft:${slot}`;
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      const slot = String(previousIdentity || '').match(/^draft:(.+)$/)?.[1];
      return Boolean(slot && String(nextIdentity || '').startsWith(`conversation:${slot}:`));
    }
  });
})();
