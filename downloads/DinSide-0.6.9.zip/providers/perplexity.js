(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');
  providers.register({
    id: 'perplexity',
    name: 'Perplexity',
    shortName: 'Perplexity',
    frameId: 'providerFrame',
    homeUrl: 'https://www.perplexity.ai/',
    origins: ['https://www.perplexity.ai', 'https://perplexity.ai'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return /^https:\/\/(?:www\.)?perplexity\.ai\/search\/[^/?#]+/.test(String(rawUrl || ''));
    },
    getChatIdentity(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        const match = url.pathname.match(/^\/search\/([^/]+)/i);
        return match ? `conversation:${match[1]}` : 'draft:default';
      } catch (_) {
        return rawUrl;
      }
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
