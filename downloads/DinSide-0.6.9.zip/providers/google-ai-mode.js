(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  providers.register({
    id: 'googleaimode',
    name: 'Google AI Mode (Beta)',
    shortName: 'AI Mode',
    frameId: 'providerFrame',
    homeUrl: 'https://www.google.com/ai',
    origins: ['https://www.google.com'],
    supportsThemeSync: true,
    getAccountUrl(slot = '') {
      const normalized = /^\d$/.test(String(slot)) ? String(slot) : '';
      return normalized
        ? `https://www.google.com/search?udm=50&aep=11&authuser=${normalized}`
        : 'https://www.google.com/ai';
    },
    getAccountSlot(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        if (url.hostname !== 'www.google.com') return null;
        const slot = url.searchParams.get('authuser');
        return /^\d$/.test(String(slot)) ? String(slot) : null;
      } catch (_) {
        return null;
      }
    },
    // Google Search does not currently expose a stable public conversation URL
    // for AI Mode. Always start from its entry point instead of restoring a URL
    // that may represent only one generated search response.
    isRestorableChatUrl() {
      return false;
    },
    getChatIdentity() {
      return 'session:google-ai-mode';
    }
  });
})();
