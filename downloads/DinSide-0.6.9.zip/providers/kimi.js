(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const conversationIdFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (!['https://kimi.ai', 'https://www.kimi.ai'].includes(url.origin)) return '';
      const match = url.pathname.match(/^\/chat\/([^/]+)\/?$/);
      const conversationId = match?.[1] || '';
      return conversationId === 'history' ? '' : conversationId;
    } catch (_) {
      return '';
    }
  };

  providers.register({
    id: 'kimi',
    name: 'Kimi',
    shortName: 'Kimi',
    frameId: 'providerFrame',
    homeUrl: 'https://www.kimi.ai/',
    origins: ['https://www.kimi.ai', 'https://kimi.ai'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return Boolean(conversationIdFromUrl(rawUrl));
    },
    getChatIdentity(rawUrl = '') {
      const conversationId = conversationIdFromUrl(rawUrl);
      return conversationId ? `conversation:${conversationId}` : 'draft:default';
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
