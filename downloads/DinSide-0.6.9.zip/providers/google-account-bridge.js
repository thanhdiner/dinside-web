(() => {
  if (window === window.top) return;

  const sidepanelOrigin = `chrome-extension://${chrome.runtime.id}`;
  if (!Array.from(location.ancestorOrigins || []).includes(sidepanelOrigin)) return;
  let connected = false;
  let helloAttempts = 0;
  const announce = () => {
    if (connected || helloAttempts++ >= 10) return;
    window.top.postMessage({ type: 'DINSIDE_GOOGLE_ACCOUNT_BRIDGE_HELLO' }, sidepanelOrigin);
    setTimeout(announce, 300);
  };

  window.addEventListener('message', (event) => {
    if (event.origin === sidepanelOrigin && event.data?.type === 'DINSIDE_GOOGLE_ACCOUNT_BRIDGE_ACK') {
      connected = true;
    }
  });
  announce();

  // Google's account picker can navigate the top window or open a new tab.
  // Keep account changes inside the active DinSide provider iframe.
  document.addEventListener('click', (event) => {
    if (!connected || event.button !== 0 || event.defaultPrevented) return;
    // AI Studio implements Switch account as a button and navigates its own
    // window to accounts.google.com. In a sidebar that would navigate the
    // embedded frame to Google's non-embeddable sign-in page.
    if (location.hostname === 'aistudio.google.com' &&
        event.target?.closest?.('button.switch-account-button')) {
      event.preventDefault();
      event.stopImmediatePropagation();
      const returnUrl = new URL('/prompts/new_chat', location.origin);
      const accountUrl = new URL('https://accounts.google.com/AccountChooser');
      accountUrl.searchParams.set('continue', returnUrl.href);
      // Force Google's account list. Without faa=1 Google may silently reuse
      // the last account and never let the user choose another one.
      accountUrl.searchParams.set('faa', '1');
      window.top.postMessage({ type: 'DINSIDE_GOOGLE_ACCOUNT_OPEN', url: accountUrl.href }, sidepanelOrigin);
      return;
    }
    const link = event.target?.closest?.('a[href]');
    if (!link) return;

    let url;
    try {
      url = new URL(link.href, location.href);
    } catch (_) {
      return;
    }
    // Google's profile avatar is an expandable button whose fallback href is
    // SignOutOptions. Let Google's own handler open the account picker first.
    if (link.getAttribute('role') === 'button' && link.hasAttribute('aria-expanded')) return;
    const isExternalAccountAction =
      ['ogs.google.com', 'gemini.google.com', 'notebook.google.com', 'notebooklm.google.com', 'aistudio.google.com'].includes(location.hostname) &&
      url.protocol === 'https:' &&
      ['accounts.google.com', 'myaccount.google.com', 'myactivity.google.com'].includes(url.hostname);
    if (isExternalAccountAction) {
      event.preventDefault();
      event.stopImmediatePropagation();
      window.top.postMessage({
        type: 'DINSIDE_GOOGLE_ACCOUNT_OPEN',
        url: url.href
      }, sidepanelOrigin);
      return;
    }
    const isAiModeAccount = location.hostname === 'ogs.google.com' &&
      url.origin === 'https://www.google.com' && url.pathname === '/webhp';
    const isGeminiAccount = ['gemini.google.com', 'ogs.google.com'].includes(location.hostname) &&
      url.origin === 'https://gemini.google.com' &&
      /^(?:\/u\/\d)?\/app\/?$/.test(url.pathname);
    const notebookOrigin = new URLSearchParams(location.search).get('origin');
    const isNotebookAccount =
      ['ogs.google.com', 'notebook.google.com', 'notebooklm.google.com'].includes(location.hostname) &&
      (['https://notebook.google.com', 'https://notebooklm.google.com'].includes(url.origin) ||
        (location.hostname === 'ogs.google.com' &&
          ['https://notebook.google.com', 'https://notebooklm.google.com'].includes(notebookOrigin) &&
          url.origin === location.origin)) &&
      url.pathname === '/';
    if (!isAiModeAccount && !isGeminiAccount && !isNotebookAccount) return;
    const slot = url.searchParams.get('authuser');
    if (!/^\d$/.test(slot || '')) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    window.top.postMessage({
      type: 'DINSIDE_GOOGLE_ACCOUNT_SWITCH',
      providerId: isNotebookAccount ? 'notebooklm' : isGeminiAccount ? 'gemini' : 'googleaimode',
      slot
    }, sidepanelOrigin);
  }, true);
})();
