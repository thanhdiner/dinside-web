(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const conversationIdFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (!['https://meta.ai', 'https://www.meta.ai'].includes(url.origin)) return '';
      return url.pathname.match(/^\/(?:c|prompt)\/([^/]+)\/?$/)?.[1] || '';
    } catch (_) {
      return '';
    }
  };

  providers.register({
    id: 'metaai',
    name: 'Meta AI',
    shortName: 'Meta AI',
    frameId: 'providerFrame',
    homeUrl: 'https://www.meta.ai/',
    origins: ['https://www.meta.ai', 'https://meta.ai'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return Boolean(conversationIdFromUrl(rawUrl));
    },
    getChatIdentity(rawUrl = '') {
      const conversationId = conversationIdFromUrl(rawUrl);
      return conversationId ? `conversation:${conversationId}` : 'draft:default';
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
