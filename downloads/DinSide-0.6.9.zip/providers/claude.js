(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');
  providers.register({
    id: 'claude',
    name: 'Claude',
    shortName: 'Claude',
    frameId: 'providerFrame',
    homeUrl: 'https://claude.ai/new',
    origins: ['https://claude.ai'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return /^https:\/\/claude\.ai\/chat\/[^/?#]+/.test(String(rawUrl || ''));
    },
    getChatIdentity(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        const match = url.pathname.match(/^\/chat\/([^/]+)/i);
        return match ? `conversation:${match[1]}` : 'draft:default';
      } catch (_) {
        return rawUrl;
      }
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
