(() => {
  // Claude keeps its sidebar controls in a store that is disabled for iframes.
  // Only change a Claude iframe after DinSide identifies it.
  if (window === window.top) return;

  let attempts = 0;
  let started = false;
  let scheduled = false;
  let reported = false;
  const startedAt = performance.now();
  const seenModules = new Set();
  const stores = new Set();
  const subscribedStores = new Set();

  function showNativeLayout(store) {
    try {
      if (store.getState()?.isInIframe !== true) return;
      store.setState({ isInIframe: false });
      if (!reported) {
        reported = true;
        console.info('[DinSide] Claude native iframe layout restored', {
          durationMs: Math.round(performance.now() - startedAt)
        });
      }
    } catch (_) {
      // Claude may change a module export during a page update.
    }
  }

  async function restoreClaudeLayout() {
    attempts += 1;
    const moduleUrls = Array.from(
      document.querySelectorAll('link[rel~="modulepreload"][href]'),
      (link) => link.href
    ).filter((url) => {
      try {
        return new URL(url).protocol === 'https:' && !seenModules.has(url);
      } catch (_) {
        return false;
      }
    });

    const modules = await Promise.all(moduleUrls.map(async (url) => {
      seenModules.add(url);
      try {
        return await import(url);
      } catch (_) {
        return null;
      }
    }));

    for (const module of modules) {
      if (!module) continue;
      for (const store of Object.values(module)) {
        if (typeof store?.getState !== 'function' ||
            typeof store?.setState !== 'function' ||
            typeof store?.subscribe !== 'function') continue;
        stores.add(store);
      }
    }

    let foundLayoutStore = false;
    for (const store of stores) {
      try {
        const state = store.getState();
        if (typeof state?.isInIframe === 'boolean') {
          foundLayoutStore = true;
          showNativeLayout(store);
          if (!subscribedStores.has(store)) {
            store.subscribe(() => showNativeLayout(store));
            subscribedStores.add(store);
          }
        }
      } catch (_) {
        // Claude may change a module export during a page update.
      }
    }

    if (foundLayoutStore) return;
    if (attempts < 40) setTimeout(restoreClaudeLayout, 250);
    else {
      console.warn('[DinSide] Claude layout store not found', {
        preloadedModules: seenModules.size,
        candidateStores: stores.size
      });
    }
  }

  function start() {
    if (started) return;
    started = true;
    restoreClaudeLayout();
  }

  function scheduleStart() {
    if (started || scheduled) return;
    scheduled = true;
    if (typeof requestIdleCallback === 'function') {
      requestIdleCallback(start, { timeout: 1200 });
    } else {
      setTimeout(start, 150);
    }
  }

  document.addEventListener('dinside:claude-embedded', scheduleStart, { once: true });
  if (window.name === 'dinside-provider-frame') {
    if (document.readyState !== 'complete') {
      window.addEventListener('load', scheduleStart, { once: true });
    } else {
      scheduleStart();
    }
  }
})();
