(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const conversationIdFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (url.origin !== 'https://aistudio.xiaomimimo.com') return '';
      return url.hash.match(/^#\/(?:ultra|chat)\/([^/?#]+)\/?(?:[?#]|$)/)?.[1] || '';
    } catch (_) {
      return '';
    }
  };

  providers.register({
    id: 'mimo',
    name: 'Xiaomi MiMo Studio',
    shortName: 'MiMo',
    frameId: 'providerFrame',
    homeUrl: 'https://aistudio.xiaomimimo.com/',
    origins: ['https://aistudio.xiaomimimo.com'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return Boolean(conversationIdFromUrl(rawUrl));
    },
    getChatIdentity(rawUrl = '') {
      const conversationId = conversationIdFromUrl(rawUrl);
      return conversationId ? `conversation:${conversationId}` : 'draft:default';
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
