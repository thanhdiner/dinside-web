(() => {
  if (window === window.top) return;

  const providerHosts = new Set([
    'chat.deepseek.com',
    'claude.ai',
    'perplexity.ai',
    'openrouter.ai',
    'copilot.microsoft.com',
    'chat.qwen.ai',
    'kimi.ai',
    'www.kimi.ai',
    'meta.ai',
    'www.meta.ai',
    'aistudio.xiaomimimo.com',
    'chat.z.ai'
  ]);
  if (!providerHosts.has(location.hostname)) return;
  // DeepSeek has a provider-specific fallback in web-chat-bridge.js where its
  // actual social-login DOM is known. Avoid duplicate auth-tab opens here.
  if (location.hostname === 'chat.deepseek.com') return;

  const authTextPattern = /\b(?:log\s*in|sign\s*in|sign\s*up|register|continue\s+with|oauth|google|apple|microsoft)\b/i;
  const authPathPattern = /\/(?:auth|oauth|login|log[-_]?in|signin|sign[-_]?in|signup|sign[-_]?up)(?:\/|$)/i;
  let lastAuthGestureAt = 0;

  function getAuthTarget(event) {
    const link = event.target?.closest?.('a[href]');
    if (link) {
      let url;
      try {
        url = new URL(link.href, location.href);
      } catch (_) {
        return null;
      }
      const label = [
        link.textContent,
        link.getAttribute('aria-label'),
        link.getAttribute('title')
      ].filter(Boolean).join(' ');
      if (authPathPattern.test(url.pathname) || authTextPattern.test(label)) {
        return url.href;
      }
      return null;
    }

    const button = event.target?.closest?.('button, [role="button"]');
    if (button) {
      const label = [
        button.textContent,
        button.getAttribute('aria-label'),
        button.getAttribute('title'),
        button.getAttribute('data-testid')
      ].filter(Boolean).join(' ');
      if (authTextPattern.test(label)) return location.href;
    }

    // Several providers render social login as a plain div/span. Walk only a
    // few ancestors so a click on the Google label is still caught without
    // treating the whole page as a login control.
    const path = event.composedPath?.() || [];
    const candidates = path.length ? path : [event.target];
    for (const node of candidates) {
      if (!node || typeof node.getAttribute !== 'function') continue;
      const label = [
        node.textContent,
        node.getAttribute?.('aria-label'),
        node.getAttribute?.('title'),
        node.getAttribute?.('data-testid')
      ].filter(Boolean).join(' ').trim();
      if (label.length <= 140 && authTextPattern.test(label)) return location.href;
    }
    if (location.hostname === 'chat.deepseek.com' &&
        /sign\s+in\s+with\s+google/i.test(document.body?.innerText || '') &&
        event.clientY > window.innerHeight * 0.55 &&
        event.clientY < window.innerHeight * 0.92) {
      return location.href;
    }
    return null;
  }

  const handleAuthGesture = (event) => {
    if (typeof event.button === 'number' && event.button !== 0) return;
    const url = getAuthTarget(event);
    if (!url) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (Date.now() - lastAuthGestureAt < 500) return;
    lastAuthGestureAt = Date.now();
    // Post directly to the side panel instead of relying on chrome.runtime
    // from the provider frame. Content scripts can survive an extension reload
    // with an invalidated runtime, while DOM postMessage continues to work.
    window.top.postMessage({
      type: 'DINSIDE_PROVIDER_AUTH_OPEN',
      providerHost: location.hostname,
      url
    }, '*');
  };
  window.addEventListener('pointerdown', handleAuthGesture, true);
  window.addEventListener('click', handleAuthGesture, true);
})();
