(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');
  providers.register({
    id: 'chatgpt',
    name: 'ChatGPT',
    shortName: 'ChatGPT',
    default: true,
    frameId: 'providerFrame',
    homeUrl: 'https://chatgpt.com/',
    origins: ['https://chatgpt.com'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return /^https:\/\/chatgpt\.com\/(c|g|share)\//.test(String(rawUrl || ''));
    },
    getChatIdentity(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        const path = url.pathname.replace(/\/+$/, '') || '/';
        const conversation = path.match(/(?:^|\/)c\/([^/]+)/i);
        const gpt = path.match(/^\/g\/([^/]+)/i);
        const share = path.match(/^\/share\/([^/]+)/i);
        if (conversation) {
          return gpt
            ? `gpt:${gpt[1]}:conversation:${conversation[1]}`
            : `conversation:${conversation[1]}`;
        }
        if (share) return `share:${share[1]}`;
        if (gpt) return `draft:gpt:${gpt[1]}`;
        if (path === '/') return 'draft:default';
        return `route:${path}`;
      } catch (_) {
        return rawUrl;
      }
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      if (previousIdentity === 'draft:default') {
        return nextIdentity.startsWith('conversation:');
      }
      const gptDraft = previousIdentity.match(/^draft:gpt:(.+)$/);
      return Boolean(
        gptDraft &&
        nextIdentity.startsWith(`gpt:${gptDraft[1]}:conversation:`)
      );
    }
  });
})();
