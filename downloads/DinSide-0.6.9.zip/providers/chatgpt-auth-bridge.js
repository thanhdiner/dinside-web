(() => {
  if (window === window.top) return;

  const sidepanelOrigin = `chrome-extension://${chrome.runtime.id}`;
  if (!Array.from(location.ancestorOrigins || []).includes(sidepanelOrigin)) return;
  window.addEventListener('click', (event) => {
    if (event.button !== 0 || event.defaultPrevented) return;
    const link = event.target?.closest?.('a[href]');
    if (!link) return;

    let url;
    try {
      url = new URL(link.href, location.href);
    } catch (_) {
      return;
    }
    if (url.origin !== 'https://chatgpt.com' ||
        !['/auth/login', '/auth/login_with', '/auth/signup'].includes(url.pathname)) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    window.top.postMessage({ type: 'DINSIDE_CHATGPT_AUTH_OPEN', url: url.href }, sidepanelOrigin);
  }, true);
})();
