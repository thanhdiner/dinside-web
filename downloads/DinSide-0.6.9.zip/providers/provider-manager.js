(() => {
  if (window.DinSideProviders) return;
  const registry = new Map();
  let activeId = '';
  let activeMessageOrigin = '';
  function normalizeProvider(provider) {
    if (!provider || typeof provider !== 'object') throw new TypeError('Provider descriptor is required.');
    if (!provider.id || !provider.name || !provider.homeUrl) {
      throw new Error('Provider descriptor requires id, name, and homeUrl.');
    }
    const origins = Array.isArray(provider.origins) ? provider.origins.filter(Boolean) : [];
    if (!origins.length) origins.push(new URL(provider.homeUrl).origin);
    return Object.freeze({
      frameId: 'providerFrame',
      ...provider,
      id: String(provider.id),
      name: String(provider.name),
      homeUrl: String(provider.homeUrl),
      origins: Object.freeze([...new Set(origins.map(String))])
    });
  }
  const api = {
    register(provider) {
      const normalized = normalizeProvider(provider);
      registry.set(normalized.id, normalized);
      if (!activeId || normalized.default === true) activeId = normalized.id;
      return normalized;
    },
    list() {
      return [...registry.values()];
    },
    get(id) {
      return registry.get(String(id || '')) || null;
    },
    getActive() {
      return registry.get(activeId) || null;
    },
    setActive(id) {
      const next = registry.get(String(id || ''));
      if (!next) throw new Error(`Unknown DinSide provider: ${id}`);
      const previous = registry.get(activeId) || null;
      if (previous?.id === next.id) return next;
      activeId = next.id;
      activeMessageOrigin = '';
      window.dispatchEvent(new CustomEvent('dinside:provider-changed', {
        detail: { previous, provider: next }
      }));
      return next;
    },
    getFrame() {
      const provider = api.getActive();
      return document.getElementById(provider?.frameId || 'providerFrame');
    },
    isTrustedMessage(event) {
      const provider = api.getActive();
      const frame = api.getFrame();
      const trusted = Boolean(
        provider &&
        frame?.contentWindow &&
        event?.source === frame.contentWindow &&
        provider.origins.includes(event.origin)
      );
      if (trusted) activeMessageOrigin = event.origin;
      return trusted;
    },
    post(message, { handshake = false } = {}) {
      const provider = api.getActive();
      const frame = api.getFrame();
      if (!provider || !frame?.contentWindow) return false;
      frame.contentWindow.postMessage(message, handshake ? '*' : (activeMessageOrigin || provider.origins[0]));
      return true;
    },
    navigate(url = '') {
      const provider = api.getActive();
      const frame = api.getFrame();
      if (!provider || !frame) return false;
      activeMessageOrigin = '';
      frame.src = url || provider.homeUrl;
      return true;
    },
    isProviderUrl(rawUrl, provider = api.getActive()) {
      if (!provider || !rawUrl) return false;
      try {
        const url = new URL(rawUrl);
        return provider.origins.includes(url.origin);
      } catch (_) {
        return false;
      }
    }
  };
  window.DinSideProviders = api;
})();
