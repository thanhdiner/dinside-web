(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');
  providers.register({
    id: 'deepseek',
    name: 'DeepSeek',
    shortName: 'DeepSeek',
    frameId: 'providerFrame',
    homeUrl: 'https://chat.deepseek.com/',
    origins: ['https://chat.deepseek.com'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return /^https:\/\/chat\.deepseek\.com\/a\/chat\/s\/[^/?#]+/.test(String(rawUrl || ''));
    },
    getChatIdentity(rawUrl = '') {
      try {
        const url = new URL(rawUrl);
        const match = url.pathname.match(/^\/a\/chat\/s\/([^/]+)/i);
        return match ? `conversation:${match[1]}` : 'draft:default';
      } catch (_) {
        return rawUrl;
      }
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
