(() => {
  const providers = window.DinSideProviders;
  if (!providers) throw new Error('DinSide provider manager must load before provider descriptors.');

  const conversationIdFromUrl = (rawUrl = '') => {
    try {
      const url = new URL(rawUrl);
      if (url.origin !== 'https://chat.z.ai') return '';
      return url.pathname.match(/^\/c\/([^/?#]+)\/?$/)?.[1] || '';
    } catch (_) {
      return '';
    }
  };

  providers.register({
    id: 'zai',
    name: 'Z.ai',
    shortName: 'Z.ai',
    frameId: 'providerFrame',
    homeUrl: 'https://chat.z.ai/',
    origins: ['https://chat.z.ai'],
    supportsThemeSync: true,
    isRestorableChatUrl(rawUrl) {
      return Boolean(conversationIdFromUrl(rawUrl));
    },
    getChatIdentity(rawUrl = '') {
      const conversationId = conversationIdFromUrl(rawUrl);
      return conversationId ? `conversation:${conversationId}` : 'draft:default';
    },
    isDraftPromotion(previousIdentity, nextIdentity) {
      return previousIdentity === 'draft:default' && nextIdentity.startsWith('conversation:');
    }
  });
})();
