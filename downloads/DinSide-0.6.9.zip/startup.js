// Let the lightweight loading screen paint before running the main panel code.
(() => {
  try {
    const cachedTheme = localStorage.getItem('dinsideStartupTheme');
    if (cachedTheme === 'light' || cachedTheme === 'dark') {
      document.documentElement.setAttribute('data-theme', cachedTheme);
    }
  } catch (_) {}

  // Start restoring ChatGPT while the loading screen paints and the main panel
  // script initializes. Closing the side panel destroys its iframe, so this
  // starts the network request early instead of waiting for all UI settings.
  const earlyNavigation = { pending: true, url: '' };
  globalThis.DinSideStartupNavigation = earlyNavigation;
  chrome.storage.local.get([
    'dinsideProviderId',
    'dinsideKeepLastChat',
    'dinsideLastChatUrl',
    'dinsideLastChatUrls'
  ]).then((saved) => {
    if (!earlyNavigation.pending) return;
    const providers = globalThis.DinSideProviders;
    const selectedProvider = providers?.get(saved.dinsideProviderId)
      ? saved.dinsideProviderId
      : 'chatgpt';
    if (selectedProvider !== 'chatgpt' || providers?.getActive()?.id !== 'chatgpt') return;
    const frame = document.getElementById('providerFrame');
    if (!frame || frame.hasAttribute('src')) return;
    const provider = providers.get('chatgpt');
    const savedUrl = saved.dinsideLastChatUrls?.chatgpt || saved.dinsideLastChatUrl;
    const url = saved.dinsideKeepLastChat === true && provider.isRestorableChatUrl(savedUrl)
      ? savedUrl
      : provider.homeUrl;
    earlyNavigation.url = url;
    frame.src = url;
  }).catch(() => {
    // The regular startup path below still loads the provider.
  });

  let started = false;
  const start = () => {
    if (started) return;
    started = true;
    const script = document.createElement('script');
    script.src = 'sidepanel.js';
    script.onerror = () => {
      document.querySelector('#startupLoading span').textContent = 'Could not open DinSide.';
    };
    document.body.appendChild(script);
  };

  const afterMarkup = () => {
    requestAnimationFrame(() => setTimeout(start, 0));
    // Hidden panels may pause animation frames until they become visible.
    setTimeout(start, 50);
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', afterMarkup, { once: true });
  } else {
    afterMarkup();
  }
})();
