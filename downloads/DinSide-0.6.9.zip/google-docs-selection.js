// Google Docs renders editor text on canvas, so window.getSelection() is empty.
// Capture only explicit user Copy actions and forward the copied plain text as
// DinSide selected-text context. This script runs in Docs' editor iframes too.
if (!globalThis.__DINSIDE_GOOGLE_DOCS_SELECTION_INITIALIZED__) {
  globalThis.__DINSIDE_GOOGLE_DOCS_SELECTION_INITIALIZED__ = true;

  const SELECTED_TEXT_CONTEXT_STORAGE_KEY = 'dinsideSelectedTextContextEnabled';
  const MAX_SELECTION_CHARS = 12000;
  let selectedTextContextEnabled = true;
  let lastPublishedText = '';
  let lastPublishedAt = 0;
  let clipboardReadTimer = null;
  let pointerStart = null;
  let pointerClipboardSnapshot = null;
  let keyboardClipboardSnapshot = null;
  let automaticCaptureInFlight = false;

  function googleDocsPageInfo() {
    let title = document.title || '';
    let url = location.href;
    try {
      if (window.top !== window && window.top.location.hostname === 'docs.google.com') {
        title = window.top.document.title || title;
        url = window.top.location.href || url;
      }
    } catch (_) {
      const ancestor = location.ancestorOrigins?.[0] || '';
      if (ancestor) url = ancestor;
    }
    return { title, url };
  }

  function publishGoogleDocsSelection(value) {
    if (!selectedTextContextEnabled) return false;
    const text = String(value || '').replace(/\r\n?/g, '\n').trim().slice(0, MAX_SELECTION_CHARS);
    if (!text || (text === lastPublishedText && Date.now() - lastPublishedAt < 800)) return false;
    lastPublishedText = text;
    lastPublishedAt = Date.now();
    const page = googleDocsPageInfo();
    chrome.runtime.sendMessage({
      type: 'DINSIDE_TEXT_SELECTED',
      selection: {
        text,
        title: page.title,
        url: page.url,
        domContext: {
          section: '',
          element: 'google docs selection',
          tag: 'canvas',
          block: 'document',
          blockId: ''
        },
        sourceChunk: ''
      }
    }).catch(() => {});
    return true;
  }

  function clearGoogleDocsSelection() {
    lastPublishedText = '';
    lastPublishedAt = 0;
    const page = googleDocsPageInfo();
    chrome.runtime.sendMessage({
      type: 'DINSIDE_TEXT_SELECTION_CLEARED',
      url: page.url
    }).catch(() => {});
  }

  function isGoogleDocsEditorTarget(target) {
    const element = target?.nodeType === Node.ELEMENT_NODE ? target : target?.parentElement;
    if (!element?.closest) return false;
    return Boolean(element.closest([
      '#docs-editor',
      '.docs-editor-container',
      '.kix-appview-editor',
      '.kix-canvas-tile-content',
      '.kix-canvas-tile-content-container',
      '[role="textbox"]'
    ].join(',')));
  }

  function plainTextFromCopyEvent(event) {
    try {
      return event.clipboardData?.getData('text/plain') || '';
    } catch (_) {
      return '';
    }
  }

  async function publishClipboardText() {
    if (!selectedTextContextEnabled || !navigator.clipboard?.readText) return;
    try {
      publishGoogleDocsSelection(await navigator.clipboard.readText());
    } catch (_) {
      // The synchronous ClipboardEvent path may still have succeeded. Do not
      // request page-level clipboard permission or modify the user's clipboard.
    }
  }

  async function snapshotClipboard() {
    if (!navigator.clipboard?.read || !navigator.clipboard?.write || typeof ClipboardItem !== 'function') {
      return null;
    }
    try {
      const currentItems = await navigator.clipboard.read();
      const restoredItems = [];
      let plainText = '';
      for (const item of currentItems) {
        const data = {};
        for (const type of item.types || []) {
          const blob = await item.getType(type);
          data[type] = blob;
          if (type === 'text/plain' && !plainText) plainText = await blob.text();
        }
        restoredItems.push(new ClipboardItem(data));
      }
      return { items: restoredItems, plainText };
    } catch (_) {
      return null;
    }
  }

  async function restoreClipboard(snapshot) {
    if (!snapshot) return;
    try {
      if (snapshot.items.length) {
        await navigator.clipboard.write(snapshot.items);
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText('');
      }
    } catch (_) {
      // Clipboard formats can change while another app is writing. Selection
      // capture still succeeds, but never retry and overwrite a newer value.
    }
  }

  function activeEditorDocument(root = document) {
    let current = root;
    for (let depth = 0; depth < 5; depth += 1) {
      const active = current.activeElement;
      if (active?.tagName !== 'IFRAME') break;
      try {
        if (!active.contentDocument || active.contentDocument === current) break;
        current = active.contentDocument;
      } catch (_) {
        break;
      }
    }
    return current;
  }

  const wait = (delay) => new Promise((resolve) => setTimeout(resolve, delay));

  async function captureCurrentGoogleDocsSelection(snapshotPromise) {
    if (!selectedTextContextEnabled || automaticCaptureInFlight) return false;
    automaticCaptureInFlight = true;
    const snapshot = await Promise.resolve(snapshotPromise).catch(() => null);
    if (!snapshot) {
      automaticCaptureInFlight = false;
      return false;
    }

    let copied = false;
    try {
      const editorDocument = activeEditorDocument();
      const candidates = editorDocument === document ? [document] : [editorDocument, document];
      for (const candidate of candidates) {
        const attempted = candidate.execCommand?.('copy') === true;
        copied = attempted || copied;
        if (!attempted) continue;

        // Google Docs can finish its clipboard write asynchronously. Keep the
        // copied value long enough for iframe Copy listeners to observe it.
        await wait(80);
        const copiedText = await navigator.clipboard.readText().catch(() => '');
        if (copiedText && copiedText !== snapshot.plainText) {
          publishGoogleDocsSelection(copiedText);
          return true;
        }
      }
      return false;
    } finally {
      if (copied) await restoreClipboard(snapshot);
      automaticCaptureInFlight = false;
    }
  }

  function scheduleClipboardRead(delay = 60) {
    clearTimeout(clipboardReadTimer);
    clipboardReadTimer = setTimeout(() => {
      clipboardReadTimer = null;
      publishClipboardText();
    }, delay);
  }

  // Google Docs normally fills text/plain in its Copy handler. A window bubble
  // listener runs after the editor target/document handlers and can read it
  // without waiting for the system clipboard.
  window.addEventListener('copy', (event) => {
    if (!publishGoogleDocsSelection(plainTextFromCopyEvent(event))) {
      scheduleClipboardRead(40);
    }
  }, false);

  // The editor's hidden event iframe can stop propagation of Copy. Keydown is a
  // second, user-initiated signal; read only after Chrome completes that copy.
  window.addEventListener('keydown', (event) => {
    const navigationKey = /^(?:arrow(?:left|right|up|down)|home|end|pageup|pagedown)$/i.test(event.key);
    if ((event.ctrlKey || event.metaKey) && !event.altKey && String(event.key).toLowerCase() === 'c') {
      scheduleClipboardRead(80);
    }
    if (event.shiftKey && navigationKey) {
      keyboardClipboardSnapshot = snapshotClipboard();
      return;
    }
    if (!event.ctrlKey && !event.metaKey && !event.altKey && (
      navigationKey || event.key === 'Backspace' || event.key === 'Delete' ||
      event.key === 'Enter' || event.key === 'Tab' || event.key.length === 1
    )) {
      clearGoogleDocsSelection();
    }
  }, true);

  window.addEventListener('keyup', (event) => {
    if (!event.shiftKey && !/^(?:arrow(?:left|right|up|down)|home|end|pageup|pagedown)$/i.test(event.key)) return;
    const snapshot = keyboardClipboardSnapshot;
    keyboardClipboardSnapshot = null;
    if (snapshot) captureCurrentGoogleDocsSelection(snapshot);
  }, true);

  window.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    pointerStart = {
      x: event.clientX,
      y: event.clientY,
      editor: isGoogleDocsEditorTarget(event.target)
    };
    pointerClipboardSnapshot = snapshotClipboard();
  }, true);

  window.addEventListener('pointerup', (event) => {
    if (event.button !== 0 || !pointerStart) return;
    const moved = Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y) >= 4;
    const selectionGesture = moved || event.detail >= 2;
    const startedInEditor = pointerStart.editor;
    const snapshot = pointerClipboardSnapshot;
    pointerStart = null;
    pointerClipboardSnapshot = null;
    if (!selectionGesture) {
      if (startedInEditor || isGoogleDocsEditorTarget(event.target)) {
        requestAnimationFrame(clearGoogleDocsSelection);
      }
      return;
    }
    if (!snapshot) return;
    requestAnimationFrame(() => captureCurrentGoogleDocsSelection(snapshot));
  }, true);

  try {
    chrome.storage.local.get(SELECTED_TEXT_CONTEXT_STORAGE_KEY).then((saved) => {
      selectedTextContextEnabled = saved[SELECTED_TEXT_CONTEXT_STORAGE_KEY] !== false;
    }).catch(() => {});
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local' || !changes[SELECTED_TEXT_CONTEXT_STORAGE_KEY]) return;
      selectedTextContextEnabled = changes[SELECTED_TEXT_CONTEXT_STORAGE_KEY].newValue !== false;
      if (!selectedTextContextEnabled) lastPublishedText = '';
    });
  } catch (_) {}
}
