<p align="center">
  <img src="icons/icon128.png" alt="DinSide" width="96" height="96">
</p>

<h1 align="center">DinSide</h1>

<p align="center">
  <strong>Bring the page you are reading into the AI chat you already use.</strong>
</p>

<p align="center">
  A Chrome Manifest V3 side-panel extension that captures useful browser context and sends it to ChatGPT, Gemini, Google AI Mode, Google AI Studio, NotebookLM, Claude, Perplexity, DeepSeek, OpenRouter, Microsoft Copilot, Qwen, Kimi, Meta AI, Xiaomi MiMo Studio, or Z.ai without turning DinSide into another chatbot.
</p>

<p align="center">
  <strong>Chrome MV3</strong> · <strong>v0.6.9</strong> · <strong>15 providers</strong>
</p>

<p align="center">
  <a href="#quick-start">Quick Start</a> ·
  <a href="#what-dinside-does">Features</a> ·
  <a href="#how-it-works">Architecture</a> ·
  <a href="#current-limitations">Limitations</a>
</p>

---

## Why DinSide exists

AI chat is much more useful when it understands what you are looking at. Copying URLs, paragraphs, selections, and screenshots into a chat by hand breaks the browsing flow and often sends either too much context or the wrong context.

DinSide sits between the browser and the AI web app. It gathers page context, keeps that context manageable, and injects it into the provider composer when needed. The AI provider still does the reasoning; DinSide handles the browser-context pipeline.

## What DinSide does

| Capability | What it gives you |
|---|---|
| **Multi-provider side panel** | Use ChatGPT, Gemini, Google AI Mode (Beta), Google AI Studio, NotebookLM, Claude, Perplexity, DeepSeek, OpenRouter, Microsoft Copilot, Qwen, Kimi, Meta AI, Xiaomi MiMo Studio, or Z.ai from the same Chrome side panel. |
| **Page context** | Reads the active page title, URL, page content, links, image references, Google Docs, and text-based PDFs—including Drive PDFs embedded in Google Classroom. |
| **Viewport context** | Tracks what is currently visible so prompts such as “this part” or “here” can be grounded in the current viewport. |
| **Selected context** | Captures selected text and supports keeping multiple selections when needed. |
| **Smart Context** | Chooses between viewport, cached, and fuller page context using prompt and page-state signals. |
| **Page updates** | Supports smart, diff, and full page-context update modes. |
| **Pinned context** | Pin a full page or the current viewport so useful context stays available beyond a single prompt. |
| **Open-tab context picker** | Add or remove readable tabs from context directly through a compact single-list picker with optimistic UI. |
| **Context Inspector** | Shows what DinSide currently has available before it is sent. |
| **Quick Ask** | Run built-in or custom actions directly from selected webpage text. Custom actions support icons and reordering. |
| **Screenshots** | Captures screenshots and attaches them when the provider exposes a compatible file input. |
| **Provider isolation** | Provider-specific selectors and behavior stay under `providers/` while the context pipeline remains shared. |

## Quick Start

DinSide currently runs as an unpacked Chrome extension.

### 1. Clone

```bash
git clone https://github.com/thanhdiner/DinSide.git
cd DinSide
```

### 2. Load the extension

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select the cloned `DinSide` directory.
5. Open DinSide from its toolbar icon or Chrome Side Panel.

The manifest also defines `Ctrl+Shift+Y` on Windows/Linux and `Command+Shift+Y` on macOS as the suggested action shortcut.

The generated UI assets are committed, so using the extension does not require an npm install or build step. npm is only needed when rebuilding the Thinking Orbs canvas bundle.

## Using DinSide

Open a normal webpage, then open DinSide. Choose one of the supported AI providers and continue using that provider's web chat inside the side panel.

DinSide can collect page, viewport, selection, pinned, open-tab, and screenshot context. Immediately before a message is sent, the relevant context is prepared for the provider composer rather than requiring you to manually paste the page into the conversation.

The context menu provides **Pin this page** and **Pin viewport** for explicit context capture. Under **Open Tabs**, each readable tab can be toggled directly from its row. Selected tabs stay in place and use a compact check-circle state; the header exposes a clear action whenever one or more tabs are selected. Selection uses optimistic UI so the visible state updates immediately while page capture is completed in the background.

For selected text, the on-page Quick Ask launcher provides built-in actions such as Explain, Translate, and Summarize. Custom actions can be created and reordered from DinSide settings.

Google Docs uses a canvas editor rather than a normal DOM selection. DinSide captures a mouse- or keyboard-selected Google Docs range through the editor's Copy command and restores the previous clipboard contents afterward. An explicit `Ctrl+C` (`Cmd+C` on macOS) is also captured. The ordinary floating Quick Ask launcher is not available for a Google Docs canvas selection.

PDF selections are captured inside accessible Google Drive/Classroom viewer frames as well as from direct text-based PDF URLs. DinSide first uses the viewer's text selection and falls back to a temporary Copy operation for canvas-based viewers, restoring the previous clipboard contents afterward. Chrome PDF guest viewers that do not expose their selection to extensions require an explicit `Ctrl+C` (`Cmd+C` on macOS); DinSide captures that Copy event and never substitutes the previous selection.

## Context controls

DinSide exposes controls for how aggressively browser context is prepared:

- **Context loading:** `On demand`, `Smart`, or `Preload`.
- **Page updates:** `Smart`, `Diff`, or `Full`.
- **Compression:** configurable context compression modes.
- **Pinned/Open Tabs:** pin a page or viewport directly, or manage context across readable tabs from a compact single list.
- **Context Inspector:** inspect available full-page, viewport, selection, pinned, and skill context.

`Smart` mode uses deterministic page and prompt signals to decide whether a cheaper viewport/cached context is sufficient or whether fuller page context should be prepared.

## How it works

```mermaid
flowchart LR
    Page[Active webpage] --> Capture[DinSide context capture]
    Capture --> Core[Context pipeline]
    Core --> Manager[Provider manager]
    Manager --> ChatGPT
    Manager --> Gemini
    Manager --> GoogleAIMode[Google AI Mode]
    Manager --> GoogleAIStudio[Google AI Studio]
    Manager --> NotebookLM
    Manager --> Claude
    Manager --> Perplexity
    Manager --> DeepSeek
    Manager --> OpenRouter
    Manager --> Copilot
    Manager --> Qwen
    Manager --> Kimi
    Manager --> MetaAI[Meta AI]
    Manager --> MiMo[MiMo Studio]
    Manager --> Zai[Z.ai]
    ChatGPT --> Bridge[Shared web-chat bridge]
    Gemini --> Bridge
    GoogleAIMode --> Bridge
    GoogleAIStudio --> Bridge
    NotebookLM --> Bridge
    Claude --> Bridge
    Perplexity --> Bridge
    DeepSeek --> Bridge
    OpenRouter --> Bridge
    Copilot --> Bridge
    Qwen --> Bridge
    Kimi --> Bridge
    MetaAI --> Bridge
    MiMo --> Bridge
    Zai --> Bridge
```

The main boundaries are deliberately small:

- `content.js` handles webpage-side capture and Quick Ask UI.
- `sidepanel.js` manages side-panel state, context preparation, settings, and provider interaction.
- `providers/provider-manager.js` manages provider selection.
- `providers/chatgpt.js`, `gemini.js`, `google-ai-mode.js`, `google-ai-studio.js`, `notebooklm.js`, `claude.js`, `perplexity.js`, `deepseek.js`, `openrouter.js`, `copilot.js`, `qwen.js`, `kimi.js`, `meta-ai.js`, `mimo.js`, and `zai.js` hold provider descriptors.
- `providers/web-chat-bridge.js` contains the shared integration layer used inside supported provider web apps.
- `vendor/Readability.js` provides local article/content extraction support.
- `vendor/pdfjs/` contains Mozilla PDF.js 4.10.38, pinned for local PDF text extraction.
- `vendor/thinking-orbs.js` is the locally bundled Thinking Orbs canvas engine used for provider connection and context-preparation feedback.

## Permissions

The current Manifest V3 configuration requests `sidePanel`, `activeTab`, `scripting`, `tabs`, `storage`, `cookies`, `browsingData`, and `declarativeNetRequestWithHostAccess`, plus host access required for webpage context capture and supported provider integration. The `cookies` permission mirrors only MiMo's non-HttpOnly `xiaomichatbot_ph` identifier into its extension iframe so the embedded page can recognize the same session as a normal tab.

Review [`manifest.json`](manifest.json) for the exact permission and host declarations before installing the unpacked extension.

## Current limitations

- Chrome internal pages such as `chrome://extensions`, the Chrome Web Store, and other privileged pages cannot be read by normal extension content scripts.
- Provider integrations depend on the DOM and capabilities exposed by each provider's web app, so provider UI changes can require selector or bridge updates.
- Google AI Mode support is experimental and starts from a fresh AI Mode entry point when selected because Google Search does not expose a stable public conversation URL.
- Screenshot attachment is only available where the provider exposes a compatible file input.
- Image-only/scanned PDFs require OCR and currently do not expose extractable text to DinSide.
- Pinned context is currently capped at 10 items across pinned pages, pinned viewports, and selected open-tab page contexts.
- DinSide is currently distributed from source as an unpacked extension; generated assets are committed so loading the extension still has no mandatory build step.

## Repository layout

```text
DinSide/
├── background.js
├── content.js
├── sidepanel.html
├── sidepanel.css
├── sidepanel.js
├── manifest.json
├── package.json
├── rules.json
├── scripts/
│   └── thinking-orbs-entry.js
├── icons/
├── providers/
│   ├── provider-manager.js
│   ├── web-chat-bridge.js
│   ├── chatgpt.js
│   ├── gemini.js
│   ├── google-ai-mode.js
│   ├── notebooklm.js
│   ├── claude.js
│   ├── perplexity.js
│   ├── deepseek.js
│   ├── openrouter.js
│   ├── copilot.js
│   ├── qwen.js
│   ├── kimi.js
│   ├── meta-ai.js
│   └── mimo.js
└── vendor/
    ├── Readability.js
    ├── thinking-orbs.js
    └── pdfjs/
```

## Development

After editing extension files, reload DinSide from `chrome://extensions`. When `content.js` changes, reload the target webpage as well so Chrome injects the updated content script.

When changing `scripts/thinking-orbs-entry.js`, rebuild its committed browser asset with:

```bash
npm install
npm run build:orbs
```

There is currently no automated test or lint command in the repository. Validate changes by reloading the unpacked extension and exercising the affected browser/provider flow.

---

<p align="center">
  <strong>DinSide keeps browser context close to the AI you already use.</strong>
</p>
