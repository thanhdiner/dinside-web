// Google Drive and Classroom render PDF text inside nested viewer frames. The
// normal DinSide content script runs in the top frame, so publish selections
// from the frame that actually owns the browser Selection.
function isDinSidePdfSelectionFrame() {
  const urls = [location.href, document.referrer, ...Array.from(location.ancestorOrigins || [])].filter(Boolean);
  return urls.some((value) => {
    try {
      const parsed = new URL(value);
      if (/\.pdf$/i.test(parsed.pathname)) return true;
      const originUrl = parsed.protocol === 'blob:' ? new URL(parsed.origin) : parsed;
      if (originUrl.hostname === 'classroom.google.com' || originUrl.hostname === 'drive.google.com') return true;
      if (/googleusercontent\.com$/i.test(originUrl.hostname)) return true;
      return originUrl.hostname === 'docs.google.com' && /^\/(?:viewer|gview)/i.test(parsed.pathname);
    } catch (_) {
      return /^blob:https:\/\/(?:classroom|drive)\.google\.com\//i.test(String(value));
    }
  });
}

if (isDinSidePdfSelectionFrame() && !globalThis.__DINSIDE_PDF_SELECTION_INITIALIZED__) {
  globalThis.__DINSIDE_PDF_SELECTION_INITIALIZED__ = true;

  const SELECTED_TEXT_CONTEXT_STORAGE_KEY = 'dinsideSelectedTextContextEnabled';
  const MAX_SELECTION_CHARS = 12000;
  let selectedTextContextEnabled = true;
  let lastPublishedText = '';
  let lastPublishedAt = 0;
  let captureTimer = null;
  let pointerStart = null;
  let pointerClipboardSnapshot = null;
  let automaticCaptureInFlight = false;
  let lastPointerDownAt = Number.NEGATIVE_INFINITY;
  let lastPointerUpAt = Number.NEGATIVE_INFINITY;
  let copyHintHost = null;
  let copyHintTimer = null;

  function t(value) {
    return globalThis.DinSideI18n?.t?.(value) || value;
  }

  function hideCopyRequiredToast() {
    clearTimeout(copyHintTimer);
    copyHintTimer = null;
    copyHintHost?.remove();
    copyHintHost = null;
  }

  function showCopyRequiredToast() {
    hideCopyRequiredToast();
    if (!document.documentElement) return;

    const host = document.createElement('div');
    host.id = '__dinside_pdf_copy_hint__';
    host.setAttribute('role', 'status');
    host.setAttribute('aria-live', 'polite');
    Object.assign(host.style, {
      position: 'fixed',
      left: '50%',
      bottom: '14px',
      transform: 'translateX(-50%)',
      zIndex: '2147483647',
      maxWidth: 'calc(100vw - 24px)',
      pointerEvents: 'none'
    });

    const shadow = host.attachShadow({ mode: 'closed' });
    const toast = document.createElement('div');
    toast.style.cssText = [
      'display:flex',
      'align-items:center',
      'gap:7px',
      'box-sizing:border-box',
      'max-width:280px',
      'padding:7px 10px',
      'border:1px solid rgba(255,255,255,.16)',
      'border-radius:9px',
      'background:rgba(32,33,36,.96)',
      'color:#fff',
      'box-shadow:0 5px 18px rgba(0,0,0,.3)',
      'font:500 12px/1.25 system-ui,-apple-system,"Segoe UI",sans-serif',
      'white-space:nowrap'
    ].join(';');

    const badge = document.createElement('span');
    badge.textContent = 'Ctrl+C';
    badge.style.cssText = 'flex:0 0 auto;padding:2px 6px;border:1px solid rgba(255,255,255,.3);border-radius:5px;background:rgba(255,255,255,.1);font:700 11px/1.2 system-ui,sans-serif;';

    const copy = document.createElement('span');
    copy.textContent = t('Attach selection to DinSide');
    copy.style.cssText = 'overflow:hidden;text-overflow:ellipsis;opacity:.9;';
    toast.append(badge, copy);
    shadow.appendChild(toast);
    document.documentElement.appendChild(host);
    copyHintHost = host;
    copyHintTimer = setTimeout(hideCopyRequiredToast, 3000);
  }

  function pageInfo() {
    let url = location.href;
    if (/^about:(?:blank|srcdoc)$/i.test(url)) {
      url = location.ancestorOrigins?.[0] || url;
    }
    return { title: document.title || '', url };
  }

  function cleanSelection(value = '') {
    return String(value || '')
      .replace(/\r\n?/g, '\n')
      .split('\n')
      .map((line) => line.replace(/[\t ]+/g, ' ').trim())
      .filter(Boolean)
      .join('\n')
      .trim()
      .slice(0, MAX_SELECTION_CHARS);
  }

  function selectionFromRoot(root) {
    try {
      const selection = root?.getSelection?.();
      const text = cleanSelection(selection?.toString?.() || '');
      if (selection?.rangeCount && text) return { selection, text };
    } catch (_) {}
    return null;
  }

  function currentSelection() {
    const normal = selectionFromRoot(window);
    if (normal) return normal;

    // Some Drive viewer versions place their text layer in an open shadow root.
    const roots = [document];
    for (let index = 0; index < roots.length && index < 500; index += 1) {
      const root = roots[index];
      const shadowSelection = root !== document ? selectionFromRoot(root) : null;
      if (shadowSelection) return shadowSelection;
      for (const element of root.querySelectorAll?.('*') || []) {
        if (element.shadowRoot) roots.push(element.shadowRoot);
      }
    }
    return null;
  }

  function send(type, payload) {
    try {
      const result = chrome.runtime.sendMessage({ type, ...payload });
      result?.catch?.(() => {});
    } catch (_) {}
  }

  function publishText(rawText, element = 'pdf text') {
    if (!selectedTextContextEnabled) return false;
    const text = cleanSelection(rawText);
    if (!text) return false;
    if (text === lastPublishedText && Date.now() - lastPublishedAt < 800) return true;

    lastPublishedText = text;
    lastPublishedAt = Date.now();
    hideCopyRequiredToast();
    const page = pageInfo();
    send('DINSIDE_TEXT_SELECTED', {
      selection: {
        text,
        title: page.title,
        url: page.url,
        domContext: {
          section: '',
          element,
          tag: '',
          block: 'pdf',
          blockId: ''
        },
        sourceChunk: ''
      }
    });
    return true;
  }

  function clearPublishedSelection() {
    if (!lastPublishedText) return;
    lastPublishedText = '';
    lastPublishedAt = 0;
    send('DINSIDE_TEXT_SELECTION_CLEARED', { url: pageInfo().url });
  }

  function captureSelection({ clear = true } = {}) {
    const snapshot = currentSelection();
    if (snapshot?.text) return publishText(snapshot.text);
    if (clear) clearPublishedSelection();
    return false;
  }

  function scheduleCapture(delay = 0, options) {
    clearTimeout(captureTimer);
    captureTimer = setTimeout(() => captureSelection(options), delay);
  }

  async function snapshotClipboard() {
    const clipboard = globalThis.navigator?.clipboard;
    if (clipboard?.read && clipboard?.write && typeof ClipboardItem === 'function') {
      try {
        const currentItems = await clipboard.read();
        const restoredItems = [];
        let plainText = '';
        for (const item of currentItems) {
          const data = {};
          for (const type of item.types || []) {
            const blob = await item.getType(type);
            data[type] = blob;
            if (type === 'text/plain' && !plainText) plainText = await blob.text();
          }
          restoredItems.push(new ClipboardItem(data));
        }
        return { items: restoredItems, plainText, plainOnly: false };
      } catch (_) {}
    }

    // Cross-origin Drive frames may allow the plain-text clipboard methods but
    // reject the richer ClipboardItem API. Plain text is enough to restore the
    // user's clipboard after our temporary Copy operation.
    if (clipboard?.readText && clipboard?.writeText) {
      try {
        return { items: null, plainText: await clipboard.readText(), plainOnly: true };
      } catch (_) {}
    }
    return null;
  }

  async function restoreClipboard(snapshot) {
    if (!snapshot) return;
    const clipboard = globalThis.navigator?.clipboard;
    try {
      if (Array.isArray(snapshot.items) && snapshot.items.length) await clipboard?.write(snapshot.items);
      else if (clipboard?.writeText) await clipboard.writeText(snapshot.plainText || '');
    } catch (_) {}
  }

  async function captureCanvasSelection(snapshotPromise) {
    if (!selectedTextContextEnabled || automaticCaptureInFlight) return false;
    automaticCaptureInFlight = true;
    const snapshot = await Promise.resolve(snapshotPromise).catch(() => null);
    if (!snapshot) {
      automaticCaptureInFlight = false;
      return false;
    }

    let copied = false;
    try {
      copied = document.execCommand?.('copy') === true;
      if (!copied) return false;
      await new Promise((resolve) => setTimeout(resolve, 80));
      const copiedText = await globalThis.navigator?.clipboard?.readText?.().catch(() => '') || '';
      if (copiedText && copiedText !== snapshot.plainText) {
        return publishText(copiedText, 'pdf copied text');
      }
      return false;
    } finally {
      if (copied) await restoreClipboard(snapshot);
      automaticCaptureInFlight = false;
    }
  }

  function eventClock() {
    return globalThis.performance?.now?.() || Date.now();
  }

  function handleSelectionPointerDown(event) {
    if (event.button !== 0) return;
    const now = eventClock();
    if (now - lastPointerDownAt < 30) return;
    lastPointerDownAt = now;
    send('DINSIDE_PDF_SELECTION_STARTED', { url: pageInfo().url });
    lastPublishedText = '';
    lastPublishedAt = 0;
    pointerStart = { x: event.clientX, y: event.clientY };
    pointerClipboardSnapshot = snapshotClipboard();
  }

  function handleSelectionPointerUp(event) {
    if (event.button !== 0) return;
    const now = eventClock();
    if (now - lastPointerUpAt < 30) return;
    lastPointerUpAt = now;
    const start = pointerStart;
    const clipboardSnapshot = pointerClipboardSnapshot || snapshotClipboard();
    pointerStart = null;
    pointerClipboardSnapshot = null;
    const selectionGesture = Boolean(start) && (
      Math.hypot(event.clientX - start.x, event.clientY - start.y) >= 4 || event.detail >= 2
    );
    requestAnimationFrame(async () => {
      if (captureSelection({ clear: false })) return;
      if (selectionGesture) {
        // Drive's text layer can update one frame after pointerup. Retry before
        // the Copy fallback, and never turn a drag gesture into an immediate
        // clear merely because the viewer exposed its selection late.
        await new Promise((resolve) => setTimeout(resolve, 40));
        if (captureSelection({ clear: false })) return;
        if (!await captureCanvasSelection(clipboardSnapshot)) {
          showCopyRequiredToast();
          send('DINSIDE_PDF_SELECTION_COPY_REQUIRED', { url: pageInfo().url });
        }
        return;
      }
      clearPublishedSelection();
    });
  }

  document.addEventListener('pointerdown', handleSelectionPointerDown, true);
  document.addEventListener('mousedown', handleSelectionPointerDown, true);
  window.addEventListener('pointerup', handleSelectionPointerUp, true);
  window.addEventListener('mouseup', handleSelectionPointerUp, true);

  document.addEventListener('keyup', (event) => {
    if (event.key === 'Shift' || event.shiftKey || event.ctrlKey || event.metaKey) {
      scheduleCapture(0);
    }
  }, true);

  // PDF canvas viewers sometimes populate only the Copy event/clipboard even
  // though their visible highlight is not exposed by window.getSelection().
  window.addEventListener('copy', (event) => {
    const copied = event.clipboardData?.getData('text/plain') || '';
    if (!publishText(copied, 'pdf copied text')) {
      setTimeout(async () => {
        try {
          publishText(await globalThis.navigator?.clipboard?.readText?.(), 'pdf copied text');
        } catch (_) {}
      }, 60);
    }
  }, false);

  document.addEventListener('selectionchange', () => scheduleCapture(120, { clear: false }), true);

  try {
    chrome.storage.local.get(SELECTED_TEXT_CONTEXT_STORAGE_KEY).then((saved) => {
      selectedTextContextEnabled = saved[SELECTED_TEXT_CONTEXT_STORAGE_KEY] !== false;
    }).catch(() => {});
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local' || !changes[SELECTED_TEXT_CONTEXT_STORAGE_KEY]) return;
      selectedTextContextEnabled = changes[SELECTED_TEXT_CONTEXT_STORAGE_KEY].newValue !== false;
      if (!selectedTextContextEnabled) clearPublishedSelection();
    });
  } catch (_) {}
}
