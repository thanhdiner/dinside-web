// Prevent duplicate initialization when Chrome injects this script again into an already-open tab.
if (globalThis.__DINSIDE_CONTENT_INITIALIZED__) {
  // Existing instance owns the listeners.
} else {
  globalThis.__DINSIDE_CONTENT_INITIALIZED__ = true;
  const t = (source, ...values) => {
    if (globalThis.DinSideI18n?.t) return globalThis.DinSideI18n.t(source, ...values);
    const key = Array.isArray(source)
      ? source.reduce((result, part, index) => result + (index ? `{${index - 1}}` : '') + part, '')
      : String(source ?? '');
    return key.replace(/\{(\d+)\}/g, (match, index) => index < values.length ? String(values[index]) : match);
  };

let revision = 1;
let dirty = true;
let lastUrl = location.href;
let dirtyTimer = null;
const validatedContentFingerprints = new Map();
const MAX_VALIDATED_CONTENT_FINGERPRINTS = 8;
const SELECTED_TEXT_CONTEXT_STORAGE_KEY = 'dinsideSelectedTextContextEnabled';
const QUICK_ASK_STORAGE_KEY = 'dinsideQuickAskEnabled';
const QUICK_ASK_CUSTOM_ACTIONS_STORAGE_KEY = 'dinsideQuickAskCustomActionsV1';
const QUICK_ASK_CUSTOM_ACTION_LIMIT = 8;
let selectedTextContextEnabled = true;
let quickAskEnabled = true;
let quickAskCustomActions = [];
let lastSelectionPayload = '';

function normalizeQuickAskCustomActions(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, QUICK_ASK_CUSTOM_ACTION_LIMIT).map((item, index) => ({
    id: String(item?.id || `custom-${index}`).slice(0, 80),
    label: String(item?.label || '').trim().slice(0, 32),
    instruction: String(item?.instruction || '').trim().slice(0, 2000),
    icon: String(item?.icon || 'sparkles').slice(0, 20)
  })).filter((item) => item.label && item.instruction);
}

function readCurrentSelectionText() {
  return selectedTextContextEnabled ? (window.getSelection()?.toString()?.trim() || '') : '';
}

try {
  chrome.storage.local.get([
    SELECTED_TEXT_CONTEXT_STORAGE_KEY,
    QUICK_ASK_STORAGE_KEY,
    QUICK_ASK_CUSTOM_ACTIONS_STORAGE_KEY
  ])
    .then((saved) => {
      selectedTextContextEnabled = saved[SELECTED_TEXT_CONTEXT_STORAGE_KEY] !== false;
      quickAskEnabled = saved[QUICK_ASK_STORAGE_KEY] !== false;
      quickAskCustomActions = normalizeQuickAskCustomActions(saved[QUICK_ASK_CUSTOM_ACTIONS_STORAGE_KEY]);
      if (!selectedTextContextEnabled) lastSelectionPayload = '';
      if (!quickAskEnabled) hideQuickAsk();
    })
    .catch(() => {});
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (changes[SELECTED_TEXT_CONTEXT_STORAGE_KEY]) {
      selectedTextContextEnabled = changes[SELECTED_TEXT_CONTEXT_STORAGE_KEY].newValue !== false;
      lastSelectionPayload = '';
    }
    if (changes[QUICK_ASK_STORAGE_KEY]) {
      quickAskEnabled = changes[QUICK_ASK_STORAGE_KEY].newValue !== false;
      if (!quickAskEnabled) hideQuickAsk();
    }
    if (changes[QUICK_ASK_CUSTOM_ACTIONS_STORAGE_KEY]) {
      quickAskCustomActions = normalizeQuickAskCustomActions(
        changes[QUICK_ASK_CUSTOM_ACTIONS_STORAGE_KEY].newValue
      );
      refreshQuickAskMenu();
    }
  });
} catch (_) {}
const LIMITS = {
  textChars: 50000,
  viewportTextChars: 8000,
  links: 40,
  images: 20,
  buttons: 30,
  viewportBlocks: 80
};

let extensionContextAlive = true;
function markExtensionContextDead() {
  extensionContextAlive = false;
  clearTimeout(dirtyTimer);
  clearTimeout(viewportDirtyTimer);
}
function runtimeIsAlive() {
  try {
    return Boolean(globalThis.chrome?.runtime?.id);
  } catch (_) {
    return false;
  }
}
function safeSendMessage(message) {
  if (!extensionContextAlive) return false;

  try {
    const runtime = globalThis.chrome?.runtime;
    if (!runtime?.id || typeof runtime.sendMessage !== 'function') {
      markExtensionContextDead();
      return false;
    }

    const pending = runtime.sendMessage(message);
    // "Receiving end does not exist" is normal while the side panel is closed.
    // Only disable this injected instance when the extension runtime itself died.
    pending?.catch?.(() => {
      if (!runtimeIsAlive()) markExtensionContextDead();
    });
    return true;
  } catch (_) {
    // Reloading an unpacked extension invalidates already-injected content scripts.
    // Stop talking to the dead runtime instead of throwing on every DOM/scroll event.
    if (!runtimeIsAlive()) markExtensionContextDead();
    return false;
  }
}

function cleanText(value = '') {
  return String(value).replace(/\s+/g, ' ').trim();
}

function isVisible(el) {
  if (!el) return false;
  const style = getComputedStyle(el);
  if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0 && rect.bottom >= 0 && rect.right >= 0 && rect.top <= innerHeight && rect.left <= innerWidth;
}

const CODE_EDITOR_CONTAINER_SELECTORS = [
  '.cm-editor',
  '.cm-content',
  '.CodeMirror',
  '.monaco-editor',
  '.ace_editor',
  '.xterm',
  '#terminal',
  '.terminal',
  '.repl-output',
  '.code-editor',
  '[data-mode-id]'
];
const CODE_EDITOR_CONTAINER_SELECTOR = CODE_EDITOR_CONTAINER_SELECTORS.join(', ');

function isCodeEditorOrTerminalElement(el) {
  if (!el?.closest) return false;
  return Boolean(el.closest(CODE_EDITOR_CONTAINER_SELECTOR));
}

function nearbyText(el) {
  const parent = el.closest('figure, picture, a, p, li, article, section, div');
  if (!parent) return '';
  const text = cleanText(parent.innerText || parent.textContent || '');
  return text.slice(0, 240);
}

function collectLinks(root) {
  return [...root.querySelectorAll('a[href]')]
    .filter(isVisible)
    .map((el) => ({
      text: cleanText(el.innerText || el.getAttribute('aria-label') || el.title || ''),
      href: el.href,
      title: cleanText(el.title || '')
    }))
    .filter((item) => item.href && (item.text || item.title))
    .slice(0, LIMITS.links);
}

function collectImages(root) {
  return [...root.querySelectorAll('img')]
    .filter(isVisible)
    .map((img) => {
      const figure = img.closest('figure');
      const caption = cleanText(figure?.querySelector('figcaption')?.innerText || '');
      return {
        alt: cleanText(img.alt || ''),
        src: img.currentSrc || img.src || '',
        title: cleanText(img.title || ''),
        caption,
        nearbyText: caption || nearbyText(img)
      };
    })
    .filter((item) => item.src)
    .slice(0, LIMITS.images);
}

function collectButtons(root) {
  return [...root.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"]')]
    .filter(isVisible)
    .map((el) => ({
      label: cleanText(el.innerText || el.getAttribute('aria-label') || el.value || el.title || ''),
      disabled: Boolean(el.disabled || el.getAttribute('aria-disabled') === 'true')
    }))
    .filter((item) => item.label)
    .slice(0, LIMITS.buttons);
}

function collectSemanticItems() {
  const selectors = [
    '[data-eventid][role="button"]',
    '[role="button"][aria-label]',
    '[role="link"][aria-label]',
    '[role="gridcell"][aria-label]'
  ].join(', ');

  const items = [...document.querySelectorAll(selectors)]
    .filter(isVisible)
    .map((el) => {
      const rect = el.getBoundingClientRect();
      const text = cleanText(
        el.innerText ||
        el.getAttribute('aria-label') ||
        el.getAttribute('title') ||
        ''
      );

      return {
        tag: el.tagName.toLowerCase(),
        role: el.getAttribute('role') || '',
        text,
        top: Math.round(rect.top),
        eventId: el.getAttribute('data-eventid') || ''
      };
    })
    .filter((item) => item.text);

  // Calendar-like events get priority so generic toolbar controls cannot push them out.
  items.sort((a, b) => Number(Boolean(b.eventId)) - Number(Boolean(a.eventId)) || a.top - b.top);

  const seen = new Set();
  return items.filter((item) => {
    const key = `${item.role}|${item.text}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 80);
}

function getArticleExtractionSignals() {
  const textLength = (document.body?.innerText || document.body?.textContent || '').trim().length;
  const articleCount = document.querySelectorAll('article').length;
  const linkCount = document.querySelectorAll('a[href]').length;
  const mainH1Count = document.querySelectorAll('main h1, article h1, [role="main"] h1').length;
  const ogType = cleanText(document.querySelector('meta[property="og:type"]')?.content || '').toLowerCase();
  const hasArticleSchema = [...document.querySelectorAll('script[type="application/ld+json"]')]
    .some((script) => /Article|BlogPosting|NewsArticle|TechArticle/i.test(script.textContent || ''));
  const strongArticleSignal = ogType === 'article' || hasArticleSchema;
  const singleArticle = articleCount === 1;
  const headingArticle = mainH1Count === 1 && articleCount <= 2 && linkCount < 180;

  const hasCodeEditor = Boolean(document.querySelector(
    '.cm-editor, .monaco-editor, .CodeMirror, .ace_editor, #editor, #terminal'
  ));
  if (hasCodeEditor && !articleCount && !strongArticleSignal) {
    return {
      textLength,
      articleCount,
      linkCount,
      mainH1Count,
      ogType,
      strongArticleSignal,
      articleLike: false
    };
  }

  return {
    textLength,
    articleCount,
    linkCount,
    mainH1Count,
    ogType,
    strongArticleSignal,
    articleLike: textLength >= 700 && (strongArticleSignal || singleArticle || headingArticle)
  };
}

function articleHtmlRoot(html = '') {
  const root = document.createElement('div');
  root.innerHTML = html;
  return root;
}

function articleTextFromRoot(root, fallback = '') {
  if (!root) return String(fallback || '').trim();
  const selector = 'h1,h2,h3,h4,h5,h6,p,li,blockquote,pre,figcaption,th,td, .cm-editor, .monaco-editor, .CodeMirror, .ace_editor, .xterm, #terminal, .terminal';
  const nestedBlockSelector = 'p,li,blockquote,pre,figcaption,th,td, .cm-editor, .monaco-editor, .CodeMirror, .ace_editor, .xterm, #terminal, .terminal';
  const blocks = [...root.querySelectorAll(selector)]
    .filter((el) => {
      if (/^H[1-6]$/.test(el.tagName)) return true;
      const ancestor = el.parentElement?.closest(nestedBlockSelector);
      return !ancestor;
    })
    .map((el) => {
      if (el.tagName === 'PRE' || el.matches?.('.cm-editor, .monaco-editor, .CodeMirror, .ace_editor, .xterm, #terminal, .terminal')) {
        return String(el.innerText || el.textContent || '')
          .replace(/\r\n?/g, '\n')
          .replace(/^\n+|\n+$/g, '');
      }
      return cleanText(el.textContent || '');
    })
    .filter(Boolean);

  const text = (blocks.length ? blocks.join('\n\n') : String(fallback || ''))
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return text;
}

function collectArticleLinks(root) {
  if (!root) return [];
  return [...root.querySelectorAll('a[href]')]
    .map((el) => {
      const rawHref = el.getAttribute('href') || '';
      let href = rawHref;
      try { href = new URL(rawHref, location.href).href; } catch (_) {}
      return {
        text: cleanText(el.textContent || el.getAttribute('aria-label') || el.title || ''),
        href,
        title: cleanText(el.title || '')
      };
    })
    .filter((item) => item.href && (item.text || item.title))
    .slice(0, LIMITS.links);
}

function collectArticleImages(root) {
  if (!root) return [];
  return [...root.querySelectorAll('img')]
    .map((img) => {
      const rawSrc = img.getAttribute('src') || '';
      let src = rawSrc;
      try { src = new URL(rawSrc, location.href).href; } catch (_) {}
      const figure = img.closest('figure');
      const caption = cleanText(figure?.querySelector('figcaption')?.textContent || '');
      return {
        alt: cleanText(img.getAttribute('alt') || ''),
        src,
        title: cleanText(img.getAttribute('title') || ''),
        caption,
        nearbyText: caption
      };
    })
    .filter((item) => item.src)
    .slice(0, LIMITS.images);
}

function tryReadabilityPageContext(selectedText = '') {
  if (typeof Readability !== 'function') return null;
  const signals = getArticleExtractionSignals();
  if (!signals.articleLike) return null;

  const startedAt = performance.now();
  try {
    const article = new Readability(document.cloneNode(true), {
      charThreshold: 400
    }).parse();
    if (!article?.content) return null;

    const articleRoot = articleHtmlRoot(article.content);
    const text = articleTextFromRoot(articleRoot, article.textContent || '').slice(0, LIMITS.textChars);
    if (text.length < 400) return null;

    return {
      title: cleanText(article.title || document.title),
      url: location.href,
      selectedText,
      text,
      links: collectArticleLinks(articleRoot),
      images: collectArticleImages(articleRoot),
      // Readability intentionally strips interactive page chrome. Keeping these
      // empty prevents toolbars/related widgets from leaking back into article context.
      buttons: [],
      semanticItems: [],
      revision,
      extractor: 'readability',
      extractorMs: Math.round((performance.now() - startedAt) * 10) / 10
    };
  } catch (error) {
    console.debug('[DinSide content] Readability fallback', error);
    return null;
  }
}

function getReadablePageContext() {
  const startedAt = performance.now();
  const selectedText = readCurrentSelectionText();
  const articleContext = tryReadabilityPageContext(selectedText);
  if (articleContext) return articleContext;

  const root = document.querySelector('main, article, [role="main"]') || document.body;
  const readableText = (el) => (el?.innerText || el?.textContent || '').trim();
  const text = (readableText(root) || readableText(document.body))
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, LIMITS.textChars);

  return {
    title: document.title,
    url: location.href,
    selectedText,
    text,
    links: collectLinks(root),
    images: collectImages(root),
    buttons: collectButtons(root),
    semanticItems: collectSemanticItems(),
    revision,
    extractor: 'dom',
    extractorMs: Math.round((performance.now() - startedAt) * 10) / 10
  };
}

function collectCodeEditorViewportItems(root = document.body) {
  if (!root?.querySelectorAll) return [];
  const targets = [
    ['.cm-editor .cm-content', 'code'],
    ['.monaco-editor .view-lines', 'code'],
    ['.CodeMirror .CodeMirror-code', 'code'],
    ['.ace_editor .ace_text-layer', 'code'],
    ['.xterm-rows', 'terminal'],
    ['#terminal', 'terminal'],
    ['.terminal', 'terminal']
  ];

  const items = [];
  const processed = new Set();

  for (const [selector, defaultTag] of targets) {
    let elements = [];
    try {
      elements = [...root.querySelectorAll(selector)];
    } catch (_) {
      elements = [];
    }

    for (const el of elements) {
      if (!isVisible(el)) continue;
      const host = el.closest('.cm-editor, .monaco-editor, .CodeMirror, .ace_editor, .xterm, #terminal, .terminal') || el;
      if (processed.has(host)) continue;

      const rawText = String(el.innerText || el.textContent || '').trim();
      if (!rawText) continue;

      processed.add(host);
      const rect = el.getBoundingClientRect();
      const isTerminal = defaultTag === 'terminal' || Boolean(el.closest('#terminal, .terminal, .xterm, .xterm-rows'));

      items.push({
        tag: isTerminal ? 'terminal' : 'code',
        text: rawText.slice(0, 3500),
        top: Math.round(rect.top)
      });
    }
  }

  const standaloneEditor = root.querySelector?.('#editor');
  if (standaloneEditor && isVisible(standaloneEditor) && !processed.has(standaloneEditor)) {
    const raw = String(standaloneEditor.innerText || standaloneEditor.textContent || '').trim();
    if (raw) {
      processed.add(standaloneEditor);
      const rect = standaloneEditor.getBoundingClientRect();
      items.push({
        tag: 'code',
        text: raw.slice(0, 3500),
        top: Math.round(rect.top)
      });
    }
  }

  return items;
}

function getViewportContext() {
  const root = document.querySelector('main, article, [role="main"]') || document.body;
  const doc = document.documentElement;
  const maxScroll = Math.max(0, doc.scrollHeight - innerHeight);
  const scrollPercent = maxScroll > 0 ? Math.round((scrollY / maxScroll) * 100) : 0;

  const candidates = [...root.querySelectorAll(
    'h1, h2, h3, h4, h5, h6, p, li, blockquote, pre, code, figcaption, td, th, [role="heading"]'
  )]
    .filter((el) => isVisible(el) && !isCodeEditorOrTerminalElement(el))
    .map((el) => {
      const rect = el.getBoundingClientRect();
      return {
        tag: el.tagName.toLowerCase(),
        text: cleanText(el.innerText || el.textContent || ''),
        top: Math.round(rect.top)
      };
    })
    .filter((item) => item.text);

  // Rich web apps such as Google Calendar render meaningful cards as interactive
  // DIVs instead of paragraphs/headings. Include those semantic nodes explicitly.
  for (const item of collectSemanticItems()) {
    candidates.push({
      tag: item.eventId ? 'event' : (item.role || item.tag),
      text: item.text,
      top: item.top
    });
  }

  for (const item of collectCodeEditorViewportItems(root)) {
    candidates.push(item);
  }

  candidates.sort((a, b) => a.top - b.top);

  const blocks = [];
  const seen = new Set();
  let usedChars = 0;

  for (const item of candidates) {
    if (seen.has(item.text)) continue;
    if (usedChars >= LIMITS.viewportTextChars || blocks.length >= LIMITS.viewportBlocks) break;

    const remaining = LIMITS.viewportTextChars - usedChars;
    const text = item.text.slice(0, remaining);
    if (!text) break;

    seen.add(item.text);
    blocks.push({ tag: item.tag, text, top: item.top });
    usedChars += text.length;
  }

  const headings = [...root.querySelectorAll('h1, h2, h3, h4, h5, h6, [role="heading"]')]
    .filter(isVisible)
    .map((el) => cleanText(el.innerText || el.textContent || ''))
    .filter(Boolean)
    .slice(0, 20);

  const videos = [...document.querySelectorAll('video')]
    .filter(isVisible)
    .map((video, index) => ({
      id: `video${index + 1}`,
      currentTime: Number.isFinite(video.currentTime) ? Math.round(video.currentTime * 10) / 10 : null,
      duration: Number.isFinite(video.duration) ? Math.round(video.duration * 10) / 10 : null,
      paused: video.paused,
      muted: video.muted,
      playbackRate: video.playbackRate,
      src: video.currentSrc || video.src || '',
      poster: video.poster || ''
    }))
    .slice(0, 5);

  const active = document.activeElement;
  const activeElement = active && active !== document.body && active !== document.documentElement
    ? {
        tag: active.tagName?.toLowerCase() || '',
        role: active.getAttribute?.('role') || '',
        type: active.getAttribute?.('type') || '',
        name: cleanText(active.getAttribute?.('name') || ''),
        label: cleanText(
          active.getAttribute?.('aria-label') ||
          active.getAttribute?.('title') ||
          active.closest?.('label')?.innerText ||
          ''
        ),
        value: ['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName)
          ? String(active.value || '').slice(0, 500)
          : '',
        text: cleanText(active.innerText || active.textContent || '').slice(0, 500)
      }
    : null;

  return {
    title: document.title,
    url: location.href,
    scrollY: Math.round(scrollY),
    scrollPercent,
    viewportWidth: innerWidth,
    viewportHeight: innerHeight,
    documentHeight: document.documentElement.scrollHeight,
    selectedText: readCurrentSelectionText(),
    selection: getDomAwareSelection(),
    blocks,
    headings,
    images: collectImages(root),
    videos,
    activeElement,
    capturedAt: Date.now()
  };
}

let pageSignalsCache = { url: '', capturedAt: 0, value: null };

function getLightweightPageSignals() {
  const now = Date.now();
  if (pageSignalsCache.url === location.href && pageSignalsCache.value && now - pageSignalsCache.capturedAt < 1200) {
    return pageSignalsCache.value;
  }

  const textLength = (document.body?.innerText || '').trim().length;
  const articleCount = document.querySelectorAll('article').length;
  const headingCount = document.querySelectorAll('h1,h2,h3').length;
  const linkCount = document.querySelectorAll('a[href]').length;
  const value = {
    textLength,
    articleCount,
    headingCount,
    linkCount,
    feedLike: articleCount >= 3 && linkCount >= 12
  };
  pageSignalsCache = { url: location.href, capturedAt: now, value };
  return value;
}

const CONTENT_FINGERPRINT_BLOCK_SELECTOR = [
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'li', 'blockquote', 'pre',
  'figcaption', 'td', 'th', '[role="heading"]', '[role="listitem"]',
  '[role="row"]', '[role="cell"]', '[role="gridcell"]', '[data-eventid]',
  '.cm-line', '.view-line', '.ace_line', '#terminal'
].join(',');
const CONTENT_FINGERPRINT_BLOCK_SAMPLES = 16;
const CONTENT_FINGERPRINT_BODY_BLOCK_SAMPLES = 20;
const CONTENT_FINGERPRINT_TEXT_SLICE = 420;

function stableFingerprintTitle(value = document.title) {
  return String(value || '')
    .replace(/^\s*[\[(]\d+[\])]\s*/, '')
    .replace(/\s*[\[(]\d+[\])]\s*$/, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 300);
}

function hashCheapContent(value = '') {
  let hash = 2166136261;
  const input = String(value || '');
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function fingerprintSampleIndexes(length, limit = CONTENT_FINGERPRINT_BLOCK_SAMPLES) {
  if (!length) return [];
  if (length <= limit) return Array.from({ length }, (_, index) => index);
  const indexes = new Set([0, 1, length - 2, length - 1]);
  const slots = Math.max(0, limit - indexes.size);
  for (let step = 1; step <= slots; step += 1) {
    indexes.add(Math.round((step * (length - 1)) / (slots + 1)));
  }
  return [...indexes].filter((index) => index >= 0 && index < length).sort((a, b) => a - b).slice(0, limit);
}

function fingerprintBodySampleIndexes(length, limit = CONTENT_FINGERPRINT_BODY_BLOCK_SAMPLES) {
  if (!length) return [];
  if (length <= limit) return Array.from({ length }, (_, index) => index);
  const indexes = new Set();
  const start = 0.08;
  const span = 0.84;
  for (let step = 0; step < limit; step += 1) {
    const ratio = limit === 1 ? 0.5 : start + (span * step) / (limit - 1);
    indexes.add(Math.round((length - 1) * ratio));
  }
  return [...indexes].sort((a, b) => a - b);
}

function getCheapContentFingerprint() {
  // Match the same broad content-root preference used by the DOM extractor.
  const root = document.querySelector('main, article, [role="main"]') || document.body;
  const rootIsBody = root === document.body;
  const rawText = String(rootIsBody
    ? (document.body?.innerText || document.body?.textContent || '')
    : (root?.textContent || ''));
  const textLength = rawText.length;
  const blockNodes = root?.querySelectorAll?.(CONTENT_FINGERPRINT_BLOCK_SELECTOR) || [];
  const blockCount = blockNodes.length;
  const samples = [];

  const normalizeSample = (value = '') => String(value || '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 260);

  const blockSampleIndexes = rootIsBody
    ? fingerprintBodySampleIndexes(blockCount)
    : fingerprintSampleIndexes(blockCount);
  for (const index of blockSampleIndexes) {
    const node = blockNodes[index];
    if (!node) continue;
    const text = normalizeSample(rootIsBody ? (node.innerText || node.textContent || '') : (node.textContent || ''));
    const tag = String(node.getAttribute?.('role') || node.tagName || '').toLowerCase();
    if (!text || (text.length < 18 && !/^h[1-6]$/.test(tag) && tag !== 'heading')) continue;
    samples.push(`${index}:${tag}:${text}`);
  }

  // Semantic roots get a few distributed slices in addition to their full text
  // hash. Body fallback intentionally avoids positional text slices: tiny header/
  // footer insertions shift character offsets and would create false invalidations.
  if (textLength && !rootIsBody) {
    const points = [0, 0.25, 0.5, 0.75, 1];
    for (const point of points) {
      const maxStart = Math.max(0, textLength - CONTENT_FINGERPRINT_TEXT_SLICE);
      const start = Math.max(0, Math.min(maxStart, Math.round(maxStart * point)));
      const slice = normalizeSample(rawText.slice(start, start + CONTENT_FINGERPRINT_TEXT_SLICE));
      if (slice) samples.push(`text@${Math.round(point * 100)}:${slice}`);
    }
  }

  const structuralLength = rootIsBody ? Math.floor(textLength / 256) : textLength;
  const structuralBlockCount = rootIsBody ? Math.floor(blockCount / 8) : blockCount;
  // We already materialized textContent to get a cheap length/sample. For a
  // semantic main/article root, hashing that text adds no DOM/layout traversal
  // and avoids false "same" results for equal-length edits between samples.
  // Body fallback stays sample-based because app chrome/timers are much noisier.
  const meaningfulTextHash = !rootIsBody && rawText ? hashCheapContent(rawText) : '';
  const signature = [
    'v2',
    location.href,
    stableFingerprintTitle(),
    `root:${String(root?.tagName || '').toLowerCase()}:${root?.getAttribute?.('role') || ''}`,
    `length:${structuralLength}`,
    meaningfulTextHash ? `text:${meaningfulTextHash}` : '',
    `blocks:${structuralBlockCount}`,
    `articles:${root?.querySelectorAll?.('article').length || 0}`,
    `headings:${root?.querySelectorAll?.('h1,h2,h3,[role="heading"]').length || 0}`,
    ...samples
  ].join('\n');

  return {
    url: location.href,
    fingerprint: `v2-${hashCheapContent(signature)}`,
    textLength,
    blockCount,
    root: String(root?.tagName || '').toLowerCase(),
    mode: rootIsBody ? 'sampled-body' : 'semantic-root'
  };
}

function captureContentFingerprintBaseline() {
  const baseline = getCheapContentFingerprint();
  if (!baseline?.url) return baseline;
  validatedContentFingerprints.delete(baseline.url);
  validatedContentFingerprints.set(baseline.url, baseline);
  while (validatedContentFingerprints.size > MAX_VALIDATED_CONTENT_FINGERPRINTS) {
    validatedContentFingerprints.delete(validatedContentFingerprints.keys().next().value);
  }
  return baseline;
}

function validateContentFingerprint(expectedUrl = '') {
  const currentUrl = location.href;
  if (expectedUrl && expectedUrl !== currentUrl) {
    return {
      same: false,
      changed: true,
      reason: 'url-mismatch',
      url: currentUrl,
      revision,
      dirty
    };
  }

  const baseline = validatedContentFingerprints.get(currentUrl) || null;
  if (!baseline) {
    return {
      same: false,
      changed: true,
      reason: 'no-baseline',
      url: currentUrl,
      revision,
      dirty
    };
  }

  // Refresh recency so SPA back/forward routes keep their own small per-page
  // validation state without allowing one route's baseline to affect another.
  validatedContentFingerprints.delete(currentUrl);
  validatedContentFingerprints.set(currentUrl, baseline);

  const startedAt = performance.now();
  const current = getCheapContentFingerprint();
  const validationMs = performance.now() - startedAt;
  const same = current.fingerprint === baseline.fingerprint;
  if (same) dirty = false;
  return {
    same,
    changed: !same,
    reason: same ? 'fingerprint-match' : 'fingerprint-changed',
    url: currentUrl,
    revision,
    dirty,
    fingerprint: current.fingerprint,
    baselineFingerprint: baseline.fingerprint,
    textLength: current.textLength,
    blockCount: current.blockCount,
    root: current.root,
    validationMs
  };
}

function getPageState() {
  return {
    title: document.title,
    url: location.href,
    selectedText: readCurrentSelectionText(),
    selection: getDomAwareSelection(),
    selectionDragging: pointerSelecting,
    documentHeight: document.documentElement.scrollHeight,
    viewportHeight: innerHeight,
    ...getLightweightPageSignals(),
    revision,
    dirty
  };
}

function markDirty(reason = 'dom') {
  if (!extensionContextAlive) return;
  dirty = true;
  revision += 1;

  clearTimeout(dirtyTimer);
  dirtyTimer = setTimeout(() => {
    safeSendMessage({
      type: 'DINSIDE_PAGE_DIRTY',
      state: getPageState(),
      reason
    });
  }, 350);
}

const observer = new MutationObserver(() => markDirty('dom'));
observer.observe(document.documentElement, {
  subtree: true,
  childList: true,
  characterData: true
});

// Covers SPA navigation where the document stays alive.
setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    markDirty('navigation');
  }
}, 750);

// Send highlighted webpage text to DinSide immediately after the user finishes
// selecting it. Ignore selections made inside editable controls.
let quickAskHost = null;
let quickAskSelection = null;

function selectionAnchorElement(selection) {
  if (!selection?.anchorNode) return null;
  return selection.anchorNode.nodeType === Node.ELEMENT_NODE
    ? selection.anchorNode
    : selection.anchorNode.parentElement;
}

function selectionIsEditable(selection) {
  const anchor = selectionAnchorElement(selection);
  if (!anchor) return false;
  // Code editors and terminals use contenteditable or custom elements, but users
  // definitely want to highlight code or terminal output to Ask AI / Quick Ask!
  if (isCodeEditorOrTerminalElement(anchor)) return false;

  return Boolean(anchor.closest?.(
    'input, textarea, [contenteditable="true"], [contenteditable="plaintext-only"]'
  ));
}

const SELECTION_BLOCK_SELECTOR = [
  'pre', 'blockquote', 'li', 'td', 'th', 'tr', 'p', 'figcaption', 'dt', 'dd',
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6', '[role="heading"]',
  '[role="listitem"]', '[role="row"]', '[role="cell"]', '[role="gridcell"]',
  '.cm-line', '.cm-content', '.view-line', '.view-lines', '.ace_line', '.CodeMirror-line',
  '.xterm-rows', '#terminal', '.terminal'
].join(',');
const SELECTION_HEADING_SELECTOR = 'h1,h2,h3,h4,h5,h6,[role="heading"]';
const SELECTION_SOURCE_CHUNK_CHARS = 1800;

function selectionNodeElement(node) {
  if (!node) return null;
  return node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
}

function compactSelectionSupportText(value = '') {
  return String(value || '')
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .join('\n')
    .trim();
}

function selectionElementType(element) {
  if (!element?.closest) return 'text';
  const candidates = [
    ['.cm-editor, .cm-content, .CodeMirror, .monaco-editor, .ace_editor, pre, code', 'code block'],
    ['.xterm, #terminal, .terminal, [class*="terminal"], .repl-output', 'terminal output'],
    ['td, th, [role="cell"], [role="gridcell"]', 'table cell'],
    ['tr, [role="row"]', 'table row'],
    ['a[href], [role="link"]', 'link'],
    ['li, [role="listitem"]', 'list item'],
    ['blockquote', 'blockquote'],
    [SELECTION_HEADING_SELECTOR, 'heading'],
    ['p', 'paragraph'],
    ['figcaption', 'figure caption'],
    ['dt', 'definition term'],
    ['dd', 'definition description']
  ];
  for (const [selector, label] of candidates) {
    if (element.closest(selector)) return label;
  }
  return String(element.tagName || 'text').toLowerCase();
}

function selectionBlockElement(range) {
  if (!range) return null;
  const start = selectionNodeElement(range.startContainer);
  const end = selectionNodeElement(range.endContainer);
  const startBlock = start?.closest?.(SELECTION_BLOCK_SELECTOR) || null;
  const endBlock = end?.closest?.(SELECTION_BLOCK_SELECTOR) || null;
  if (startBlock && startBlock === endBlock) return startBlock;

  const common = selectionNodeElement(range.commonAncestorContainer);
  const commonBlock = common?.closest?.(SELECTION_BLOCK_SELECTOR) || null;
  if (commonBlock && (!start || commonBlock.contains(start)) && (!end || commonBlock.contains(end))) {
    const commonText = compactSelectionSupportText(commonBlock.innerText || commonBlock.textContent || '');
    if (commonText.length <= 2600) return commonBlock;
  }
  return startBlock || endBlock || common;
}

function nearestSelectionHeading(block) {
  if (!block) return '';
  if (block.matches?.(SELECTION_HEADING_SELECTOR)) {
    return compactSelectionSupportText(block.innerText || block.textContent || '').slice(0, 240);
  }

  const section = block.closest?.('section, article, main, [role="region"]') || null;
  const root = section || document.querySelector('main, article, [role="main"]') || document.body;
  if (!root?.querySelectorAll) return '';

  let nearest = '';
  for (const heading of root.querySelectorAll(SELECTION_HEADING_SELECTOR)) {
    if (heading === block || heading.contains(block)) {
      nearest = compactSelectionSupportText(heading.innerText || heading.textContent || '');
      break;
    }
    const position = heading.compareDocumentPosition(block);
    if (position & Node.DOCUMENT_POSITION_FOLLOWING) {
      nearest = compactSelectionSupportText(heading.innerText || heading.textContent || '');
      continue;
    }
    if (position & Node.DOCUMENT_POSITION_PRECEDING) break;
  }
  return nearest.slice(0, 240);
}

function selectionSourceChunk(block, exactSelectionText) {
  if (!block) return '';
  const full = compactSelectionSupportText(block.innerText || block.textContent || '');
  const selected = compactSelectionSupportText(exactSelectionText);
  if (!full || full === selected) return '';

  // If the user already selected most of the logical block, sending the block
  // again adds mostly duplicate tokens and very little supporting context.
  if (selected && full.length && selected.length / full.length >= 0.7) return '';
  if (full.length <= SELECTION_SOURCE_CHUNK_CHARS) return full;

  const probe = selected.slice(0, 320);
  let index = probe ? full.indexOf(probe) : -1;
  if (index < 0) index = 0;
  const before = 520;
  let start = Math.max(0, index - before);
  let end = Math.min(full.length, start + SELECTION_SOURCE_CHUNK_CHARS);
  if (end === full.length) start = Math.max(0, end - SELECTION_SOURCE_CHUNK_CHARS);
  return `${start > 0 ? '…' : ''}${full.slice(start, end)}${end < full.length ? '…' : ''}`;
}

function selectionBlockId(block) {
  if (!block?.tagName) return '';
  const parts = [];
  let current = block;
  let depth = 0;
  while (current?.tagName && current !== document.documentElement && depth < 8) {
    const tag = current.tagName.toLowerCase();
    const stableId = String(current.id || '').trim();
    if (stableId && stableId.length <= 80) {
      parts.unshift(`${tag}#${stableId}`);
      break;
    }

    let sameTagIndex = 1;
    let sibling = current.previousElementSibling;
    while (sibling) {
      if (sibling.tagName === current.tagName) sameTagIndex += 1;
      sibling = sibling.previousElementSibling;
    }
    parts.unshift(`${tag}:nth-of-type(${sameTagIndex})`);
    current = current.parentElement;
    depth += 1;
  }
  return parts.join('>');
}

function getDomAwareSelection(selection = window.getSelection()) {
  if (!selectedTextContextEnabled || !selection?.rangeCount || selectionIsEditable(selection)) return null;
  const text = selection.toString();
  if (!text || !text.trim()) return null;

  const range = selection.getRangeAt(0);
  const startElement = selectionNodeElement(range.startContainer) || selectionAnchorElement(selection);
  const block = selectionBlockElement(range);
  const semanticElement = startElement?.closest?.(
    'td, th, [role="cell"], [role="gridcell"], tr, [role="row"], a[href], [role="link"], pre, code, .cm-editor, .CodeMirror, .monaco-editor, .ace_editor, .xterm, #terminal, li, [role="listitem"], blockquote, h1, h2, h3, h4, h5, h6, [role="heading"], p, figcaption, dt, dd'
  ) || startElement;

  return {
    text: text.slice(0, 12000),
    title: document.title,
    url: location.href,
    domContext: {
      section: nearestSelectionHeading(block),
      element: selectionElementType(startElement),
      tag: String(semanticElement?.tagName || '').toLowerCase(),
      block: String(block?.tagName || '').toLowerCase(),
      blockId: selectionBlockId(block)
    },
    sourceChunk: selectionSourceChunk(block, text)
  };
}

function selectionPayloadKey(selection) {
  if (!selection?.text) return '';
  return [
    selection.url || '',
    selection.text,
    selection.domContext?.section || '',
    selection.domContext?.element || '',
    selection.domContext?.block || '',
    selection.domContext?.blockId || '',
    selection.sourceChunk || ''
  ].join('\n');
}

function plainClientRect(rect) {
  return {
    left: rect.left,
    right: rect.right,
    top: rect.top,
    bottom: rect.bottom,
    width: rect.width,
    height: rect.height
  };
}

function getQuickAskSelection(pointerAnchor = null) {
  const selection = window.getSelection();
  const snapshot = getDomAwareSelection(selection);
  if (!quickAskEnabled || !snapshot || snapshot.text.trim().length < 2 || !selection?.rangeCount) return null;

  const range = selection.getRangeAt(0);
  const rects = [...range.getClientRects()]
    .filter((rect) => rect.width || rect.height)
    .map(plainClientRect);
  const fallbackRect = plainClientRect(rects.at(-1) || range.getBoundingClientRect());
  if (!fallbackRect || (!fallbackRect.width && !fallbackRect.height)) return null;

  const pointerUsable = Number.isFinite(pointerAnchor?.clientX) && Number.isFinite(pointerAnchor?.clientY);
  const anchor = pointerUsable
    ? { x: pointerAnchor.clientX, y: pointerAnchor.clientY, source: 'pointer' }
    : { x: fallbackRect.right, y: fallbackRect.bottom, source: 'selection' };

  return {
    ...snapshot,
    locale: navigator.language || 'en',
    rects: rects.length ? rects : [fallbackRect],
    anchor
  };
}

function quickAskTheme() {
  try {
    const bg = getComputedStyle(document.body || document.documentElement).backgroundColor;
    const rgb = bg.match(/[\d.]+/g)?.slice(0, 3).map(Number);
    if (rgb?.length === 3) {
      const luminance = rgb[0] * 0.299 + rgb[1] * 0.587 + rgb[2] * 0.114;
      return luminance >= 160 ? 'light' : 'dark';
    }
  } catch (_) {}
  return matchMedia?.('(prefers-color-scheme: light)')?.matches ? 'light' : 'dark';
}

function hideQuickAsk() {
  quickAskHost?.remove();
  quickAskHost = null;
  quickAskSelection = null;
}

function quickAskCustomIconSvg(key) {
  const icons = {
    sparkles: '<svg viewBox="0 0 24 24"><path d="m12 3 1.35 3.65L17 8l-3.65 1.35L12 13l-1.35-3.65L7 8l3.65-1.35Z"/><path d="m18 13 .8 2.2L21 16l-2.2.8L18 19l-.8-2.2L15 16l2.2-.8Z"/></svg>',
    pencil: '<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
    wand: '<svg viewBox="0 0 24 24"><path d="m15 4 5 5L7 22l-5-5Z"/><path d="m14 5 5 5"/><path d="M6 3v4M4 5h4M19 14v4M17 16h4"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="m20 6-11 11-5-5"/></svg>',
    code: '<svg viewBox="0 0 24 24"><path d="m8 9-4 3 4 3M16 9l4 3-4 3M14 5l-4 14"/></svg>',
    search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>',
    book: '<svg viewBox="0 0 24 24"><path d="M2 4h6a4 4 0 0 1 4 4v12a3 3 0 0 0-3-3H2Z"/><path d="M22 4h-6a4 4 0 0 0-4 4v12a3 3 0 0 1 3-3h7Z"/></svg>',
    message: '<svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/></svg>'
  };
  return icons[key] || icons.sparkles;
}

function createQuickAskCustomActionButton(customAction, isFirst = false) {
  if (!customAction) return null;
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `action${isFirst ? ' custom-start' : ''}`;
  button.dataset.action = 'custom';
  button.dataset.customId = customAction.id;
  button.dataset.customActionId = customAction.id;
  const icon = document.createElement('span');
  icon.className = 'action-icon';
  icon.innerHTML = quickAskCustomIconSvg(customAction.icon);
  const label = document.createElement('span');
  label.className = 'action-label';
  label.textContent = customAction.label;
  button.append(icon, label);
  button.title = customAction.label;
  return button;
}

function refreshQuickAskMenu() {
  if (!quickAskHost?.shadowRoot || !quickAskSelection) return;
  const menu = quickAskHost.shadowRoot.querySelector('.menu');
  if (!menu) return;
  menu.querySelectorAll('.action[data-custom-action-id]').forEach((node) => node.remove());
  quickAskCustomActions.forEach((customAction, index) => {
    const button = createQuickAskCustomActionButton(customAction, index === 0);
    if (button) menu.appendChild(button);
  });
}

function applyQuickAskLanguage(root = quickAskHost?.shadowRoot) {
  if (!root) return;
  const launcher = root.querySelector('.launcher');
  launcher?.setAttribute('aria-label', t('Quick Ask'));
  launcher?.setAttribute('title', t('Quick Ask'));
  for (const [action, label] of Object.entries({ explain: 'Explain', translate: 'Translate', summarize: 'Summarize' })) {
    const text = root.querySelector(`[data-action="${action}"] .action-label`);
    if (text) text.textContent = t(label);
  }
}
globalThis.DinSideI18n?.onChange?.(() => applyQuickAskLanguage());

function quickAskBoxOverlapsSelection(left, top, size, rects, padding = 3) {
  const right = left + size;
  const bottom = top + size;
  return rects.some((rect) => (
    right > rect.left - padding &&
    left < rect.right + padding &&
    bottom > rect.top - padding &&
    top < rect.bottom + padding
  ));
}

function clampQuickAskPoint(left, top, size, margin) {
  return {
    left: Math.max(margin, Math.min(innerWidth - size - margin, left)),
    top: Math.max(margin, Math.min(innerHeight - size - margin, top))
  };
}

function nearestQuickAskRect(rects, anchor) {
  let best = rects[0];
  let bestDistance = Infinity;
  for (const rect of rects) {
    const dx = anchor.x < rect.left ? rect.left - anchor.x : anchor.x > rect.right ? anchor.x - rect.right : 0;
    const dy = anchor.y < rect.top ? rect.top - anchor.y : anchor.y > rect.bottom ? anchor.y - rect.bottom : 0;
    const distance = (dx * dx) + (dy * dy);
    if (distance < bestDistance) {
      best = rect;
      bestDistance = distance;
    }
  }
  return best || rects.at(-1);
}

function positionQuickAsk(host, snapshot) {
  const margin = 8;
  const gap = 10;
  const launcherSize = 30;
  const menuWidth = 168;
  const menuHeight = Math.min(330, 10 + ((3 + quickAskCustomActions.length) * 31) + (quickAskCustomActions.length ? 5 : 0));
  const anchor = snapshot.anchor;
  const rects = snapshot.rects;
  const candidates = [
    [anchor.x + gap, anchor.y + gap],
    [anchor.x + gap, anchor.y - launcherSize - gap],
    [anchor.x - launcherSize - gap, anchor.y + gap],
    [anchor.x - launcherSize - gap, anchor.y - launcherSize - gap]
  ];

  const nearest = nearestQuickAskRect(rects, anchor);
  if (nearest) {
    candidates.push(
      [nearest.right + gap, nearest.bottom + 2],
      [nearest.left - launcherSize - gap, nearest.bottom + 2],
      [nearest.right - launcherSize, nearest.bottom + gap],
      [nearest.right - launcherSize, nearest.top - launcherSize - gap]
    );
  }

  let point = null;
  for (const [rawLeft, rawTop] of candidates) {
    const candidate = clampQuickAskPoint(rawLeft, rawTop, launcherSize, margin);
    if (!quickAskBoxOverlapsSelection(candidate.left, candidate.top, launcherSize, rects)) {
      point = candidate;
      break;
    }
  }
  if (!point) {
    point = clampQuickAskPoint(anchor.x + gap, anchor.y + gap, launcherSize, margin);
  }

  const roomBelow = innerHeight - (point.top + launcherSize + 6);
  const roomAbove = point.top - 6;
  const menuBelow = roomBelow >= menuHeight || roomBelow >= roomAbove;
  host.dataset.menuSide = menuBelow ? 'below' : 'above';
  host.style.left = `${Math.round(point.left)}px`;
  host.style.top = `${Math.round(point.top)}px`;
  host.style.setProperty(
    '--dinside-quick-menu-left',
    `${Math.round(Math.min(0, innerWidth - point.left - menuWidth - margin))}px`
  );
}

function showQuickAsk(pointerAnchor = null) {
  const snapshot = getQuickAskSelection(pointerAnchor);
  if (!snapshot) {
    hideQuickAsk();
    return;
  }

  hideQuickAsk();
  quickAskSelection = snapshot;
  const host = document.createElement('div');
  host.id = '__dinside_quick_ask__';
  host.dataset.theme = quickAskTheme();
  host.style.cssText = 'position:fixed;z-index:2147483647;width:30px;height:30px;pointer-events:auto;';
  const shadow = host.attachShadow({ mode: 'open' });
  shadow.innerHTML = `
    <style>
      :host{all:initial}
      *{box-sizing:border-box}
      .launcher{width:30px;height:30px;border:1px solid rgba(255,255,255,.14);border-radius:10px;background:rgba(30,30,30,.96);color:#fff;box-shadow:0 2px 8px rgba(0,0,0,.18);font:600 15px/1 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;cursor:pointer;display:grid;place-items:center;padding:0;transition:transform .12s ease,background .12s ease,box-shadow .12s ease}
      .launcher:hover{background:rgba(44,44,44,.97);transform:translateY(-1px)}
      .menu{position:absolute;top:36px;left:var(--dinside-quick-menu-left,0);width:194px;max-height:min(250px,calc(100vh - 20px));padding:6px;border:1px solid rgba(255,255,255,.08);border-radius:12px;background:rgba(32,32,32,.98);box-shadow:0 14px 38px rgba(0,0,0,.30);backdrop-filter:blur(16px);overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.18) transparent}.menu::-webkit-scrollbar{width:5px}.menu::-webkit-scrollbar-track{background:transparent}.menu::-webkit-scrollbar-thumb{background:rgba(255,255,255,.18);border-radius:999px}.menu::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,.28)}
      :host([data-menu-side="above"]) .menu{top:auto;bottom:36px}
      .menu[hidden]{display:none}
      .action{width:100%;height:32px;border:0;border-radius:7px;background:transparent;color:rgba(255,255,255,.90);font:500 12.5px/1 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-align:left;padding:0 9px;cursor:pointer;overflow:hidden;white-space:nowrap;display:flex;align-items:center;gap:9px}.action-icon{width:17px;height:17px;min-width:17px;display:grid;place-items:center;color:rgba(255,255,255,.60)}.action-icon svg{width:16px;height:16px;display:block;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.action-label{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .action:hover{background:rgba(255,255,255,.075);color:#fff}
      .action.custom-start{position:relative;margin-top:7px}.action.custom-start::before{content:"";position:absolute;left:7px;right:7px;top:-4px;height:1px;background:rgba(255,255,255,.08)}
      :host([data-theme="light"]) .launcher{border-color:rgba(60,64,67,.16);background:#fff;color:#202124;box-shadow:0 2px 8px rgba(60,64,67,.16)}
      :host([data-theme="light"]) .launcher:hover{background:#fff}
      :host([data-theme="light"]) .menu{border-color:rgba(60,64,67,.10);background:rgba(255,255,255,.98);box-shadow:0 12px 34px rgba(60,64,67,.20);scrollbar-color:rgba(60,64,67,.22) transparent}
      :host([data-theme="light"]) .menu::-webkit-scrollbar-thumb{background:rgba(60,64,67,.22)}
      :host([data-theme="light"]) .action{color:#202124}
      :host([data-theme="light"]) .action:hover{background:rgba(60,64,67,.07)}
      :host([data-theme="light"]) .action.custom-start{border-top-color:rgba(60,64,67,.10)}
    </style>
    <button class="launcher" type="button" aria-label="Quick Ask" title="Quick Ask">✦</button>
    <div class="menu" hidden>
      <button class="action" type="button" data-action="explain"><span class="action-icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M9.8 9.4a2.35 2.35 0 0 1 4.55.8c0 1.8-2.35 2.05-2.35 3.65"/><path d="M12 17h.01"/></svg></span><span class="action-label">Explain</span></button>
      <button class="action" type="button" data-action="translate"><span class="action-icon"><svg viewBox="0 0 24 24"><path d="M4 5h9M8.5 3v2M6 8.5c1.3 2.2 3.2 3.9 5.6 5M11 8.5c-.8 2-2.3 3.8-4.6 5.2"/><path d="m14 18 3-8 3 8M15.2 15h3.6"/></svg></span><span class="action-label">Translate</span></button>
      <button class="action" type="button" data-action="summarize"><span class="action-icon"><svg viewBox="0 0 24 24"><path d="M6 5h12M6 9h12M6 13h8M6 17h6"/></svg></span><span class="action-label">Summarize</span></button>
    </div>`;

  const launcher = shadow.querySelector('.launcher');
  const menu = shadow.querySelector('.menu');
  applyQuickAskLanguage(shadow);
  quickAskCustomActions.forEach((customAction, index) => {
    const button = createQuickAskCustomActionButton(customAction, index === 0);
    if (button) menu.appendChild(button);
  });

  shadow.addEventListener('pointerdown', (event) => event.preventDefault());
  launcher.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    menu.hidden = !menu.hidden;
    positionQuickAsk(host, snapshot);
  });
  shadow.addEventListener('click', (event) => {
    const button = event.target.closest?.('[data-action]');
    if (!button || !quickAskSelection) return;
    const customAction = button.dataset.action === 'custom'
      ? quickAskCustomActions.find((item) => item.id === button.dataset.customId)
      : null;
    if (button.dataset.action === 'custom' && !customAction) return;
    const payload = {
      type: 'DINSIDE_QUICK_ASK',
      action: button.dataset.action,
      label: customAction?.label || '',
      instruction: customAction?.instruction || '',
      selection: {
        text: quickAskSelection.text,
        title: quickAskSelection.title,
        url: quickAskSelection.url,
        locale: quickAskSelection.locale,
        domContext: quickAskSelection.domContext,
        sourceChunk: quickAskSelection.sourceChunk
      }
    };
    hideQuickAsk();
    safeSendMessage(payload);
  });

  document.documentElement.appendChild(host);
  quickAskHost = host;
  positionQuickAsk(host, snapshot);
}

function publishSelectedText() {
  if (!extensionContextAlive || !selectedTextContextEnabled) return;
  const snapshot = getDomAwareSelection();
  if (!snapshot) {
    if (!lastSelectionPayload) return;
    lastSelectionPayload = '';
    safeSendMessage({
      type: 'DINSIDE_TEXT_SELECTION_CLEARED',
      url: location.href
    });
    return;
  }

  const payloadKey = selectionPayloadKey(snapshot);
  if (payloadKey === lastSelectionPayload) return;
  lastSelectionPayload = payloadKey;

  safeSendMessage({
    type: 'DINSIDE_TEXT_SELECTED',
    selection: snapshot
  });
}

let pointerSelecting = false;

document.addEventListener('pointerdown', (event) => {
  if (quickAskHost && event.composedPath?.().includes(quickAskHost)) return;
  if (event.button === 0) {
    pointerSelecting = true;
    hideQuickAsk();
  }
}, true);

document.addEventListener('pointerup', (event) => {
  if (quickAskHost && event.composedPath?.().includes(quickAskHost)) return;
  if (event.button !== 0) return;
  pointerSelecting = false;
  const pointerAnchor = { clientX: event.clientX, clientY: event.clientY };

  // Let the browser finish its native selection/collapse behavior first.
  // This matters for reverse drags: during pointerup dispatch the Selection API
  // can still expose the previous range even though it will collapse immediately
  // after the event finishes. Keep the release point so the launcher follows the
  // end the user actually dragged to instead of the document-order end of a range.
  requestAnimationFrame(() => {
    publishSelectedText();
    showQuickAsk(pointerAnchor);
  });
}, true);

document.addEventListener('pointercancel', () => {
  pointerSelecting = false;
}, true);

// Mouse selection is published only on pointerup. Do not mirror selectionchange:
// it fires continuously while dragging and can make the card update mid-drag.
document.addEventListener('keyup', (event) => {
  if (event.key === 'Escape') {
    hideQuickAsk();
    return;
  }
  if (event.key === 'Shift' || event.shiftKey || event.ctrlKey || event.metaKey) {
    publishSelectedText();
    showQuickAsk();
  }
}, true);

window.addEventListener('scroll', hideQuickAsk, { passive: true });
window.addEventListener('resize', hideQuickAsk, { passive: true });

// Keep viewport context warm before the user presses Send. This only publishes a
// lightweight "viewport changed" signal; the side panel debounces the actual read.
let viewportDirtyTimer = null;
function publishViewportDirty(reason = 'scroll') {
  if (!extensionContextAlive) return;
  clearTimeout(viewportDirtyTimer);
  viewportDirtyTimer = setTimeout(() => {
    safeSendMessage({
      type: 'DINSIDE_VIEWPORT_DIRTY',
      state: getPageState(),
      reason
    });
  }, 120);
}

window.addEventListener('scroll', () => publishViewportDirty('scroll'), { passive: true });
window.addEventListener('resize', () => publishViewportDirty('resize'), { passive: true });

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'DINSIDE_PAGE_STATE') {
    sendResponse({ ok: true, state: getPageState() });
    return;
  }

  if (message?.type === 'DINSIDE_VALIDATE_PAGE_CONTEXT') {
    const validation = validateContentFingerprint(String(message.expectedUrl || ''));
    sendResponse({ ok: true, validation });
    return;
  }

  if (message?.type === 'DINSIDE_READ_PAGE') {
    const context = getReadablePageContext();
    captureContentFingerprintBaseline();
    dirty = false;
    console.log('[DinSide content] page context', {
      title: context?.title || '',
      url: context?.url || '',
      extractor: context?.extractor || 'dom',
      extractorMs: context?.extractorMs ?? null,
      textLength: context?.text?.length || 0,
      linkCount: context?.links?.length || 0,
      imageCount: context?.images?.length || 0
    });
    sendResponse({ ok: true, context });
    return;
  }

  if (message?.type === 'DINSIDE_READ_VIEWPORT') {
    const viewport = getViewportContext();
    console.log('[DinSide content] viewport context', {
      url: viewport?.url || '',
      scrollY: viewport?.scrollY || 0,
      scrollPercent: viewport?.scrollPercent || 0,
      blockCount: viewport?.blocks?.length || 0
    });
    sendResponse({ ok: true, viewport });
  }
});

}
