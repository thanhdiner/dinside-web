const PROVIDERS = {
  chatgpt: {
    id: 'chatgpt',
    tabPatterns: ['https://chatgpt.com/*', 'https://*.chatgpt.com/*'],
    matches(url) {
      return url.hostname === 'chatgpt.com' || url.hostname.endsWith('.chatgpt.com');
    },
    isChat(url) {
      return /^\/(c|g|share)\//.test(url.pathname);
    }
  },
  gemini: {
    id: 'gemini',
    tabPatterns: ['https://gemini.google.com/*'],
    matches(url) {
      return url.hostname === 'gemini.google.com';
    },
    isChat(url) {
      return /^\/(?:u\/\d\/)?app\/[^/]+/.test(url.pathname);
    }
  },
  googleaimode: {
    id: 'googleaimode',
    tabPatterns: [
      'https://www.google.com/ai*',
      'https://www.google.com/search*'
    ],
    matches(url) {
      if (url.hostname !== 'www.google.com') return false;
      if (url.pathname === '/ai') return true;
      return url.pathname === '/search' && (
        url.searchParams.get('udm') === '50' || url.searchParams.get('aep') === '11'
      );
    },
    isChat(url) {
      return this.matches(url) && url.pathname === '/search' && Boolean(url.searchParams.get('q'));
    }
  },
  notebooklm: {
    id: 'notebooklm',
    tabPatterns: ['https://notebook.google.com/*', 'https://notebooklm.google.com/*'],
    matches(url) {
      return url.hostname === 'notebook.google.com' || url.hostname === 'notebooklm.google.com';
    },
    isChat(url) {
      return /^\/notebook\/[^/]+/.test(url.pathname);
    }
  },
  claude: {
    id: 'claude',
    tabPatterns: ['https://claude.ai/*'],
    matches(url) {
      return url.hostname === 'claude.ai';
    },
    isChat(url) {
      return /^\/chat\/[^/]+/.test(url.pathname);
    }
  },
  perplexity: {
    id: 'perplexity',
    tabPatterns: ['https://perplexity.ai/*', 'https://*.perplexity.ai/*'],
    matches(url) {
      return url.hostname === 'perplexity.ai' || url.hostname.endsWith('.perplexity.ai');
    },
    isChat(url) {
      return /^\/search\/[^/]+/.test(url.pathname);
    }
  },
  deepseek: {
    id: 'deepseek',
    tabPatterns: ['https://chat.deepseek.com/*'],
    matches(url) {
      return url.hostname === 'chat.deepseek.com';
    },
    isChat(url) {
      return /^\/a\/chat\/s\/[^/]+/.test(url.pathname);
    }
  },
  openrouter: {
    id: 'openrouter',
    tabPatterns: ['https://openrouter.ai/*'],
    matches(url) {
      return url.hostname === 'openrouter.ai';
    },
    isChat(url) {
      return url.pathname === '/chat' && Boolean(url.searchParams.get('room'));
    }
  },
  copilot: {
    id: 'copilot',
    tabPatterns: ['https://copilot.microsoft.com/*'],
    matches(url) {
      return url.hostname === 'copilot.microsoft.com';
    },
    isChat(url) {
      const match = url.pathname.match(/^\/chats\/([^/]+)\/?$/);
      return Boolean(match?.[1] && !['new', 'temporary'].includes(match[1]));
    }
  },
  qwen: {
    id: 'qwen',
    tabPatterns: ['https://chat.qwen.ai/*'],
    matches(url) {
      return url.hostname === 'chat.qwen.ai';
    },
    isChat(url) {
      const match = url.pathname.match(/^\/c\/([^/]+)\/?$/);
      return Boolean(match?.[1] && !['new-chat', 'new-branch'].includes(match[1]));
    }
  },
  kimi: {
    id: 'kimi',
    tabPatterns: ['https://kimi.ai/*', 'https://www.kimi.ai/*'],
    matches(url) {
      return url.hostname === 'kimi.ai' || url.hostname === 'www.kimi.ai';
    },
    isChat(url) {
      const match = url.pathname.match(/^\/chat\/([^/]+)\/?$/);
      return Boolean(match?.[1] && match[1] !== 'history');
    }
  },
  metaai: {
    id: 'metaai',
    tabPatterns: ['https://meta.ai/*', 'https://www.meta.ai/*'],
    matches(url) {
      return url.hostname === 'meta.ai' || url.hostname === 'www.meta.ai';
    },
    isChat(url) {
      return /^\/(?:c|prompt)\/[^/]+\/?$/.test(url.pathname);
    }
  },
  mimo: {
    id: 'mimo',
    tabPatterns: ['https://aistudio.xiaomimimo.com/*'],
    matches(url) {
      return url.hostname === 'aistudio.xiaomimimo.com';
    },
    isChat(url) {
      return /^#\/(?:ultra|chat)\/[^/?#]+\/?(?:[?#]|$)/.test(url.hash);
    }
  },
  zai: {
    id: 'zai',
    tabPatterns: ['https://chat.z.ai/*'],
    matches(url) {
      return url.hostname === 'chat.z.ai';
    },
    isChat(url) {
      return /^\/c\/[^/]+\/?$/.test(url.pathname);
    }
  },
  googleaistudio: {
    id: 'googleaistudio',
    tabPatterns: ['https://aistudio.google.com/*'],
    matches(url) {
      return url.hostname === 'aistudio.google.com' && /^\/(?:u\/\d\/)?prompts\//.test(url.pathname);
    },
    isChat(url) {
      const promptId = url.pathname.match(/^\/(?:u\/\d\/)?prompts\/([^/?#]+)/)?.[1];
      return Boolean(promptId && promptId !== 'new_chat');
    }
  }
};
function providerForUrl(url) {
  return Object.values(PROVIDERS).find((provider) => provider.matches(url)) || null;
}

const MIMO_COOKIE_URL = 'https://aistudio.xiaomimimo.com/';
const MIMO_COOKIE_NAME = 'xiaomichatbot_ph';
function isSidePanelSender(sender) {
  try {
    const url = new URL(sender?.url || '');
    return sender?.id === chrome.runtime.id &&
      url.origin === new URL(chrome.runtime.getURL('/')).origin &&
      url.pathname === '/sidepanel.html';
  } catch (_) {
    return false;
  }
}

async function syncMimoCookiePartition() {
  if (!chrome.cookies?.get || !chrome.cookies?.set) {
    return { ok: false, found: false, changed: false, error: 'Cookie API unavailable.' };
  }
  try {
    const partitionKey = {
      topLevelSite: chrome.runtime.getURL('/').replace(/\/$/, ''),
      hasCrossSiteAncestor: true
    };
    const source = await chrome.cookies.get({ url: MIMO_COOKIE_URL, name: MIMO_COOKIE_NAME });
    // MiMo reads this non-HttpOnly identifier through document.cookie. Session
    // credentials and any other cookies are never copied by DinSide.
    if (source?.httpOnly) {
      return { ok: false, found: false, changed: false, error: 'MiMo session cookie is HttpOnly.' };
    }
    const embedded = await chrome.cookies.get({
      url: MIMO_COOKIE_URL,
      name: MIMO_COOKIE_NAME,
      ...(source?.storeId ? { storeId: source.storeId } : {}),
      partitionKey
    });
    if (!source?.value) {
      if (!embedded) return { ok: true, found: false, changed: false, accountChanged: false };
      const removed = await chrome.cookies.remove({
        url: MIMO_COOKIE_URL,
        name: MIMO_COOKIE_NAME,
        storeId: embedded.storeId,
        partitionKey
      });
      return { ok: true, found: false, changed: Boolean(removed), accountChanged: Boolean(removed) };
    }
    if (embedded?.value === source.value) {
      return { ok: true, found: true, changed: false, accountChanged: false };
    }
    const details = {
      url: MIMO_COOKIE_URL,
      name: MIMO_COOKIE_NAME,
      value: source.value,
      path: source.path || '/',
      secure: true,
      httpOnly: false,
      sameSite: 'no_restriction',
      ...(source.storeId ? { storeId: source.storeId } : {}),
      partitionKey
    };
    if (!source.session && Number.isFinite(source.expirationDate)) {
      details.expirationDate = source.expirationDate;
    }
    const mirrored = await chrome.cookies.set(details);
    return {
      ok: Boolean(mirrored),
      found: true,
      changed: Boolean(mirrored),
      accountChanged: Boolean(mirrored && embedded)
    };
  } catch (error) {
    return { ok: false, found: false, changed: false, error: error?.message || String(error) };
  }
}

let mimoCookieChangeTimer = null;
chrome.cookies.onChanged.addListener(({ cookie }) => {
  if (cookie?.name !== MIMO_COOKIE_NAME || cookie.partitionKey) return;
  const domain = String(cookie.domain || '').replace(/^\./, '');
  if (domain !== 'aistudio.xiaomimimo.com' && domain !== 'xiaomimimo.com') return;
  clearTimeout(mimoCookieChangeTimer);
  mimoCookieChangeTimer = setTimeout(async () => {
    mimoCookieChangeTimer = null;
    const result = await syncMimoCookiePartition();
    if (result.changed) {
      try {
        const saved = await chrome.storage.local.get('dinsideLastChatUrls');
        if (saved.dinsideLastChatUrls?.mimo) {
          const lastChatUrls = { ...saved.dinsideLastChatUrls };
          delete lastChatUrls.mimo;
          await chrome.storage.local.set({ dinsideLastChatUrls: lastChatUrls });
        }
      } catch (error) {
        console.warn('[DinSide] could not clear old MiMo chat after account change', error);
      }
      chrome.runtime.sendMessage({ type: 'DINSIDE_MIMO_SESSION_CHANGED' }).catch(() => {});
    }
  }, 350);
});

const PERPLEXITY_FRAME_RULE_ID = 1004;
const CLAUDE_FRAME_RULE_IDS = [1003, 1005];
const META_FRAME_RULE_ID = 1006;
const GOOGLE_FRAME_RULE_IDS = [1007, 1008, 1009, 1010];
let installedClaudeFrameRuleKey = '';
let claudeFrameRuleUpdate = Promise.resolve();
let installedMetaFrameRuleKey = '';
let metaFrameRuleUpdate = Promise.resolve();
let installedGoogleFrameRuleKey = '';
let googleFrameRuleUpdate = Promise.resolve();
async function installPerplexityFrameRule() {
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [PERPLEXITY_FRAME_RULE_ID],
      addRules: [{
        id: PERPLEXITY_FRAME_RULE_ID,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            { header: 'x-frame-options', operation: 'remove' },
            { header: 'frame-options', operation: 'remove' },
            { header: 'content-security-policy', operation: 'remove' }
          ]
        },
        condition: {
          tabIds: [chrome.tabs.TAB_ID_NONE],
          requestDomains: ['perplexity.ai'],
          resourceTypes: ['sub_frame']
        }
      }]
    });
  } catch (error) {
    console.warn('[DinSide] Failed to install Perplexity iframe rule:', error);
  }
}

async function installClaudeFrameRules() {
  const tabIds = [chrome.tabs.TAB_ID_NONE];
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (Number.isInteger(activeTab?.id)) tabIds.push(activeTab.id);
  } catch (_) {
    // The side panel request still has TAB_ID_NONE when no tab is available.
  }

  const condition = {
    requestDomains: ['claude.ai'],
    tabIds,
    resourceTypes: ['sub_frame']
  };
  const requestHeaders = [
    { header: 'user-agent', operation: 'set', value: navigator.userAgent }
  ];
  const userAgentData = navigator.userAgentData;
  if (Array.isArray(userAgentData?.brands)) {
    const brands = userAgentData.brands.map(({ brand, version }) =>
      `"${String(brand).replace(/["\\]/g, '\\$&')}";v="${String(version).replace(/["\\]/g, '\\$&')}"`
    ).join(', ');
    if (brands) requestHeaders.push({ header: 'sec-ch-ua', operation: 'set', value: brands });
  }
  if (userAgentData) {
    requestHeaders.push(
      { header: 'sec-ch-ua-mobile', operation: 'set', value: userAgentData.mobile ? '?1' : '?0' },
      { header: 'sec-ch-ua-platform', operation: 'set', value: JSON.stringify(userAgentData.platform || '') }
    );
  }
  const ruleKey = tabIds.join(',');
  claudeFrameRuleUpdate = claudeFrameRuleUpdate.catch(() => {}).then(async () => {
    if (installedClaudeFrameRuleKey === ruleKey) return;
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: CLAUDE_FRAME_RULE_IDS,
      addRules: [
        {
          id: CLAUDE_FRAME_RULE_IDS[0],
          priority: 2,
          action: {
            type: 'modifyHeaders',
            requestHeaders,
            responseHeaders: [
              { header: 'x-frame-options', operation: 'remove' },
              { header: 'content-security-policy', operation: 'remove' },
              { header: 'content-security-policy-report-only', operation: 'remove' }
            ]
          },
          condition
        },
        {
          id: CLAUDE_FRAME_RULE_IDS[1],
          priority: 2,
          action: {
            type: 'modifyHeaders',
            requestHeaders: [
              { header: 'sec-fetch-dest', operation: 'set', value: 'document' },
              { header: 'sec-fetch-site', operation: 'set', value: 'same-origin' }
            ]
          },
          condition
        }
      ]
    });
    installedClaudeFrameRuleKey = ruleKey;
  });
  await claudeFrameRuleUpdate;
}

async function installMetaFrameRule() {
  // Present the embedded navigation with document fetch metadata before Meta's
  // initial HTML request. Keep the rule scoped to Meta subframes.
  const tabIds = [chrome.tabs.TAB_ID_NONE];
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (Number.isInteger(activeTab?.id)) tabIds.push(activeTab.id);
  } catch (_) {
    // The side panel request still has TAB_ID_NONE when no tab is available.
  }

  const ruleKey = tabIds.join(',');
  metaFrameRuleUpdate = metaFrameRuleUpdate.catch(() => {}).then(async () => {
    if (installedMetaFrameRuleKey === ruleKey) return;
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [META_FRAME_RULE_ID],
      addRules: [{
        id: META_FRAME_RULE_ID,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'sec-fetch-dest', operation: 'set', value: 'document' },
            { header: 'sec-fetch-site', operation: 'set', value: 'same-origin' }
          ]
        },
        condition: {
          tabIds,
          requestDomains: ['meta.ai'],
          resourceTypes: ['sub_frame']
        }
      }]
    });
    installedMetaFrameRuleKey = ruleKey;
  });
  await metaFrameRuleUpdate;
}

async function installGoogleFrameRules() {
  // Install the Google rules together so switching between providers does
  // not have to replace them. The side panel may use TAB_ID_NONE or its tab ID.
  const tabIds = [chrome.tabs.TAB_ID_NONE];
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (Number.isInteger(activeTab?.id)) tabIds.push(activeTab.id);
  } catch (_) {
    // TAB_ID_NONE still covers requests made by the extension side panel.
  }

  const ruleKey = tabIds.join(',');
  googleFrameRuleUpdate = googleFrameRuleUpdate.catch(() => {}).then(async () => {
    if (installedGoogleFrameRuleKey === ruleKey) return;
    const action = {
      type: 'modifyHeaders',
      requestHeaders: [
        { header: 'sec-fetch-dest', operation: 'set', value: 'document' },
        { header: 'sec-fetch-site', operation: 'set', value: 'same-origin' }
      ],
      responseHeaders: [
        { header: 'x-frame-options', operation: 'remove' },
        { header: 'frame-options', operation: 'remove' },
        { header: 'content-security-policy', operation: 'remove' },
        { header: 'content-security-policy-report-only', operation: 'remove' }
      ]
    };
    const condition = { tabIds, resourceTypes: ['sub_frame'] };
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: GOOGLE_FRAME_RULE_IDS,
      addRules: [
        {
          id: GOOGLE_FRAME_RULE_IDS[0],
          priority: 2,
          action,
          condition: { ...condition, requestDomains: ['gemini.google.com'] }
        },
        {
          id: GOOGLE_FRAME_RULE_IDS[1],
          priority: 2,
          action,
          condition: {
            ...condition,
            regexFilter: '^https://www\\.google\\.com/(?:ai(?:[/?#]|$)|search(?:[?#]|$))'
          }
        },
        {
          id: GOOGLE_FRAME_RULE_IDS[2],
          priority: 2,
          action: {
            type: 'modifyHeaders',
            responseHeaders: action.responseHeaders
          },
          condition: {
            ...condition,
            requestDomains: ['accounts.google.com', 'ogs.google.com'],
            initiatorDomains: [
              'gemini.google.com', 'www.google.com', 'notebook.google.com',
              'notebooklm.google.com', 'ogs.google.com', 'aistudio.google.com'
            ]
          }
        },
        {
          id: GOOGLE_FRAME_RULE_IDS[3],
          priority: 2,
          action,
          condition: { ...condition, requestDomains: ['aistudio.google.com'] }
        }
      ]
    });
    installedGoogleFrameRuleKey = ruleKey;
  });
  await googleFrameRuleUpdate;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  injectDinSideContentScripts();
});

// Reloading an unpacked extension invalidates content scripts already injected
// into existing tabs. Re-inject them so selection/context listeners recover
// without requiring the user to refresh every webpage.
async function injectDinSideContentScripts() {
  const tabs = await chrome.tabs.query({});

  for (const tab of tabs) {
    if (!tab.id || !tab.url) continue;
    if (!/^https?:\/\//.test(tab.url)) continue;

    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['i18n.js', 'content.js']
      });
      if (/^https:\/\/docs\.google\.com\/document\//i.test(tab.url)) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: ['google-docs-selection.js']
        });
      }
      if (
        /^https:\/\/(?:classroom|drive)\.google\.com\//i.test(tab.url) ||
        /^https:\/\/docs\.google\.com\/(?:viewer|gview)/i.test(tab.url) ||
        /^https:\/\/[^/]*googleusercontent\.com\//i.test(tab.url) ||
        /\.pdf(?:[?#]|$)/i.test(tab.url)
      ) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: ['i18n.js', 'pdf-selection.js']
        });
      }
    } catch (_) {
      // Ignore restricted pages (chrome://, extensions, PDF viewers, etc.).
    }
  }
}

async function prepareProviderFrame(providerId, sender) {
  if (providerId === 'mimo') {
    if (!isSidePanelSender(sender)) return { ok: false, error: 'MiMo session sync requires DinSide side panel.' };
    return syncMimoCookiePartition();
  }
  if (providerId === 'gemini' || providerId === 'googleaimode' || providerId === 'notebooklm' || providerId === 'googleaistudio') {
    await installGoogleFrameRules();
    return { ok: true };
  }
  if (providerId === 'claude') {
    await installClaudeFrameRules();
    return { ok: true };
  }
  if (providerId === 'metaai') {
    await installMetaFrameRule();
    return { ok: true };
  }
  if (providerId !== 'perplexity') return { ok: true };
  await installPerplexityFrameRule();
  // Perplexity's service worker can synthesize the iframe document with its
  // original frame-ancestors CSP, bypassing DNR response-header rewriting.
  // Remove only that origin's service-worker registration before embedding;
  // cookies, login state, local storage, and normal cache are left untouched.
  await chrome.browsingData.removeServiceWorkers({
    origins: ['https://www.perplexity.ai', 'https://perplexity.ai']
  });
  return { ok: true };
}

let lastProviderAuthRequestKey = '';
let lastProviderAuthRequestAt = 0;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'DINSIDE_PROVIDER_AUTH_OPEN') {
    let url;
    try {
      url = new URL(String(message.url || ''));
    } catch (_) {
      sendResponse({ ok: false, error: 'Invalid provider sign-in URL.' });
      return;
    }
    if (url.protocol !== 'https:') {
      sendResponse({ ok: false, error: 'Provider sign-in must use HTTPS.' });
      return;
    }
    const requestKey = `${String(message.providerHost || url.hostname)}|${url.href}`;
    const now = Date.now();
    if (requestKey === lastProviderAuthRequestKey && now - lastProviderAuthRequestAt < 2000) {
      sendResponse({ ok: true, duplicate: true });
      return;
    }
    lastProviderAuthRequestKey = requestKey;
    lastProviderAuthRequestAt = now;
    chrome.tabs.create({ url: url.href, active: true })
      .then((tab) => {
        chrome.runtime.sendMessage({
          type: 'DINSIDE_PROVIDER_AUTH_TAB_CREATED',
          providerHost: String(message.providerHost || url.hostname),
          tabId: tab?.id
        }).catch(() => {});
        sendResponse({ ok: true, tabId: tab?.id });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'DINSIDE_PREPARE_PROVIDER_FRAME') {
    prepareProviderFrame(message.providerId, sender)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
    return true;
  }
  if (message?.type === 'DINSIDE_CHAT_URL_CHANGED') {
    let url;
    try {
      url = new URL(String(message.url || ''));
    } catch (_) {
      return;
    }
    const provider = providerForUrl(url);
    if (!provider || (message.providerId && message.providerId !== provider.id)) return;
    chrome.storage.local.get(['dinsideKeepLastChat', 'dinsideLastChatUrls'])
      .then((saved) => {
        if (saved.dinsideKeepLastChat !== true || !provider.isChat(url)) return;
        const urls = saved.dinsideLastChatUrls && typeof saved.dinsideLastChatUrls === 'object'
          ? { ...saved.dinsideLastChatUrls }
          : {};
        urls[provider.id] = url.href;
        return chrome.storage.local.set({ dinsideLastChatUrls: urls });
      })
      .catch(() => {});
    return;
  }
  if (message?.type === 'DINSIDE_QUICK_ASK') {
    const action = ['explain', 'translate', 'summarize', 'custom'].includes(message.action)
      ? message.action
      : 'explain';
    const text = String(message.selection?.text ?? '').slice(0, 12000);
    const instruction = action === 'custom'
      ? String(message.instruction || '').trim().slice(0, 2000)
      : '';
    const label = action === 'custom'
      ? String(message.label || '').trim().slice(0, 32)
      : '';
    if (!sender.tab?.id || !text.trim() || (action === 'custom' && !instruction)) {
      sendResponse({ ok: false, error: 'Quick Ask needs a valid webpage selection and action.' });
      return;
    }

    const pending = {
      id: `quick-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      action,
      label,
      instruction,
      sourceTabId: sender.tab.id,
      createdAt: Date.now(),
      selection: {
        text,
        title: String(message.selection?.title || sender.tab.title || '').slice(0, 500),
        url: String(message.selection?.url || sender.tab.url || '').slice(0, 4000),
        locale: String(message.selection?.locale || '').slice(0, 32),
        domContext: {
          section: String(message.selection?.domContext?.section || '').trim().slice(0, 240),
          element: String(message.selection?.domContext?.element || '').trim().slice(0, 80),
          tag: String(message.selection?.domContext?.tag || '').trim().slice(0, 40),
          block: String(message.selection?.domContext?.block || '').trim().slice(0, 40),
          blockId: String(message.selection?.domContext?.blockId || '').trim().slice(0, 500)
        },
        sourceChunk: String(message.selection?.sourceChunk || '').trim().slice(0, 1800)
      }
    };

    const store = chrome.storage.session || chrome.storage.local;
    const savePromise = store.set({ dinsideQuickAskPending: pending });
    // Start opening the side panel directly from the user-triggered message so
    // Chrome still sees this as part of the click gesture from the webpage.
    const openPromise = chrome.sidePanel.open({ tabId: sender.tab.id });
    Promise.all([savePromise, openPromise])
      .then(() => {
        chrome.runtime.sendMessage({ type: 'DINSIDE_QUICK_ASK_PENDING' }).catch(() => {});
        sendResponse({ ok: true, id: pending.id });
      })
      .catch((error) => sendResponse({
        ok: false,
        error: error?.message || 'Could not open DinSide for Quick Ask.'
      }));
    return true;
  }
  if (message?.type === 'DINSIDE_ATTACH_SCREENSHOT_NOW') {
    const provider = PROVIDERS[message.providerId] || PROVIDERS.chatgpt;
    chrome.tabs.query({ url: provider.tabPatterns }, (tabs) => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      const target = tabs.find((tab) => tab.id && tab.status === 'complete') || tabs.find((tab) => tab.id);
      if (!target?.id) {
        sendResponse({ ok: false, error: `${provider.id} tab/frame was not found.` });
        return;
      }
      chrome.tabs.sendMessage(target.id, {
        type: 'DINSIDE_ATTACH_SCREENSHOT_NOW',
        providerId: provider.id,
        screenshot: message.screenshot
      }, (response) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        sendResponse(response || { ok: false, error: `No response from ${provider.id} bridge.` });
      });
    });
    return true;
  }
  if (message?.type === 'DINSIDE_CAPTURE_VISIBLE_TAB') {
    chrome.tabs.captureVisibleTab(undefined, { format: 'png' }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      sendResponse({ ok: true, dataUrl });
    });
    return true;
  }
});
